"""Write the v0.42 supplementary tables S7/S8 from stored reports (no manual transcription).

S7: centre depth against the rangefinder for C1-C5 (v0.41 LRF run), C6-C8 (v0.42 RTK summary)
and MVS at 1600/518 px with the C5 cameras (v0.41 LRF run, v0.42 MVS518 analysis).
S8: solver state, withheld RTK deviation, calibration residual and V3 discrepancy of C6-C8 against C5.
"""
from pathlib import Path
import json, sys

BASE = Path(__file__).resolve().parent; RUNS = BASE / 'runs'
SRC = BASE.parent / 'paper/Bridge_Reconstruction_Buildings_LaTeX_v0.42_Source'
LABELS = {'R10': 'C6', 'R03': 'C7', 'RF': 'C8'}


def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def sgn(x, digits): return f"{'$+$' if x >= 0 else '$-$'}{abs(x):.{digits}f}"
def pct(b): return sgn(b, 2) + '\\%'


def main(rtk_run, mvs_run):
    lrf = read(sorted(RUNS.glob('revision_v041_lrf_*'))[-1] / 'report.json')['centre_depth_vs_lrf']; rtk = read(rtk_run / 'report.json'); mvs = read(mvs_run / 'report.json') if mvs_run else None
    rows = []
    def old(case, method, key):
        a, f = lrf[key]['all_lrf'], lrf[key]['locally_flat_centre']
        rows.append(f"{case} & {method} & {pct((a['ratio_to_lrf']['median'] - 1) * 100)} & {a['abs_residual_after_median_ratio_m']['median']:.2f}/{a['abs_residual_after_median_ratio_m']['p95']:.2f} & "
                    f"{pct((f['ratio_to_lrf']['median'] - 1) * 100)} & {f['abs_residual_after_median_ratio_m']['median']:.2f}/{f['abs_residual_after_median_ratio_m']['p95']:.2f} \\\\")
    def new(case, method, a, f):
        rows.append(f"{case} & {method} & {pct(a['bias_pct'])} & {a['scatter_median_m']:.2f}/{a['scatter_p95_m']:.2f} & {pct(f['bias_pct'])} & {f['scatter_median_m']:.2f}/{f['scatter_p95_m']:.2f} \\\\")
    for c in ['C1', 'C2', 'C3', 'C4', 'C5']:
        for m in ['V3', 'A3', 'A1']: old(c, m, f'{c}_{m}')
    old('C5', 'MVS 1600', 'MVS')
    if mvs: new('C5', 'MVS 518', mvs['centre_depth_vs_lrf']['MVS518']['all'], mvs['centre_depth_vs_lrf']['MVS518']['flat'])
    for label, case in LABELS.items():
        if label not in rtk['cases']: continue
        r = rtk['cases'][label]['centre_depth_vs_lrf']
        for m in ['V3', 'A3', 'A1']: new(case, m, r[f'{m}/all'], r[f'{m}/flat'])
    (SRC / '_tableS7.tex').write_text('\n'.join(rows), encoding='utf-8')
    # Reference row: the primary C5 (continuation report of its prior solve, and its own V3 support).
    import numpy as np
    ctrl = read(RUNS / 'full_route_survey_20261018_221243_8084fdb4/navigation_prior_controls/20261019_203952_8cc0b0b6/report.json')
    prim = read(RUNS / 'global_hybrid_20261019_205203_28fc26c6/report.json'); prep = read(Path(prim['preparation']) / 'report.json')
    with np.load(RUNS / 'global_hybrid_20261019_205203_28fc26c6/checking_pairs.npz') as p: e, ok = p['errors'][:, 3], p['supported'][:, 3]
    params = prep['native_cameras'][str(min(v['camera_id'] for v in prep['views'] if v['index'] < 576))]['params']
    w = ctrl['withheld_navigation_error']; t = ctrl['training_reprojection_pixels']; assert prep['camera_control_source'].endswith('20261019_203952_8cc0b0b6')
    s8 = [f"C5 & 100 + 39 & {params[0]:.1f} & {params[3]:.3f} & {w['median']:.2f}/{w['p95']:.2f} & {t['median']:.3f}/{t['p95']:.2f} & {np.median(e[ok]):.3f}/{np.percentile(e[ok], 95):.2f} & "
          f"{100 * ok.mean():.2f}\\%/{100 * np.sum(ok & (e < 2)) / len(e):.2f}\\% & (reference) \\\\"]
    for label, case in LABELS.items():
        if label not in rtk['cases']: continue
        r = rtk['cases'][label]; it = int(r['solver'].split('Iterations: ')[1].split(',')[0]); w = r['withheld_rtk_deviation_m']; t = r['training_reprojection_px']; v = r['v3']
        d = v['median_minus_C5_V3']; k1 = r['main_camera']['params'][3]
        s8.append(f"{case} & {it} & {r['main_camera']['params'][0]:.1f} & {k1:.3f} & {w['median']:.2f}/{w['p95']:.2f} & {t['median']:.3f}/{t['p95']:.2f} & {v['own']['median']:.3f}/{v['own']['p95']:.2f} & "
                  f"{100 * v['support']:.2f}\\%/{100 * v['success_below2px']:.2f}\\% & {sgn(d['point'], 3)} [{sgn(d['ci95'][0], 3)}, {sgn(d['ci95'][1], 3)}] \\\\")
    (SRC / '_tableS8.tex').write_text('\n'.join(s8), encoding='utf-8')
    print('\n'.join(rows[-10:])); print('\n'.join(s8))


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else None)
