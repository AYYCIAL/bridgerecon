"""Shared-photo Sim(3) alignment and explicit cross-block numerical checks.

Shared pixels are predictions of the same input photo in different contexts.
They are not independent physical landmarks or a PCD accuracy assessment.
"""
import numpy as np
from scipy.spatial.transform import Rotation
from scipy.optimize import lsq_linear
from similarity import robust_similarity,apply_similarity
from local_validation import unproject,project_world
from geometry_core import camera_centers

SETTINGS={'grid_step':8,'minimum_common_images':3,'minimum_points_per_common_image':100,
          'confidence_minimum':1.2,'fit_cap_per_image':600,
          'split':'(grid_row+2*grid_column) modulo5==0 for checking; remainder for fitting',
          'ransac_threshold_fraction_reference_depth':.01,
          'minimum_second_to_first_singular_value':1e-4,
          'maximum_check_p95_distance_fraction_depth':.03,
          'maximum_check_median_reprojection_pixels':3.,
          'maximum_camera_center_median_distance_fraction_depth':.03,
          'maximum_camera_rotation_p95_degrees':5.,
          'minimum_local_scale':.5,'maximum_local_scale':2.}


def identity():return (1.,np.eye(3),np.zeros(3))


def compose(outer,inner):
    a,A,b=outer;s,R,t=inner
    return a*s,A@R,a*A@t+b


def transform_extrinsics(E,model):
    s,R,t=model
    rotations=E[:,:,:3]@R.T
    translations=s*E[:,:,3]-np.einsum('nij,j->ni',rotations,t)
    return np.concatenate([rotations,translations[:,:,None]],axis=2)


def serialize(model):
    s,R,t=model
    return {'scale':float(s),'rotation':R.tolist(),'translation':t.tolist()}


def scalar_stats(a):
    a=np.asarray(a);a=a[np.isfinite(a)]
    return {'n':len(a),'median':float(np.median(a)) if len(a) else None,
            'p95':float(np.percentile(a,95)) if len(a) else None,
            'max':float(a.max()) if len(a) else None}


def align(previous,current,mode='points'):
    common=sorted(set(previous['image_indices'].tolist())&set(current['image_indices'].tolist()))
    report={'qualified':False,'common_image_indices':common,'settings':SETTINGS,'alignment_mode':mode,
            'reference_access':False,'assessment_scope':'Cross-context numerical consistency on shared predictions, not independent accuracy'}
    if len(common)<SETTINGS['minimum_common_images']:
        report['reasons']=['insufficient_common_images'];return None,report
    h,w=previous['depth'].shape[1:3]
    assert current['depth'].shape[1:3]==(h,w)
    yy,xx=np.mgrid[8:h-8:8,8:w-8:8];uv=np.c_[xx.ravel(),yy.ravel()]
    check=((np.indices(yy.shape)[0]+2*np.indices(yy.shape)[1])%5==0).ravel()
    source=[];target=[];held_source=[];held_target=[];held_uv=[];held_view=[];counts=[]
    depths=[];fit_views=[];check_views=[];fit_depths=[];check_depths=[]
    for index in common:
        p=int(np.where(previous['image_indices']==index)[0][0]);c=int(np.where(current['image_indices']==index)[0][0])
        x=uv[:,0];y=uv[:,1]
        d0=previous['depth'][p,y,x,0];d1=current['depth'][c,y,x,0]
        conf0=previous['depth_conf'][p,y,x];conf1=current['depth_conf'][c,y,x]
        good=(conf0>=1.2)&(conf1>=1.2)&(d0>0)&(d1>0)&np.isfinite(d0)&np.isfinite(d1)
        fit_ids=np.where(good&~check)[0]
        if len(fit_ids)>600:fit_ids=fit_ids[np.linspace(0,len(fit_ids)-1,600,dtype=int)]
        check_ids=np.where(good&check)[0]
        counts.append({'image_index':index,'eligible_grid_pixels':int(good.sum()),'fit_samples':len(fit_ids),'checking_samples':len(check_ids)})
        for ids,dst0,dst1 in [(fit_ids,target,source),(check_ids,held_target,held_source)]:
            dst0.append(unproject(uv[ids],d0[ids],previous['extrinsics'][p],previous['intrinsics'][p]))
            dst1.append(unproject(uv[ids],d1[ids],current['extrinsics'][c],current['intrinsics'][c]))
        fit_views.extend([c]*len(fit_ids));check_views.extend([c]*len(check_ids))
        fit_depths.extend(d1[fit_ids]);check_depths.extend(d1[check_ids])
        held_uv.append(uv[check_ids]);held_view.extend([p]*len(check_ids));depths.extend(d0[good].tolist())
    report['sampling']=counts
    if any(r['eligible_grid_pixels']<100 or r['checking_samples']<20 for r in counts):
        report['reasons']=['insufficient_shared_depth_support'];return None,report
    source=np.concatenate(source);target=np.concatenate(target)
    held_source=np.concatenate(held_source);held_target=np.concatenate(held_target);held_uv=np.concatenate(held_uv)
    L=(float(np.median(depths))-float(previous.get('_applied_depth_offset',0.)))/float(previous.get('_applied_depth_scale',1.));report['reference_depth_normalizer']=L
    singular=np.linalg.svd(source-source.mean(axis=0),compute_uv=False)
    ratio=float(singular[1]/max(singular[0],1e-12));report['second_to_first_singular_value']=ratio
    if ratio<1e-4:
        report['reasons']=['nearly_collinear_shared_geometry'];return None,report
    depth_scale=1.;depth_offset=0.;affine_bound_hit=False
    if mode=='points':
        model,inliers,fit_errors=robust_similarity(source,target,.01*L,seed=20261019)
    elif mode in ('camera_depth','camera_depth_affine'):
        ps=[int(np.where(previous['image_indices']==i)[0][0]) for i in common]
        cs=[int(np.where(current['image_indices']==i)[0][0]) for i in common]
        rotations=previous['extrinsics'][ps,:,:3].transpose(0,2,1)@current['extrinsics'][cs,:,:3]
        R=Rotation.from_matrix(rotations).mean().as_matrix()
        pc=camera_centers(previous['extrinsics'])[ps];cc=camera_centers(current['extrinsics'])[cs]
        x=(cc-cc.mean(axis=0))@R.T;y=pc-pc.mean(axis=0)
        scale=float(np.sum(x*y)/np.sum(x*x))
        if not np.isfinite(scale) or scale<=0:raise ValueError('Unsupported camera-motion scale')
        model=(scale,R,pc.mean(axis=0)-scale*R@cc.mean(axis=0))
        centers=camera_centers(current['extrinsics'])
        origin=apply_similarity(centers[np.array(fit_views)],model)
        ray=scale*(source-centers[np.array(fit_views)])@R.T
        goal=target-origin;weights=np.ones(len(source))
        unit_ray=ray/np.array(fit_depths)[:,None]
        for _ in range(8):
            if mode=='camera_depth':
                depth_scale=float(np.sum(weights*np.sum(ray*goal,axis=1))/np.sum(weights*np.sum(ray*ray,axis=1)))
            else:
                design=np.stack([ray,unit_ray*L/scale],axis=2).reshape(-1,2)
                weight=np.repeat(np.sqrt(weights),3)
                fitted=lsq_linear(design*weight[:,None],goal.ravel()*weight,bounds=([.8,-.05],[1.25,.05]),tol=1e-12)
                depth_scale=float(fitted.x[0]);depth_offset=float(fitted.x[1]*L/scale)
                affine_bound_hit=bool(np.any(fitted.active_mask))
            error=np.linalg.norm(ray*depth_scale+unit_ray*depth_offset-goal,axis=1)
            weights=np.minimum(1.,(.01*L)/np.maximum(error,1e-12))
        source=centers[np.array(fit_views)]+(depth_scale+depth_offset/np.array(fit_depths))[:,None]*(source-centers[np.array(fit_views)])
        held_source=centers[np.array(check_views)]+(depth_scale+depth_offset/np.array(check_depths))[:,None]*(held_source-centers[np.array(check_views)])
        fit_errors=np.linalg.norm(apply_similarity(source,model)-target,axis=1)
        inliers=fit_errors<.01*L
        report['depth_scale_fit_scope']='Global depth scale'+(' and offset' if mode=='camera_depth_affine' else '')+' for entire current chunk; fit spatial samples only; no reference data'
        if mode=='camera_depth_affine':report['depth_offset_bound_fraction_mapped_reference_depth']=.05
    else:raise ValueError('Unknown alignment mode')
    checked=apply_similarity(held_source,model)
    distance=np.linalg.norm(checked-held_target,axis=1)/L
    reprojection=[];negative=0
    held_view=np.array(held_view)
    for view in np.unique(held_view):
        ids=np.where(held_view==view)[0]
        pixel,z=project_world(checked[ids],previous['extrinsics'][view],previous['intrinsics'][view])
        negative+=int((z<=0).sum())
        error=np.linalg.norm(pixel-held_uv[ids],axis=1)
        error[z<=0]=np.inf;reprojection.extend(error.tolist())
    p_slots=[int(np.where(previous['image_indices']==i)[0][0]) for i in common]
    c_slots=[int(np.where(current['image_indices']==i)[0][0]) for i in common]
    camera_error=np.linalg.norm(apply_similarity(camera_centers(current['extrinsics'])[c_slots],model)-camera_centers(previous['extrinsics'])[p_slots],axis=1)/L
    transformed=transform_extrinsics(current['extrinsics'],model)
    delta=transformed[c_slots,:,:3]@previous['extrinsics'][p_slots,:,:3].transpose(0,2,1)
    angles=np.degrees(Rotation.from_matrix(delta).magnitude())
    report.update(local_similarity=serialize(model),depth_scale_correction=depth_scale,depth_offset_correction=depth_offset,affine_bound_hit=affine_bound_hit,fit_inlier_fraction=float(inliers.mean()),
                  fit_distance_fraction_depth=scalar_stats(fit_errors/L),
                  checking_distance_fraction_depth=scalar_stats(distance),
                  checking_reprojection_pixels=scalar_stats(reprojection),
                  checking_negative_depths=negative,
                  shared_camera_center_distance_fraction_depth=scalar_stats(camera_error),
                  shared_camera_rotation_difference_degrees=scalar_stats(angles))
    reasons=[]
    if affine_bound_hit:reasons.append('affine_correction_bound_hit')
    if np.min(current['depth'])*depth_scale+depth_offset<=0:reasons.append('nonpositive_corrected_depth')
    if not .8<=depth_scale<=1.25:reasons.append('depth_scale_correction_outside_predeclared_bounds')
    if not .5<=model[0]<=2:reasons.append('local_scale_outside_predeclared_bounds')
    if np.percentile(distance,95)>.03:reasons.append('large_checking_3D_disagreement')
    if np.median(reprojection)>3 or negative:reasons.append('large_checking_reprojection_or_negative_depth')
    if np.median(camera_error)>.03:reasons.append('shared_camera_center_disagreement')
    if np.percentile(angles,95)>5:reasons.append('shared_camera_orientation_disagreement')
    report.update(qualified=not reasons,reasons=reasons)
    return model,report
