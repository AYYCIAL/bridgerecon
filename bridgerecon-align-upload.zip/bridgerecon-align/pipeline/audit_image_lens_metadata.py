"""Read image headers only to test the shared-lens hypothesis."""
from pathlib import Path
from datetime import datetime
import hashlib,json,time
from PIL import Image

BASE=Path(__file__).resolve().parent


def main():
    tic=time.monotonic();path=BASE/'data_audit/images.json';inventory=json.loads(path.read_text(encoding='utf-8'));records=[]
    for item in inventory:
        with Image.open(BASE.parent/item['file']) as im:
            exif=im.getexif();sub=exif.get_ifd(34665)
            def number(tag):
                value=sub.get(tag,exif.get(tag));return float(value) if value is not None else None
            serial=sub.get(42033,exif.get(42033))
            records.append({'index':item['index'],'model':str(exif.get(272,'')),'size':list(im.size),
                            'focal_mm':number(37386),'focal35_mm':number(41989),'digital_zoom':number(41988),
                            'body_serial_sha256':hashlib.sha256(str(serial).encode()).hexdigest() if serial else None})
    classes={json.dumps({k:v for k,v in r.items() if k!='index'},sort_keys=True) for r in records}
    report={'created':datetime.now().astimezone().isoformat(),'status':'completed','images':len(records),
            'inventory_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'classes':[json.loads(c) for c in sorted(classes)],
            'records':records,'shared_header_lens_hypothesis_supported':len(classes)==1,
            'limits':'Matching model/focal/zoom tags support an optical-sharing hypothesis, not independently calibrated intrinsics; absent serials do not prove one physical camera',
            'original_images_modified':False,'seconds':time.monotonic()-tic}
    dest=BASE/'data_audit/image_lens_metadata_20261019.json';dest.write_text(json.dumps(report,indent=2),encoding='utf-8');print(dest);print(report['classes']);print('seconds',report['seconds'])


if __name__=='__main__':main()
