"""Check against received native samples/observations before outcome scoring."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import hashlib,json,time
import numpy as np
from metashape_delivery_io import Delivery,RECEIPT,BASE
from metashape_geometry import rays,project_camera,camera_from_world,world_from_camera
from work_schedule import require_start_window


def main():
    require_start_window(300);start=time.monotonic()
    out=BASE/'runs'/('metashape_adapter_'+datetime.now(timezone(timedelta(hours=9))).strftime('%Y%m%d_%H%M%S'));out.mkdir()
    protocol={'fixed_before_checks':True,'sources':['https://www.agisoft.com/pdf/metashape_2_2_en.pdf','https://openexr.com/en/latest/python.html'],
              'geometry':'Agisoft manual2.2 AppendixD; image centers(col+.5,row+.5); camera Z positive forward; native p1/p2 order',
              'depth_array_conversion':'Native depth-calibration projection minus0.5 gives zero-origin NumPy array coordinates',
              'roundtrip_max_original_pixel_error':1e-7,'native_sample_Z_tolerance':0.,
              'sparse_native_RMS_expected_pixels':1.05001,'sparse_native_RMS_absolute_tolerance':.05,
              'metric_outcomes_used_to_choose_convention':False}
    (out/'protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    for name in ['validate_metashape_adapter.py','metashape_geometry.py','metashape_delivery_io.py']:(out/name).write_bytes((BASE/name).read_bytes())
    d=Delivery()
    result={'status':'running','protocol_sha256':hashlib.sha256((out/'protocol.json').read_bytes()).hexdigest(),'reference_access':False}
    try:
        native=json.loads((RECEIPT/'metadata/evidence/native_depth_samples.json').read_text(encoding='utf-8'))
        a=d.depth(native['camera_id'],0,out/'temporary.exr')
        errors=[abs(float(a[s['y'],s['x']])-s['native_depth_value']) for s in native['samples']]
        assert max(errors)==0
        mask=d.mask(native['camera_id'],0);assert np.array_equal(mask>0,np.isfinite(a)&(a>0))
        result.update(native_Z_samples=len(errors),native_Z_max_error=max(errors),native_mask_roundtrip_exact=True)
        del a,mask
        c=d.calibrations[0];u,v=np.meshgrid(np.linspace(.5,c['width']-.5,11),np.linspace(.5,c['height']-.5,9));uv=np.c_[u.ravel(),v.ravel()]
        r=rays(uv,c);back,z=project_camera(r,c);error=float(np.max(np.linalg.norm(back-uv,axis=1)));assert error<1e-7
        C=d.cameras[39]['C'];points=r*15;world=world_from_camera(points,C)
        assert np.max(abs(camera_from_world(world,C)-points))<1e-10
        result.update(project_unproject_grid_pixels=error,pose_roundtrip_internal_max=float(np.max(abs(camera_from_world(world,C)-points))))
        points=d.npz('chunk_000/sparse_observations/tie_points_internal.npz');observations=d.npz('chunk_000/sparse_observations/observations.npz')['observations']
        xyz=np.full((len(points['track_rgb']),3),np.nan)
        xyz[points['track_id']]=np.c_[points['x'],points['y'],points['z']]
        observations=observations[observations['has_reconstructed_3d']]
        residuals=[]
        for key,camera in d.cameras.items():
            selection=observations[observations['camera_id']==key]
            if not len(selection):continue
            pc=camera_from_world(xyz[selection['track_id']],camera['C']);uv,z=project_camera(pc,camera['calibration'])
            assert np.isfinite(uv).all() and (z>0).all()
            residuals.append(np.linalg.norm(uv-np.c_[selection['x'],selection['y']],axis=1))
        residual=np.concatenate(residuals);rms=float(np.sqrt(np.mean(residual**2)))
        result.update(sparse_observations=len(residual),native_sparse_reprojection_RMS_pixels=rms,
                      sparse_max_reprojection_pixels=float(residual.max()),native_report_expected_RMS_pixels=1.05001)
        assert abs(rms-1.05001)<.05,('Native sparse RMS mismatch',rms)
        result.update(status='passed',seconds=time.monotonic()-start,
                      scope='Adapter verified against eight native Z values, complete delivered mask for camera39, documented camera convention, and native reconstructed observations. Native sparse residual is fitted diagnostic, not independent quality evidence.')
    except Exception as exc:result.update(status='failed',error=repr(exc));raise
    finally:
        d.close();(out/'report.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        print(json.dumps(result),flush=True);print('REPORT',out,flush=True)


if __name__=='__main__':main()
