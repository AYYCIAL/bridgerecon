"""All-image connectivity survey, separate from frozen local assessment.

Uses every inventoried photo at reduced resolution. No PCD access, ground-truth
fit, dense reconstruction, or reuse as a held-out image evaluation model.
"""
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import time
import uuid

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
EXE = os.environ.get('COLMAP_EXE', 'colmap')


def group(i):
    return ('nadir' if i < 576 else 'south_oblique' if i < 579 else
            'north_oblique' if i < 582 else 'side_oblique' if i < 586 else 'side_nadir')


def pair_inventory(rows, sequence_radius=6, gps_neighbors=16):
    """GPS selects candidates only; it is never a camera/control constraint."""
    n = len(rows)
    lat = np.array([r['GpsLatitude'] for r in rows])
    lon = np.array([r['GpsLongitude'] for r in rows])
    xy = np.column_stack(((lon-lon.mean())*111320*np.cos(np.deg2rad(lat.mean())),
                          (lat-lat.mean())*111320))
    pairs = set()
    for i in range(n):
        for j in range(i+1, min(n, i+sequence_radius+1)):
            pairs.add((i, j))
        neighbors = np.argsort(np.sum((xy-xy[i])**2, axis=1), kind='stable')
        for j in [int(j) for j in neighbors if j != i][:gps_neighbors]:
            pairs.add(tuple(sorted((i, j))))
    # All special-view photos are tested against every photo, including the
    # omitted intermediate nadir views from the older 60-image survey.
    for i in range(576, n):
        for j in range(n):
            if i != j:
                pairs.add(tuple(sorted((i, j))))
    return sorted(pairs)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    start = time.perf_counter()
    rows = json.loads((ROOT/'experiments/data_audit/images.json').read_text(encoding='utf-8'))
    assert len(rows) == 588 and all(r['index'] == i for i, r in enumerate(rows))
    out = ROOT/'experiments/runs'/('full_route_survey_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
    out.mkdir(parents=True)
    report = {
        'status': 'preparing', 'scope': 'All 588 photos, 1600-pixel image-only sparse survey; no PCD registration or dense reconstruction',
        'independence': 'Uses all image features; separate from frozen reserved-correspondence experiments and not used to reevaluate them',
        'indices': list(range(len(rows))), 'images': [], 'stages': [], 'models': [],
        'settings': {'width': 1600, 'height': 1200, 'features': 4096, 'sequence_radius': 6,
                     'gps_neighbors': 16, 'special_views_match_all': True, 'mapper_limit_seconds': 1800,
                     'camera_model': 'SIMPLE_RADIAL', 'calibration': 'self calibration per image group; not certified'},
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'input_inventory_sha256': hashlib.sha256((ROOT/'experiments/data_audit/images.json').read_bytes()).hexdigest(),
        'reference_access': False,
    }

    def save():
        tmp = out/'report.tmp'
        tmp.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, out/'report.json')

    names = [f'{group(i)}/{i:04d}.jpg' for i in range(len(rows))]
    pairs = pair_inventory(rows)
    (out/'pairs.txt').write_text(''.join(f'{names[i]} {names[j]}\n' for i, j in pairs), encoding='ascii')
    report['candidate_pairs'] = len(pairs)
    print(json.dumps({'output': str(out), 'photos': len(rows), 'pairs': len(pairs)}, ensure_ascii=True), flush=True)
    save()
    if args.prepare_only:
        report['status'] = 'plan_only'; save(); return

    def resize_one(i):
        dest = out/'images'/names[i]
        dest.parent.mkdir(parents=True, exist_ok=True)
        with Image.open(ROOT/rows[i]['file']) as im:
            w, h = im.size
            assert abs(w/h-4/3) < .01, (i, w, h)
            im.convert('RGB').resize((1600, 1200), Image.Resampling.LANCZOS).save(dest, quality=95)
        sx, sy = 1600/w, 1200/h
        return {'index': i, 'name': names[i], 'source': rows[i]['file'],
                'original_to_input': [[sx, 0, .5*sx-.5], [0, sy, .5*sy-.5], [0, 0, 1]]}

    with ThreadPoolExecutor(max_workers=4) as pool:
        report['images'] = list(pool.map(resize_one, range(len(rows))))
    report['preprocessing_seconds'] = time.perf_counter()-start
    (out/'sparse').mkdir()
    (out/'snapshots').mkdir()
    report['status'] = 'running'; save()
    stages = [
        ('features', ['feature_extractor', '--database_path', 'database.db', '--image_path', 'images',
                      '--ImageReader.single_camera_per_folder', '1', '--ImageReader.camera_model', 'SIMPLE_RADIAL',
                      '--FeatureExtraction.use_gpu', '1', '--FeatureExtraction.num_threads', '4',
                      '--SiftExtraction.max_image_size', '1600', '--SiftExtraction.max_num_features', '4096']),
        ('matching', ['matches_importer', '--database_path', 'database.db', '--match_list_path', 'pairs.txt',
                      '--match_type', 'pairs', '--FeatureMatching.use_gpu', '1',
                      '--FeatureMatching.num_threads', '4', '--FeatureMatching.guided_matching', '1']),
        ('mapping', ['mapper', '--database_path', 'database.db', '--image_path', 'images', '--output_path', 'sparse',
                     '--Mapper.num_threads', '4', '--Mapper.max_runtime_seconds', '1800',
                     '--Mapper.snapshot_path', 'snapshots', '--Mapper.snapshot_frames_freq', '20']),
    ]
    try:
        for name, argv in stages:
            print('STAGE', name, flush=True)
            report['current_stage'] = name; save()
            stage_start = time.perf_counter()
            with (out/(name+'.log')).open('w', encoding='utf-8') as log:
                proc = subprocess.run([EXE]+argv, cwd=out, stdout=log, stderr=subprocess.STDOUT)
            report['stages'].append({'name': name, 'seconds': time.perf_counter()-stage_start,
                                     'exit_code': proc.returncode, 'command': [EXE]+argv})
            save()
            if proc.returncode:
                raise RuntimeError(f'{name} failed: {proc.returncode}')
            if name == 'features':
                with sqlite3.connect(out/'database.db') as db:
                    count = db.execute('SELECT COUNT(*) FROM keypoints WHERE rows>0').fetchone()[0]
                report['images_with_features'] = count; save()
                if count != len(rows):
                    raise RuntimeError(f'Feature records {count}/{len(rows)}')
        print('STAGE', 'coverage_export', flush=True)
        # Summarizer handles pycolmap through ASCII paths relative to the run.
        with (out/'coverage_export.log').open('w', encoding='utf-8') as log:
            exported = subprocess.run([sys.executable, str(ROOT/'experiments/summarize_coverage.py'), str(out)],
                                      cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        if exported.returncode:
            report['status'] = 'sparse_saved_export_failed'
            raise RuntimeError('Sparse models saved, CPU export failed; recover without recomputing COLMAP')
        summary = json.loads((out/'coverage_summary.json').read_text(encoding='utf-8'))
        summary['scope'] = report['scope']
        summary['input_photos'] = len(rows)
        summary['reference_access'] = False
        (out/'coverage_summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
        report['models'] = summary['models']
        report['unregistered'] = summary['unregistered']
        report['status'] = 'completed' if summary['models'] else 'no_model'
        if not summary['models']:
            raise RuntimeError('No sparse model')
    except BaseException as exc:
        if report['status'] != 'sparse_saved_export_failed':
            report['status'] = 'failed'
        report['error'] = repr(exc)
        raise
    finally:
        report['total_seconds'] = time.perf_counter()-start
        save()
    print(json.dumps({'output': str(out), 'status': report['status'],
                      'registered_per_model': [m['registered_images'] for m in report['models']]}, ensure_ascii=True), flush=True)


if __name__ == '__main__':
    main()
