"""CPU-only reuse of MASt3R matches for globally split side-photo PnP."""
from pathlib import Path
from datetime import datetime
import argparse,hashlib,json,os,subprocess,sys,time,uuid
import numpy as np
import cv2
from PIL import Image
from scipy.spatial import cKDTree
from geometry_core import camera_centers
from similarity import robust_similarity,apply_similarity
from local_validation import statistics
from budget_run import OwnedJob
from work_schedule import require_start_window

BASE=Path(__file__).resolve().parent
PREP=BASE/'runs/full_route_survey_20261018_221243_8084fdb4/hybrid_preparations/20261019_194608_05d2032e'
CACHE=BASE/'runs/d0_mast3r_connectivity_20261019_092520_1138a0b3'


def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,r):p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')


def nominal_positions(rows):
    lat=np.deg2rad([r['GpsLatitude'] for r in rows]);lon=np.deg2rad([r['GpsLongitude'] for r in rows]);alt=np.array([r['AbsoluteAltitude'] for r in rows])
    return np.c_[(lon-lon[0])*6378137*np.cos(np.mean(lat)),(lat-lat[0])*6378137,alt-alt[0]]


def cue(index,inventory):
    with Image.open(BASE.parent/inventory[index]['file']) as im:rgb=np.array(im.convert('RGB').resize((512,384),Image.Resampling.LANCZOS))
    r,g,b=rgb.astype(float).transpose(2,0,1);mask=(b-r>20)&(g-r>25)&(abs(g-b)<45)&(g>80)
    valid=int(mask.sum())>=100
    band=cv2.dilate(mask.astype('uint8'),cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(129,129))).astype(bool) if valid else np.ones_like(mask)
    return band,{'cue_pixels':int(mask.sum()),'qualified':valid,'radius_pixels':64}


def worker(out,transfer='nearest',preparation=PREP,matching_run=None):
    import torch
    started=time.monotonic();inventory=read(BASE/'data_audit/images.json');prep=read(preparation/'report.json');old=read(CACHE/'report.json')
    assert old['settings'].get('route_quarter_turns_counterclockwise',0)==0
    if 'route_quarter_turns_counterclockwise' not in old['settings']:
        assert 'rot90' not in (CACHE/'driver_source.py').read_text(encoding='utf-8')
    paths={i:str(BASE.parent/inventory[i]['file']) for i in old['indices']}
    if matching_run:
        matching=read(matching_run/'report.json');assert matching['status']=='completed'
        pair_records=matching['pairs'];sources=sorted({p['source'] for p in pair_records});targets=sorted({p['target'] for p in pair_records})
    else:
        sources=[408,420,586,587];targets=[582,583];pair_records=[{'source':s,'target':t} for t in targets for s in sources]
    positions=nominal_positions(inventory);groups=[[576,577,578],[579,580,581],[582,583,584,585]]
    gps=[]
    for ids in groups:
        points=positions[ids];baseline=float(np.linalg.norm(points[:,None]-points[None],axis=2).max())
        gps.append({'indices':ids,'nominal_maximum_baseline_metres':baseline,
                    'pitch_degrees':[inventory[i]['GimbalPitchDegree'] for i in ids],
                    'position_accuracy':'Unknown; nominal EXIF separation is not a calibrated baseline'})
    global_data=dict(np.load(preparation/'global_cameras.npz'));main=global_data['image_indices']<576
    center=camera_centers(global_data['extrinsics'][main]);enu=positions[global_data['image_indices'][main]]
    gps_model,gps_inliers,_=robust_similarity(center,enu,.01*np.ptp(enu,axis=0).max(),seed=20261019)
    residual=np.linalg.norm(apply_similarity(center,gps_model)-enu,axis=1)
    camera=prep['native_cameras']['1'];p=camera['params'];A=np.array([[512/1600,0,-.5],[0,384/1200,-.5],[0,0,1.]])
    K=A@np.array([[p[0],0,p[1]],[0,p[0],p[2]],[0,0,1.]])
    dist=np.array([p[3],0,0,0,0.]);cv2.setNumThreads(4);cv2.setRNGSeed(20261019)
    report={'status':'matching_anchors','created':datetime.now().astimezone().isoformat(),'reference_access':False,'gpu_used':False,
            'cache':str(CACHE),'preparation':str(preparation),'nominal_station_audit':gps,'pairs':[],'targets':[],
            'gps_source_fit_median_metres':float(np.median(residual)),'gps_source_fit_p95_metres':float(np.percentile(residual,95)),
            'gps_warning':'Uncalibrated navigation positions used only as a rough diagnostic, not reference accuracy',
            'fitting_scope':'Global training IDs only; original SfM initializer reused checking tracks',
            'intrinsics_assumption':'Global SfM main SIMPLE_RADIAL camera, not independently calibrated','anchor_transfer':transfer,
            'source_cache_report_sha256':sha(CACHE/'report.json'),'preparation_report_sha256':sha(preparation/'report.json'),
            'matching_run':str(matching_run) if matching_run else None,'matching_report_sha256':sha(matching_run/'report.json') if matching_run else None}
    write(out/'report.json',report)
    records={v['index']:v for v in prep['views']};source_data={};masks={}
    for index in sorted(set(sources+targets)):masks[index]=cue(index,inventory)
    for index in sources:
        a=dict(np.load(preparation/records[index]['file']));T=A@np.linalg.inv(a['native_to_input'])
        train=a['train_eligible'];uv=np.r_[a['train_uv'][train],a['checking_uv']];xyz=np.r_[a['train_xyz'][train],a['checking_xyz']]
        ids=np.r_[a['train_ids'][train],a['checking_ids']];roles=np.r_[np.zeros(train.sum(),bool),np.ones(len(a['checking_ids']),bool)]
        uv=uv@T[:2,:2].T+T[:2,2];good=np.isfinite(xyz).all(axis=1)
        source_data[index]=(cKDTree(uv[good]),ids[good],xyz[good],roles[good])
    candidates={i:[] for i in targets}
    for pair_record in pair_records:
            source=pair_record['source'];target=pair_record['target']
            if matching_run:
                cache=matching_run/pair_record['file'];assert sha(cache)==pair_record['sha256']
                with np.load(cache) as pair:uv1=pair['source_uv'];uv2=pair['target_uv']
            else:
                a,b=sorted([source,target],key=old['indices'].index)
                first=hashlib.md5(paths[a].encode()).hexdigest();second=hashlib.md5(paths[b].encode()).hexdigest()
                cache=CACHE/'cache/corres_conf=desc_conf_subsample=8'/f'{first}-{second}.pth'
                score,(left,right,confidence)=torch.load(cache,map_location='cpu',weights_only=False)
                uv1,uv2=np.asarray(left),np.asarray(right)
                if a!=source:uv1,uv2=uv2,uv1
            tree,ids,xyz,roles=source_data[source]
            if transfer=='nearest':
                distance,nearest=tree.query(uv1);good=distance<=2
            else:
                from anchor_match_transfer import local_affine
                uv2,good,distance=local_affine(uv1,uv2,tree.data)
                uv1=tree.data;nearest=np.arange(len(ids))
            good=good&np.isfinite(uv2).all(axis=1)&(uv2[:,0]>=3)&(uv2[:,0]<509)&(uv2[:,1]>=3)&(uv2[:,1]<381)
            pair={'source':source,'target':target,'cached_matches':len(uv1),'near_global_anchors':int(good.sum()),'cache_sha256':sha(cache)}
            report['pairs'].append(pair)
            for i in np.where(good)[0]:
                n=nearest[i];u=uv1[i];v=uv2[i]
                bridge=bool(masks[source][0][int(u[1]),int(u[0])] and masks[target][0][int(v[1]),int(v[0])])
                candidates[target].append({'id':int(ids[n]),'xyz':xyz[n].tolist(),'uv':v.tolist(),'distance':float(distance[i]),'checking':bool(roles[n]),'bridge':bridge})
    write(out/'fixed_candidates.json',candidates);report['fixed_candidates_sha256']=sha(out/'fixed_candidates.json')
    report['status']='fitting_pose';write(out/'report.json',report)
    for target,raw in candidates.items():
        for variant in ['all','cue_band']:
            selected=[c for c in raw if variant=='all' or c['bridge']];byid={}
            for c in selected:byid.setdefault(c['id'],[]).append(c)
            merged=[]
            for pid,group in sorted(byid.items()):
                uv=np.array([g['uv'] for g in group]);median=np.median(uv,axis=0)
                if np.max(np.linalg.norm(uv-median,axis=1))>5:continue
                merged.append({**group[0],'uv':median.tolist(),'distance':float(np.mean([g['distance'] for g in group]))})
            cells={}
            for c in sorted(merged,key=lambda c:(c['distance'],c['id'])):
                key=tuple((np.array(c['uv'])//2).astype(int));cells.setdefault(key,c)
            merged=list(cells.values());training=[c for c in merged if not c['checking']];checking=[c for c in merged if c['checking']]
            item={'target':target,'variant':variant,'training_candidates':len(training),'checking_candidates':len(checking),
                  'cue':masks[target][1],'qualified_numeric_pose':False,'reasons':[]}
            report['targets'].append(item)
            if len(training)<30:item['reasons']=['insufficient_training_correspondences'];continue
            obj=np.array([c['xyz'] for c in training],float);uv=np.array([c['uv'] for c in training],float)
            cv2.setRNGSeed(20261019)
            success,rvec,tvec,inliers=cv2.solvePnPRansac(obj,uv,K,dist,iterationsCount=10000,reprojectionError=4.,confidence=.999,flags=cv2.SOLVEPNP_EPNP)
            ids=inliers.ravel() if inliers is not None else np.array([],int);item['training_inliers']=len(ids)
            if not success or len(ids)<20 or len(ids)/len(training)<.25:item['reasons']=['insufficient_training_pose_inliers'];continue
            rvec,tvec=cv2.solvePnPRefineLM(obj[ids],uv[ids],K,dist,rvec,tvec)
            R=cv2.Rodrigues(rvec)[0];E=np.c_[R,tvec.ravel()];center=-R.T@tvec.ravel()
            singular=np.linalg.svd(obj[ids]-obj[ids].mean(axis=0),compute_uv=False)
            item['training_point_singular_ratios']=(singular/singular[0]).tolist()
            item['pose_file']=f'pose_{target}_{variant}.npz';np.savez_compressed(out/item['pose_file'],extrinsics=E,intrinsics=K,distortion=dist)
            inferred=apply_similarity(center[None],gps_model)[0]
            forward=gps_model[1]@R.T[:,2]
            yaw=np.deg2rad(inventory[target]['GimbalYawDegree']);pitch=np.deg2rad(inventory[target]['GimbalPitchDegree'])
            expected=np.array([np.sin(yaw)*np.cos(pitch),np.cos(yaw)*np.cos(pitch),np.sin(pitch)])
            item['nominal_gps_position_difference_metres']=float(np.linalg.norm(inferred-positions[target]))
            item['nominal_gimbal_view_direction_difference_degrees']=float(np.rad2deg(np.arccos(np.clip(forward@expected,-1,1))))
            if len(checking)<10:item['reasons'].append('insufficient_checking_correspondences')
            else:
                check_obj=np.array([c['xyz'] for c in checking]);check_uv=np.array([c['uv'] for c in checking]);pixel,_=cv2.projectPoints(check_obj,rvec,tvec,K,dist)
                error=np.linalg.norm(pixel.reshape(-1,2)-check_uv,axis=1);z=(check_obj@R.T+tvec.ravel())[:,2]
                item['checking_reprojection_pixels']=statistics(error);item['checking_positive_depth_fraction']=float((z>0).mean())
                np.savez_compressed(out/f'checking_{target}_{variant}.npz',ids=np.array([c['id'] for c in checking]),errors=error,positive_z=z>0)
                if np.median(error)>3 or np.percentile(error,95)>8 or np.any(z<=0):item['reasons'].append('checking_pose_disagreement')
            if singular[1]/singular[0]<1e-3:item['reasons'].append('nearly_collinear_training_geometry')
            item['qualified_numeric_pose']=not item['reasons']
    report.update(status='completed',seconds=time.monotonic()-started,
                  fixed_candidates_unchanged=sha(out/'fixed_candidates.json')==report['fixed_candidates_sha256'],
                  qualification_scope='Numeric PnP candidacy only; not a physical shared-surface certificate')
    write(out/'report.json',report);print('REPORT',out,flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--worker',action='store_true');p.add_argument('--out',type=Path)
    p.add_argument('--transfer',choices=['nearest','local_affine'],default='nearest');p.add_argument('--preparation',type=Path,default=PREP)
    p.add_argument('--matching-run',type=Path);args=p.parse_args()
    if args.worker:worker(args.out.resolve(),args.transfer,args.preparation.resolve(),args.matching_run.resolve() if args.matching_run else None);return
    require_start_window(600)
    out=BASE/'runs'/('cached_side_pnp_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir()
    (out/'driver_source.py').write_bytes(Path(__file__).read_bytes())
    (out/'anchor_match_transfer.py').write_bytes((BASE/'anchor_match_transfer.py').read_bytes())
    env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='-1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',PYTHONIOENCODING='utf-8')
    with (out/'worker.log').open('w',encoding='utf-8') as log:
        command=[sys.executable,'-u',str(Path(__file__).resolve()),'--worker','--out',str(out),'--transfer',args.transfer,'--preparation',str(args.preparation)]
        if args.matching_run:command.extend(['--matching-run',str(args.matching_run)])
        child=subprocess.Popen(command,cwd=BASE.parent,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW);owned=OwnedJob(child)
        try:code=child.wait(timeout=540)
        except subprocess.TimeoutExpired:owned.terminate();child.wait(timeout=15);raise
        finally:owned.close()
    print('REPORT',out)
    if code:print((out/'worker.log').read_text(encoding='utf-8',errors='replace')[-3000:]);raise SystemExit(code)


if __name__=='__main__':main()
