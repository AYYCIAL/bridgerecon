"""Summarize camera controls (e.g. RTK-weighted BA) with the v0.41 measures.

For each --case LABEL=<global_hybrid run>: intrinsics and BA solver state, camera centres against
RTK, cross-view discrepancy on the fixed pair inventory (with a route-block bootstrap of the
difference to the primary C5 V3), and depth at the principal point against the rangefinder.
CPU only; reads frozen outputs; writes runs/revision_v042_rtk_<stamp>/report.json.
"""
from pathlib import Path
from datetime import datetime
import argparse, csv, json, sys, time
import numpy as np

BASE = Path(__file__).resolve().parent; ROOT = BASE.parent; RUNS = BASE / 'runs'
sys.path.insert(0, str(BASE))
from revision_v041_analysis import PRIMARY, MVS, block_histograms, quantile_from_hist, stats  # noqa: E402
from revision_v041_lrf_check import enu, umeyama, tin_centre  # noqa: E402
from local_validation import sample  # noqa: E402


def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))


def summarize(label, run, lrf_rows, flat, rtk, ref):
    rep = read(run / 'report.json'); prep_dir = Path(rep['preparation']); prep = read(prep_dir / 'report.json')
    control = Path(prep['camera_control_source']) if prep.get('camera_control_source') else None
    ctrl = read(control / 'report.json') if control else {}
    out = {'run': str(run.relative_to(BASE)), 'preparation': str(prep_dir), 'camera_control': str(control) if control else None,
           'main_camera': prep['native_cameras'][str(min(v['camera_id'] for v in prep['views'] if v['index'] < 576))],
           'solver': (ctrl.get('solver') or {}).get('brief'), 'prior_sigma_h_m': ctrl.get('navigation_standard_deviation_assumption_metres'),
           'prior_sigma_v_m': ctrl.get('height_standard_deviation_assumption_metres'), 'withheld_rtk_deviation_m': ctrl.get('withheld_navigation_error'),
           'training_reprojection_px': ctrl.get('training_reprojection_pixels'), 'view_scale_acceptances': rep.get('actual_view_scale_acceptances')}
    # Camera centres against RTK after one similarity (576 main-route photographs).
    g = np.load(prep_dir / 'global_cameras.npz'); E, idx = g['extrinsics'], g['image_indices']; sel = idx < 576; order = np.argsort(idx[sel])
    C = -np.einsum('nji,nj->ni', E[sel][order][:, :, :3], E[sel][order][:, :, 3]); s, R, t = umeyama(C, rtk); d = (s * (R @ C.T)).T + t - rtk
    out['camera_centres_vs_rtk'] = {'residual_3d_m': stats(np.linalg.norm(d, axis=1)), 'horizontal_m': stats(np.linalg.norm(d[:, :2], axis=1)), 'vertical_abs_m': stats(abs(d[:, 2]))}
    # Cross-view discrepancy on the identical inventory.
    p = np.load(run / 'checking_pairs.npz'); assert np.array_equal(p['source'], ref['source']) and np.array_equal(p['target'], ref['target'])
    e, ok = p['errors'][:, 3], p['supported'][:, 3]; full = len(e)
    common = ok & ref['supported']
    out['v3'] = {'support': float(ok.mean()), 'success_below2px': float(np.sum(ok & (e < 2)) / full), 'own': stats(e[ok]), 'common_with_C5_V3': stats(e[common]), 'C5_V3_on_common': stats(ref['errors'][common])}
    block = ref['view'][ref['source']] // 8; edges = np.geomspace(1e-3, 1e3, 6001); rng = np.random.default_rng(20261023)
    w = np.stack([np.bincount(rng.integers(0, 72, 72), minlength=72) for _ in range(2000)]).astype(float)
    a = quantile_from_hist(w @ block_histograms(e, common, block, edges), edges, .5); b = quantile_from_hist(w @ block_histograms(ref['errors'], common, block, edges), edges, .5)
    out['v3']['median_minus_C5_V3'] = {'point': float(np.median(e[common]) - np.median(ref['errors'][common])), 'ci95': np.percentile(a - b, [2.5, 97.5]).tolist()}
    # Depth at the principal point against the rangefinder (same definitions as v0.41).
    views = {v['index']: v for v in prep['views']}; owner = {}
    for c in rep['chunks']:
        for slot, i in enumerate(c['image_indices']): owner.setdefault(i, (c, slot))
    centre = np.array([800 * (518 / 1600) - 0.5, 600 * (392 / 1200) - 0.5]); cache = {}; v3 = np.full(576, np.nan); a3 = np.full(576, np.nan); a1 = np.full(576, np.nan)
    for i in range(576):
        an = np.load(prep_dir / views[i]['file']); use = an['train_eligible'] & np.isfinite(an['train_z']) & (an['train_z'] > 0)
        a1[i] = np.median(an['train_z'][use]); a3[i] = tin_centre(an['train_uv'][use], an['train_z'][use], centre)
        c, slot = owner[i]
        if c['input'] not in cache: cache = {c['input']: np.load(c['input'])['depth']}
        dep = float(sample(cache[c['input']][slot, ..., 0], centre[None])[0])
        v3[i] = dep * c['similarity']['scale'] * c['depth_fit']['views'][slot]['applied_scale'] if dep > 0 else np.nan
    L = lrf_rows; res = {}
    for name, v in [('V3', v3), ('A3', a3), ('A1', a1)]:
        for scope, m in [('all', np.isfinite(L)), ('flat', np.isfinite(L) & flat)]:
            gd = m & np.isfinite(v); ratio = v[gd] / L[gd]; resid = abs((ratio / np.median(ratio) - 1) * L[gd])
            res[f'{name}/{scope}'] = {'n': int(gd.sum()), 'bias_pct': float((np.median(ratio) - 1) * 100), 'scatter_median_m': float(np.median(resid)), 'scatter_p95_m': float(np.percentile(resid, 95))}
    out['centre_depth_vs_lrf'] = res
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--case', action='append', required=True, help='LABEL=path to a global_hybrid run'); args = ap.parse_args()
    tic = time.monotonic(); out = RUNS / ('revision_v042_rtk_' + datetime.now().strftime('%Y%m%d_%H%M%S')); out.mkdir()
    (out / 'revision_v042_rtk_analysis.py').write_bytes(Path(__file__).read_bytes())
    lrf_run = sorted(RUNS.glob('revision_v041_lrf_*'))[-1]; rows = list(csv.DictReader((lrf_run / 'per_image_centre_depths.csv').open(encoding='utf-8')))
    L = np.array([float(r['lrf_m']) if r['lrf_m'] not in ('', 'None') else np.nan for r in rows])
    flat = np.array([r['MVS_window_range_m'] not in ('', 'None') and float(r['MVS_window_range_m']) < 1.0 for r in rows])
    img = read(BASE / 'data_audit/images.json'); lat = np.array([r['GpsLatitude'] for r in img]); lon = np.array([r['GpsLongitude'] for r in img]); alt = np.array([r['AbsoluteAltitude'] for r in img])
    rtk = enu(lat, lon, alt, lat[0], lon[0], alt[0])[:576]
    p = np.load(PRIMARY / 'checking_pairs.npz'); s = np.load(PRIMARY / 'checking_samples.npz')
    ref = {'source': p['source'], 'target': p['target'], 'errors': p['errors'][:, 3], 'supported': p['supported'][:, 3], 'view': s['view']}
    report = {'status': 'running', 'created': datetime.now().astimezone().isoformat(), 'gpu_used': False, 'reference_primary': str(PRIMARY.relative_to(BASE)), 'lrf_run': lrf_run.name, 'cases': {}}
    for spec in args.case:
        label, path = spec.split('=', 1); report['cases'][label] = summarize(label, Path(path).resolve(), L, flat, rtk, ref)
    report.update(status='completed', seconds=time.monotonic() - tic)
    (out / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding='utf-8'); print('REPORT', out)


if __name__ == '__main__':
    main()
