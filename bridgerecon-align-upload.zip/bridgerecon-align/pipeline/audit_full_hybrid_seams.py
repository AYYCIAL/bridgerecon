"""All adjacent full-route seams, fixed training-depth normalizer and grid."""
from pathlib import Path
from datetime import datetime
import hashlib,json,time,uuid
import numpy as np
from global_hybrid_geometry import VARIANTS,unproject_native
from route_chunk_geometry import serialize
from local_validation import unproject,statistics
from similarity import apply_similarity
from work_schedule import require_start_window

BASE=Path(__file__).resolve().parent
INPUT=BASE/'runs/global_hybrid_20261019_205203_28fc26c6'

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,r):p.write_text(json.dumps(r,indent=2),encoding='utf-8')


def main():
    require_start_window(1200);tic=time.monotonic();r=read(INPUT/'report.json');fixed=read(INPUT/'frozen_parameters.json')
    assert r['status']=='completed' and r['parameters_unchanged_after_checking'] and sha(INPUT/'frozen_parameters.json')==r['frozen_parameters_sha256']
    prep=Path(r['preparation']);metadata=read(prep/'report.json');records={v['index']:v for v in metadata['views']};cameras=read(prep/'native_cameras.json')
    out=BASE/'runs'/('full_hybrid_seams_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir()
    (out/'driver_source.py').write_bytes(Path(__file__).read_bytes())
    chunks=fixed['chunks'];seams=[];all_values=[];count=0;all_supported=0;slots=0
    manifest=[]
    for a,b in zip(chunks,chunks[1:]):manifest.append({'starts':[a['start'],b['start']],'common_images':sorted(set(a['image_indices'])&set(b['image_indices']))})
    write(out/'fixed_seam_inventory.json',{'seams':manifest,'grid_start_xy':[2,2],'stride':8,'minimum_confidence':1.2,'reference_access':False,'outcome_selection':False})
    for seam,a,b in zip(manifest,chunks,chunks[1:]):
        require_start_window(120)
        da=np.load(a['input']);db=np.load(b['input']);data_a={k:da[k] for k in ['depth','depth_conf','extrinsics','intrinsics']};da.close()
        data_b={k:db[k] for k in ['depth','depth_conf','extrinsics','intrinsics']};db.close()
        h,w=data_a['depth'].shape[1:3];yy,xx=np.mgrid[2:h-2:8,2:w-2:8];uv=np.c_[xx.ravel(),yy.ravel()];samples=[];inventory_samples=0;supported_samples=0
        for index in seam['common_images']:
            slots+=1;anchor=dict(np.load(prep/records[index]['file']));E=anchor['extrinsics'];camera=cameras[str(int(anchor['camera_id']))];A=anchor['native_to_input']
            train=anchor['train_z'];normalizer=float(np.median(train[np.isfinite(train)&(train>0)]));assert normalizer>0
            xyz=[];zs=[];support=np.ones(len(uv),bool)
            for row,data in [(a,data_a),(b,data_b)]:
                j=row['image_indices'].index(index);depth=data['depth'][j,yy,xx,0].ravel();confidence=data['depth_conf'][j,yy,xx].ravel()
                m=row['similarity'];model=(m['scale'],np.array(m['rotation']),np.array(m['translation']));fit=row['depth_fit']
                points=[apply_similarity(unproject(uv,depth,data['extrinsics'][j],data['intrinsics'][j]),model)]
                for scale in [1.,fit['chunk_scale'],fit['views'][j]['applied_scale']]:points.append(unproject_native(uv,m['scale']*scale*depth,E,camera,A))
                points=np.stack(points,axis=1);z=(points@E[:,:3].T+E[:,3])[...,2]
                support&=(confidence>=1.2)&np.isfinite(points).all(axis=(1,2))&(z>0).all(axis=1)&(depth>0)
                xyz.append(points)
            values=np.linalg.norm(xyz[0]-xyz[1],axis=2)/normalizer
            samples.append(values[support]);inventory_samples+=len(uv);supported_samples+=int(support.sum())
        values=np.concatenate(samples);all_values.append(values);count+=inventory_samples;all_supported+=supported_samples
        result={v:{**statistics(values[:,k]),'below1pct_fraction':float((values[:,k]<.01).mean()),'below3pct_fraction':float((values[:,k]<.03).mean()),'below5pct_fraction':float((values[:,k]<.05).mean())} for k,v in enumerate(VARIANTS)}
        seams.append({**seam,'fixed_grid_samples':inventory_samples,'common_supported_samples':supported_samples,'support_fraction':supported_samples/inventory_samples,'metrics':result})
        print('SEAM',seam['starts'],supported_samples,flush=True);del data_a,data_b
    full=np.concatenate(all_values);np.savez_compressed(out/'seam_normalized_differences.npz',values=full)
    metrics={v:statistics(full[:,k]) for k,v in enumerate(VARIANTS)}
    report={'status':'completed','created':datetime.now().astimezone().isoformat(),'input':str(INPUT),'input_report_sha256':sha(INPUT/'report.json'),
            'frozen_parameters_sha256':sha(INPUT/'frozen_parameters.json'),'seams':seams,'seam_count':len(seams),'repeated_image_slots':slots,
            'fixed_grid_samples':count,'common_supported_samples':all_supported,'support_fraction':all_supported/count,'metrics':metrics,
            'median_improved_seams_against_raw':{v:sum(s['metrics'][v]['median']<s['metrics'][VARIANTS[0]]['median'] for s in seams) for v in VARIANTS},
            'p95_improved_seams_against_raw':{v:sum(s['metrics'][v]['p95']<s['metrics'][VARIANTS[0]]['p95'] for s in seams) for v in VARIANTS},
            'reference_access':False,'gpu_used':False,'independent_bridges':1,'seconds':time.monotonic()-tic,
            'normalizer':'Per-view positive training-anchor median depth, fixed across four variants; no checking depth access',
            'scope':'Cross-context consistency of shared photos and shared anchors; not physical accuracy or original free-chain gate qualification'}
    assert sha(INPUT/'frozen_parameters.json')==r['frozen_parameters_sha256'];write(out/'report.json',report)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    for k,variant in enumerate(VARIANTS):
        q=np.linspace(0,1,501);axes[0].plot(np.quantile(full[:,k],q)*100,q,label=variant.replace('_',' '))
        axes[1].plot(np.arange(1,len(seams)+1),[s['metrics'][variant]['p95']*100 for s in seams],lw=1,label=variant.replace('_',' '))
    axes[0].set(xlim=(0,15),ylim=(0,1),xlabel='3D discrepancy / fixed training depth (%)',ylabel='Common-support cumulative fraction')
    axes[1].set(xlabel='Adjacent seam in fixed route order',ylabel='P95 discrepancy / fixed training depth (%)',yscale='log')
    for ax in axes:ax.grid(alpha=.2);ax.legend(fontsize=7)
    fig.suptitle('71 shared-photo seams: conditional consistency, no measured reference')
    fig.savefig(out/'full_route_seams.png',dpi=180);fig.savefig(out/'full_route_seams.pdf');plt.close(fig)
    print('REPORT',out,flush=True)


if __name__=='__main__':main()
