"""Reuse saved matching database; periodically persist mapping snapshots.

Launch through budget_run.py only. --prepare-only does not run COLMAP. A saved
snapshot is a partial reconstruction, not a completed all-photo result.
"""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import json
import os
import struct
import subprocess
import time
import uuid
from work_schedule import require_start_window

ROOT = Path(__file__).resolve().parent.parent
EXE = os.environ.get('COLMAP_EXE', 'colmap')
REQUIRED = ('cameras.bin', 'images.bin', 'points3D.bin')


def saved_models(run):
    candidates = []
    # Do not read image JPEGs or unrelated historical experiments.
    for base in (run/'sparse', run/'snapshots', run/'mapping_attempts'):
        if not base.exists():
            continue
        for images_file in base.rglob('images.bin'):
            model = images_file.parent
            if all((model/n).is_file() and (model/n).stat().st_size >= 8 for n in REQUIRED):
                with images_file.open('rb') as stream:
                    count = struct.unpack('<Q', stream.read(8))[0]
                if 2 <= count <= 588:
                    candidates.append((count, model.stat().st_mtime_ns, model))
    return sorted(candidates, reverse=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source_run')
    parser.add_argument('--mapping-seconds', type=int, default=3600)
    parser.add_argument('--snapshot-frames', type=int, default=20)
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--exe', type=Path, default=Path(EXE))
    parser.add_argument('--runtime-bin', type=Path)
    parser.add_argument('--gpu-ba', action='store_true')
    parser.add_argument('--num-threads', type=int, default=4)
    parser.add_argument('--ba-function-tolerance',type=float)
    parser.add_argument('--ba-global-iterations',type=int)
    parser.add_argument('--ba-global-refinements',type=int)
    parser.add_argument('--ba-global-frames-ratio',type=float)
    parser.add_argument('--ba-global-points-ratio',type=float)
    args = parser.parse_args()
    exe=str(args.exe.resolve())
    env=os.environ.copy()
    if args.runtime_bin:
        env['PATH']=str(args.runtime_bin.resolve())+';'+env['PATH']
    if args.mapping_seconds <= 0 or args.snapshot_frames <= 0 or args.num_threads<=0:
        parser.error('Positive limits required')
    if args.ba_function_tolerance is not None and args.ba_function_tolerance<0:
        parser.error('Nonnegative function tolerance required')
    if any(v is not None and v<=0 for v in (args.ba_global_iterations,args.ba_global_refinements)):
        parser.error('Positive iteration/refinement limits required')
    if args.ba_global_frames_ratio is not None and args.ba_global_frames_ratio<=1:
        parser.error('Global frame ratio must exceed one')
    if args.ba_global_points_ratio is not None and args.ba_global_points_ratio<=1:
        parser.error('Global point ratio must exceed one')
    source = Path(args.source_run).resolve()
    source.relative_to(ROOT/'experiments/runs')
    metadata = json.loads((source/'report.json').read_text(encoding='utf-8'))
    assert len(metadata['images']) == 588
    assert (source/'database.db').is_file() and (source/'images').is_dir()
    previous = saved_models(source)
    seed = previous[0][2] if previous else None
    folder = source/'mapping_attempts'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
    folder.mkdir(parents=True)
    (folder/'driver_source.py').write_bytes(Path(__file__).read_bytes())
    (folder/'sparse').mkdir(); (folder/'snapshots').mkdir()
    def relative(p):
        return p.relative_to(source).as_posix()
    command = [exe, 'mapper', '--database_path', 'database.db', '--image_path', 'images',
               '--output_path', relative(folder/'sparse'), '--Mapper.num_threads', str(args.num_threads),
               '--Mapper.max_runtime_seconds', str(args.mapping_seconds),
               '--Mapper.snapshot_path', relative(folder/'snapshots'),
               '--Mapper.snapshot_frames_freq', str(args.snapshot_frames)]
    if args.gpu_ba:
        command += ['--Mapper.ba_use_gpu','1']
    optional_settings={'ba_global_function_tolerance':args.ba_function_tolerance,
                       'ba_global_max_num_iterations':args.ba_global_iterations,
                       'ba_global_max_refinements':args.ba_global_refinements,
                       'ba_global_frames_ratio':args.ba_global_frames_ratio,
                       'ba_global_points_ratio':args.ba_global_points_ratio}
    for key,value in optional_settings.items():
        if value is not None:command += ['--Mapper.'+key,str(value)]
    if seed:
        # Validate readability with the installed native COLMAP before fitting.
        # model_analyzer receives ASCII relative paths under the same run.
        command += ['--input_path', relative(seed)]
    report = {
        'status': 'prepared', 'source_run': str(source), 'command': command,
        'input_model': str(seed) if seed else None,
        'initial_saved_cameras': previous[0][0] if previous else 0,
        'runtime_bin':str(args.runtime_bin.resolve()) if args.runtime_bin else None,
        'gpu_ba_requested':args.gpu_ba,
        'incremental_optimizer_overrides':{k:v for k,v in optional_settings.items() if v is not None},
        'quality_scope':'Coverage mapping; any reduced incremental settings require declared final refinement before accuracy comparisons',
        'reuse': 'All 588 image features and verified pair matches; no feature extraction or matching repeated',
        'resume_limitation': 'No previous saved model: mapping restarts from cached matches' if seed is None else 'Continues a saved image-only model',
        'images': metadata['images'], 'preprocessing_seconds': 0,
        'reference_access': False, 'stages': [],
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    def save():
        temporary = folder/'report.tmp'
        temporary.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(temporary,folder/'report.json')
    save()
    print(json.dumps({'attempt':str(folder),'status':report['status'],
                      'input_model':str(seed) if seed else None},ensure_ascii=True),flush=True)
    if args.prepare_only:
        return
    # Inner mapper may overrun its nominal timer while optimizing; the parent
    # executor must allow margin and enforce the actual daily deadline.
    require_start_window(args.mapping_seconds+180)
    start=time.perf_counter()
    try:
        if seed:
            with (folder/'input_validation.log').open('w',encoding='utf-8') as log:
                checked=subprocess.run([exe,'model_analyzer','--path',relative(seed)],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
            if checked.returncode:
                raise RuntimeError('Saved input model failed native validation')
        report['status']='mapping';save()
        with (folder/'mapping.log').open('w',encoding='utf-8') as log:
            proc=subprocess.run(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
        report['stages'].append({'name':'mapping','exit_code':proc.returncode,'seconds':time.perf_counter()-start})
        written=saved_models(folder)
        # saved_models accepts a nested attempt as well: it scans sparse and
        # snapshots directly; no dependence on COLMAP's exit status alone.
        report['saved_models']=[{'path':str(p),'header_registered_images':n} for n,_,p in written]
        if not written:
            raise RuntimeError('No readable model-header files saved; do not count this as completed reconstruction')
        best=written[0][2]
        with (folder/'output_validation.log').open('w',encoding='utf-8') as log:
            validated=subprocess.run([exe,'model_analyzer','--path',relative(best)],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
        if validated.returncode:
            raise RuntimeError('Best saved model failed native validation')
        report['best_saved_model']=str(best)
        report['best_saved_registered_images']=written[0][0]
        report['status']='saved_partial_or_final' if proc.returncode==0 else 'saved_checkpoint_after_failure'
    except BaseException as exc:
        report['status']='failed';report['error']=repr(exc)
        raise
    finally:
        report['total_seconds']=time.perf_counter()-start
        save()


if __name__=='__main__':
    main()
