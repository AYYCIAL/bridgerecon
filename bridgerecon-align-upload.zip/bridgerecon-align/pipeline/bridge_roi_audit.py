"""Case-specific image-only bridge-envelope screening, not a static-object mask.

Turquoise walkway paint is an observed cue in this dataset, not a generic bridge
detector or a measured structural boundary. No reconstruction residuals or PCD.
"""
from pathlib import Path
from datetime import datetime
import json,time
import numpy as np
import cv2
from scipy.optimize import least_squares
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE=Path(__file__).resolve().parent
SOURCE=BASE/'runs/d0_ordinary_ba_20261018_110415'
SETTINGS={'scope':'D0 image-only painted-strip envelope; not a semantic static mask or physical width',
    'source':str(SOURCE),'minimum_blue_minus_red':20,'minimum_green_minus_red':25,
    'maximum_abs_green_minus_blue':45,'minimum_green':80,
    'component_minimum_height_fraction':.55,'component_minimum_area_pixels':100,
    'row_minimum_colored_pixels':2,'minimum_supported_row_fraction':.55,
    'minimum_vertical_support_span_fraction':.8,'line_fit_robust_scale_pixels':1.5,
    'maximum_fit_p95_pixels':4.,'outer_margin_pixels':3.,
    'minimum_strip_separation_fraction':.1,'maximum_strip_separation_fraction':.6,
    'reference_access':False,'residual_access':False,'mask_warning':'May retain vehicles and cables; may exclude occluded or unpainted structure'}


def fit_strips(rgb):
    h,w=rgb.shape[:2];r,g,b=rgb.astype(float).transpose(2,0,1)
    colored=(b-r>20)&(g-r>25)&(abs(g-b)<45)&(g>80)
    # Close only small gaps; retain raw-color support for fitting.
    closed=cv2.morphologyEx(colored.astype('uint8'),cv2.MORPH_CLOSE,np.ones((7,3),np.uint8))
    count,labels,stats,centers=cv2.connectedComponentsWithStats(closed,8)
    eligible=[i for i in range(1,count) if stats[i,cv2.CC_STAT_HEIGHT]>=.55*h and stats[i,cv2.CC_STAT_AREA]>=100]
    eligible=sorted(eligible,key=lambda i:(-stats[i,cv2.CC_STAT_HEIGHT],-stats[i,cv2.CC_STAT_AREA]))[:2]
    if len(eligible)!=2:return None,{'pass':False,'reason':'two_long_color_strips_not_found','components':len(eligible)}
    eligible.sort(key=lambda i:centers[i,0]);fits=[];rows=np.arange(h,dtype=float)
    for i in eligible:
        obs=[]
        for y in range(h):
            xx=np.where((labels[y]==i)&colored[y])[0]
            if len(xx)>=2:obs.append([y,float(np.median(xx))])
        obs=np.array(obs)
        if len(obs)<.55*h or np.ptp(obs[:,0])<.8*h:return None,{'pass':False,'reason':'insufficient_visible_strip_rows'}
        yy=(obs[:,0]-h/2)/h
        initial=np.polyfit(yy,obs[:,1],1)
        fit=least_squares(lambda p:p[0]*yy+p[1]-obs[:,1],initial,loss='soft_l1',f_scale=1.5)
        error=abs(fit.fun);curve=fit.x[0]*(rows-h/2)/h+fit.x[1]
        fits.append({'line_coefficients_normalized_y':fit.x.tolist(),'support_rows':len(obs),
                     'absolute_fit_error_median_pixels':float(np.median(error)),
                     'absolute_fit_error_p95_pixels':float(np.percentile(error,95)),
                     'curve':curve})
    separation=fits[1]['curve']-fits[0]['curve']
    if min(separation)<.1*w or max(separation)>.6*w:return None,{'pass':False,'reason':'invalid_strip_separation'}
    if max(f['absolute_fit_error_p95_pixels'] for f in fits)>4:return None,{'pass':False,'reason':'strip_line_fit_inconsistent'}
    left=fits[0].pop('curve')-3;right=fits[1].pop('curve')+3
    mask=(np.arange(w)[None,:]>=left[:,None])&(np.arange(w)[None,:]<=right[:,None])
    return mask,{'pass':True,'strip_fits':fits,'left_pixels':left.tolist(),'right_pixels':right.tolist(),
                 'mask_area_fraction':float(mask.mean())}


def main():
    start=time.perf_counter();out=BASE/'runs'/('d0_bridge_roi_'+datetime.now().strftime('%Y%m%d_%H%M%S'));out.mkdir()
    (out/'settings.json').write_text(json.dumps(SETTINGS,indent=2),encoding='utf-8')
    source=dict(np.load(SOURCE/'optimized_predictions.npz'));images=source['rgb'];masks=[];records=[]
    for view,rgb in enumerate(images):
        mask,record=fit_strips(rgb);record.update(view=view,image_index=int(source['image_indices'][view]))
        masks.append(mask if mask is not None else np.zeros(rgb.shape[:2],bool));records.append(record)
    masks=np.array(masks);all_valid=all(r['pass'] for r in records)
    np.savez_compressed(out/'roi_masks.npz',masks=masks.astype('uint8')*255,image_indices=source['image_indices'],valid_views=np.array([r['pass'] for r in records]))
    original=json.loads((SOURCE/'tracks.json').read_text(encoding='utf-8'));audit={}
    for group,tracks in original.items():
        items=[]
        for tr in tracks:
            v=np.array(tr['views']);uv=np.rint(tr['uv']).astype(int)
            within=(uv[:,0]>=0)&(uv[:,0]<masks.shape[2])&(uv[:,1]>=0)&(uv[:,1]<masks.shape[1])
            use=np.zeros(len(v),bool);ids=np.where(within)[0];use[ids]=masks[v[ids],uv[ids,1],uv[ids,0]]
            items.append({'id':tr['id'],'observations':len(v),'inside_observations':int(use.sum()),'all_observations_inside':bool(use.all()),'at_least_four_inside':bool(use.sum()>=4)})
        audit[group]={'original_tracks':len(items),'all_observations_inside':sum(x['all_observations_inside'] for x in items),
                      'at_least_four_inside':sum(x['at_least_four_inside'] for x in items),'tracks':items}
    report={'settings':SETTINGS,'all_views_valid':all_valid,'views':records,'original_track_roi_membership':audit,
        'seconds':time.perf_counter()-start,'interpretation':'ROI membership is not a static/dynamic classification. Original full inventory is retained in audit; no error comparison after selective deletion.'}
    (out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    fig,axes=plt.subplots(3,4,figsize=(14,9))
    for ax,rgb,mask,rec in zip(axes.flat,images,masks,records):
        display=rgb.copy();display[~mask]=(display[~mask]*.35).astype('uint8');ax.imshow(display)
        if rec['pass']:
            y=np.arange(len(rgb));ax.plot(rec['left_pixels'],y,color='yellow',lw=.7);ax.plot(rec['right_pixels'],y,color='yellow',lw=.7)
        ax.set_title(f"Image {rec['image_index']}; {'valid ROI' if rec['pass'] else 'NO ROI'}",fontsize=9);ax.axis('off')
    fig.suptitle('Image-only painted-strip envelope: vegetation outside removed; vehicles inside remain')
    fig.tight_layout();fig.savefig(out/'roi_contact.png',dpi=160);plt.close(fig)
    print(json.dumps({'all_views_valid':all_valid,'membership':{k:{kk:vv for kk,vv in v.items() if kk!='tracks'} for k,v in audit.items()},'failures':[r for r in records if not r['pass']]}),flush=True)
    print('REPORT',out,flush=True)


if __name__=='__main__':main()
