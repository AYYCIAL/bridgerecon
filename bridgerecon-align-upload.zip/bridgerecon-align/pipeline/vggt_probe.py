"""Reproducible D0 camera/depth inference probe, not a method comparison."""
import os
from pathlib import Path
from datetime import datetime
import argparse, gc, json, subprocess, sys, time, traceback
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
sys.path.insert(0, str(BASE/'vendor'/'vggt'))
import numpy as np
import torch
from PIL import Image
from vggt.models.vggt import VGGT
from vggt.utils.load_fn import load_and_preprocess_images
from vggt.utils.pose_enc import pose_encoding_to_extri_intri
from vggt.utils.geometry import unproject_depth_map_to_point_map

def save_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

def load_model():
    # Meta construction + checkpoint mmap prevents two simultaneous 5GB CPU copies.
    # The upstream stochastic-depth schedule uses .item(); keep only that tiny
    # schedule on CPU. This changes allocation, not model mathematics/weights.
    linspace = torch.linspace
    def cpu_linspace(*args, **kwargs):
        kwargs['device']='cpu'
        return linspace(*args, **kwargs)
    with patch('torch.linspace', cpu_linspace), torch.device('meta'):
        model = VGGT(enable_camera=True, enable_depth=True, enable_point=False, enable_track=False)
    state = torch.load(BASE/'weights'/'model.pt', map_location='cpu', mmap=True, weights_only=True)
    kept = {k:v for k,v in state.items() if not k.startswith(('point_head.', 'track_head.'))}
    model.load_state_dict(kept, strict=True, assign=True)
    assert not any(p.is_meta for p in model.parameters())
    model.eval().requires_grad_(False).to('cuda')
    del state, kept
    gc.collect()
    return model

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--counts', type=int, nargs='+', default=[2,4,8])
    p.add_argument('--offset', type=int, default=0)
    p.add_argument('--stride', type=int, default=3)
    p.add_argument('--head-chunk', type=int, default=0, help='0=official forward; positive=frame-chunked FP32 heads')
    a=p.parse_args()
    out=BASE/'runs'/('d0_vggt_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    out.mkdir(parents=True)
    torch.set_num_threads(4); torch.manual_seed(20261017); np.random.seed(20261017)
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA required')
    files=sorted(p for p in Path(os.environ.get('BRIDGERECON_IMAGES', ROOT / 'images')).rglob('*') if p.suffix.lower()=='.jpg')
    indices=[a.offset+i*a.stride for i in range(max(a.counts))]
    chosen=[files[i] for i in indices]
    report={'scope':'D0 feasibility only; no reference comparison', 'started':datetime.now().astimezone().isoformat(),
            'source_commit':subprocess.check_output(['git','-C',str(BASE/'vendor'/'vggt'),'rev-parse','HEAD'],text=True).strip(),
            'weights':json.loads((BASE/'weights'/'model_source.json').read_text()),
            'torch':torch.__version__, 'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(),
            'parameters':'FP32, BF16 autocast aggregator with weight cache disabled; camera/depth heads FP32',
            'heads':['camera','depth'], 'disabled_heads':['point','track'], 'head_chunk':a.head_chunk,
            'input_indices':indices, 'images':[str(f.relative_to(ROOT)) for f in chosen],
            'preprocessing':'official load_and_preprocess_images(mode=crop), width 518; no JPEG draft shortcut',
            'trials':[]}
    save_json(out/'report.json',report)
    started=time.perf_counter()
    print('Loading checkpoint',flush=True)
    model=load_model(); torch.cuda.synchronize()
    report['model_load_seconds']=time.perf_counter()-started
    report['model_parameter_count']=sum(p.numel() for p in model.parameters())
    report['model_allocated_MiB']=torch.cuda.memory_allocated()/1024**2
    print(json.dumps({k:report[k] for k in ['model_load_seconds','model_parameter_count','model_allocated_MiB']}),flush=True)
    for count in a.counts:
        rec={'frames':count, 'status':'started'}
        report['trials'].append(rec); save_json(out/'report.json',report)
        images=pred=aggregated=depth=conf=pose=None
        t=time.perf_counter()
        try:
            trial=out/f'n{count}'; trial.mkdir()
            images=load_and_preprocess_images([str(f) for f in chosen[:count]]).to('cuda')
            rec['preprocess_seconds']=time.perf_counter()-t
            rec['input_shape']=list(images.shape)
            torch.cuda.reset_peak_memory_stats()
            torch.cuda.synchronize(); ti=time.perf_counter()
            with torch.inference_mode(), torch.autocast(device_type='cuda', dtype=torch.bfloat16, cache_enabled=False):
                if a.head_chunk:
                    aggregated, start=model.aggregator(images[None])
                    with torch.autocast(device_type='cuda',enabled=False):
                        pose=model.camera_head(aggregated)[-1]
                        depth,conf=model.depth_head(aggregated,images[None],start,frames_chunk_size=a.head_chunk)
                    pred={'pose_enc':pose,'depth':depth,'depth_conf':conf}
                else:
                    pred=model(images)
            torch.cuda.synchronize()
            rec['inference_seconds']=time.perf_counter()-ti
            rec['peak_allocated_MiB']=torch.cuda.max_memory_allocated()/1024**2
            rec['peak_reserved_MiB']=torch.cuda.max_memory_reserved()/1024**2
            extr,intr=pose_encoding_to_extri_intri(pred['pose_enc'].float(),images.shape[-2:])
            arrays={k:pred[k][0].float().cpu().numpy() for k in ['pose_enc','depth','depth_conf']}
            arrays.update(extrinsics=extr[0].cpu().numpy(),intrinsics=intr[0].cpu().numpy())
            for key,arr in arrays.items():
                if not np.isfinite(arr).all():
                    raise RuntimeError('Nonfinite output: '+key)
            if not (arrays['depth']>0).all():
                raise RuntimeError('Nonpositive depth')
            arrays['rgb']=(images.permute(0,2,3,1).float().cpu().numpy()*255).round().astype(np.uint8)
            arrays['image_indices']=np.array(indices[:count])
            transforms=[]
            for f in chosen[:count]:
                with Image.open(f) as im:
                    w,h=im.size
                nh=round(h*(518/w)/14)*14
                # PIL maps pixel centers; preserve the half-pixel offset.
                # Historical prediction files retain the earlier approximation.
                sx,sy=518/w,nh/h
                transforms.append([[sx,0,.5*sx-.5],[0,sy,.5*sy-.5-max(0,(nh-518)//2)],[0,0,1]])
            arrays['original_to_input']=np.array(transforms)
            np.savez_compressed(trial/'predictions.npz',**arrays)
            points=unproject_depth_map_to_point_map(arrays['depth'], arrays['extrinsics'],arrays['intrinsics'])
            # Compact visualization only: stride 4, top 50% confidence per image.
            pts=points[:,::4,::4].reshape(-1,3)
            rgb=arrays['rgb'][:,::4,::4].reshape(-1,3)
            c=arrays['depth_conf'][:,::4,::4]
            mask=(c>=np.median(c,axis=(1,2),keepdims=True)).reshape(-1)
            packed=np.empty(int(mask.sum()),dtype=[('x','<f4'),('y','<f4'),('z','<f4'),('red','u1'),('green','u1'),('blue','u1')])
            for j,k in enumerate(['x','y','z']): packed[k]=pts[mask,j]
            for j,k in enumerate(['red','green','blue']): packed[k]=rgb[mask,j]
            with (trial/'preview.ply').open('wb') as f:
                f.write(('ply\nformat binary_little_endian 1.0\nelement vertex '+str(len(packed))+'\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n').encode())
                f.write(packed.tobytes())
            rec.update(status='completed', depth_percentiles=np.percentile(arrays['depth'],[1,50,99]).tolist(),
                       confidence_percentiles=np.percentile(arrays['depth_conf'],[1,50,99]).tolist(),
                       output=str(trial.relative_to(BASE)), total_trial_seconds=time.perf_counter()-t)
            del arrays,points,extr,intr
        except torch.cuda.OutOfMemoryError as e:
            rec.update(status='oom',error=str(e),total_trial_seconds=time.perf_counter()-t)
            traceback.print_exc()
        except Exception as e:
            rec.update(status='failed',error=repr(e),total_trial_seconds=time.perf_counter()-t)
            traceback.print_exc()
        finally:
            images=pred=aggregated=depth=conf=pose=None
            gc.collect(); torch.cuda.empty_cache()
            save_json(out/'report.json',report)
            print(json.dumps(rec),flush=True)
        if rec['status']!='completed':
            break
    print('REPORT '+str(out/'report.json'),flush=True)
    return 0 if all(x['status']=='completed' for x in report['trials']) else 1
if __name__=='__main__':
    sys.exit(main())
