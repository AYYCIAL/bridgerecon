"""Checkpointed frozen VGGT chunks; run through the exclusive GPU executor."""
from pathlib import Path
from datetime import datetime
import argparse,gc,hashlib,json,shutil,time,uuid
import numpy as np
from PIL import Image
from work_schedule import require_start_window

BASE=Path(__file__).resolve().parent;ROOT=BASE.parent


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(path)


def main():
    p=argparse.ArgumentParser();p.add_argument('--starts',nargs='+',type=int);p.add_argument('--all-main',action='store_true')
    p.add_argument('--reuse',nargs='*',type=Path,default=[]);args=p.parse_args()
    require_start_window(180)
    import torch
    from vggt_probe import load_model,load_and_preprocess_images,pose_encoding_to_extri_intri
    manifest_path=BASE/'data_audit/full_route_vggt_prepared_manifest.json'
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    starts=[c['indices'][0] for c in manifest['chunks']] if args.all_main else args.starts
    assert starts and len(set(starts))==len(starts) and all(0<=i<=564 for i in starts)
    inventory=json.loads((BASE/'data_audit/images.json').read_text(encoding='utf-8'))
    out=BASE/'runs'/('vggt_route_chunks_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir()
    (out/'driver_source.py').write_bytes(Path(__file__).read_bytes())
    report={'status':'preparing','created':datetime.now().astimezone().isoformat(),'starts':starts,'chunks':[],
            'scope':'Frozen VGGT raw main-route chunks; not yet assembled or independent accuracy assessed',
            'settings':{'views':12,'preprocess':'Official 518px crop, no orientation changes, pixel-center transforms saved',
                        'heads':'FP32 camera/depth, BF16 aggregator, frame head chunk1, no autocast weight cache',
                        'weights_source_sha256':sha(BASE/'weights/model_source.json'),
                        'input_inventory_sha256':sha(BASE/'data_audit/images.json'),'seed':20261019},
            'manifest_sha256':sha(manifest_path),'reference_access':False,'colmap_camera_access':False,
            'gpu':torch.cuda.get_device_name(),'torch':torch.__version__,'reuse_sources':[str(p) for p in args.reuse]}
    save(out/'report.json',report)
    reuse={}
    for source in args.reuse:
        old=json.loads((source/'report.json').read_text(encoding='utf-8'))
        assert old['settings']==report['settings'],'Reuse numerical/input settings differ'
        for item in old['chunks']:
            if item['status']=='completed':reuse[item['start']]=(source,item)
    torch.set_num_threads(4);torch.manual_seed(20261019);np.random.seed(20261019)
    model=None;cache={};total=time.monotonic()
    try:
        report['status']='running';save(out/'report.json',report)
        for start in starts:
            require_start_window(120)
            tic=time.monotonic();folder=out/f'chunk_{start:04d}';folder.mkdir()
            indices=list(range(start,start+12));item={'start':start,'image_indices':indices,'status':'started'}
            report['chunks'].append(item);save(out/'report.json',report)
            dest=folder/'predictions.npz'
            if start in reuse:
                source,old=reuse[start];path=source/old['prediction']
                assert sha(path)==old['sha256'] and old['image_indices']==indices
                shutil.copy2(path,dest)
                item.update(status='completed',prediction=str(dest.relative_to(out)),sha256=sha(dest),
                            reused_from=str(path),seconds=time.monotonic()-tic)
                save(out/'report.json',report);print('REUSED',start,flush=True);continue
            if model is None:
                load=time.monotonic();model=load_model();torch.cuda.synchronize()
                report['model_load_seconds']=time.monotonic()-load
            for index in indices:
                if index not in cache:
                    cache[index]=load_and_preprocess_images([str(ROOT/inventory[index]['file'])])[0]
            cache={i:cache[i] for i in indices}
            images=torch.stack([cache[i] for i in indices]).to('cuda')
            torch.cuda.reset_peak_memory_stats();torch.cuda.synchronize();infer=time.monotonic()
            with torch.inference_mode(),torch.autocast(device_type='cuda',dtype=torch.bfloat16,cache_enabled=False):
                tokens,patch_start=model.aggregator(images[None])
                with torch.autocast(device_type='cuda',enabled=False):
                    pose=model.camera_head(tokens)[-1]
                    depth,conf=model.depth_head(tokens,images[None],patch_start,frames_chunk_size=1)
            torch.cuda.synchronize()
            item['inference_seconds']=time.monotonic()-infer
            E,K=pose_encoding_to_extri_intri(pose.float(),images.shape[-2:])
            arrays={'depth':depth[0].float().cpu().numpy(),'depth_conf':conf[0].float().cpu().numpy(),
                    'extrinsics':E[0].cpu().numpy(),'intrinsics':K[0].cpu().numpy(),
                    'rgb':(images.permute(0,2,3,1).float().cpu().numpy()*255).round().astype('uint8'),
                    'image_indices':np.array(indices)}
            transforms=[]
            for index in indices:
                with Image.open(ROOT/inventory[index]['file']) as im:w,h=im.size
                nh=round(h*(518/w)/14)*14;sx,sy=518/w,nh/h
                transforms.append([[sx,0,.5*sx-.5],[0,sy,.5*sy-.5-max(0,(nh-518)//2)],[0,0,1]])
            arrays['original_to_input']=np.array(transforms)
            assert all(np.isfinite(v).all() for v in arrays.values()) and (arrays['depth']>0).all()
            np.savez_compressed(dest,**arrays)
            item.update(status='completed',prediction=str(dest.relative_to(out)),sha256=sha(dest),
                        seconds=time.monotonic()-tic,peak_allocated_MiB=torch.cuda.max_memory_allocated()/1024**2,
                        peak_reserved_MiB=torch.cuda.max_memory_reserved()/1024**2)
            save(out/'report.json',report)
            print('CHUNK',start,'seconds',round(item['seconds'],2),'infer',round(item['inference_seconds'],2),flush=True)
            del arrays,images,tokens,pose,depth,conf,E,K
            gc.collect();torch.cuda.empty_cache()
        report.update(status='completed',seconds=time.monotonic()-total,
                      unique_images=len({i for c in report['chunks'] for i in c['image_indices']}))
    except Exception as exc:
        report.update(status='failed',error=repr(exc),seconds=time.monotonic()-total);raise
    finally:
        save(out/'report.json',report);print('REPORT',str(out),flush=True)


if __name__=='__main__':main()
