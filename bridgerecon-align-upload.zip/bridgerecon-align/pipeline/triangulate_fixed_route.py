"""Restore matched sparse support at supplied fixed cameras, without PCD/GPU."""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import json
import os
import subprocess
import time
import uuid
import sqlite3
from contextlib import closing
from budget_run import OwnedJob
from work_schedule import require_start_window

BASE=Path(__file__).resolve().parent
EXE=os.environ.get('COLMAP_EXE', 'colmap')


def digest(path):
    result=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''):result.update(block)
    return result.hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('source_run',type=Path)
    parser.add_argument('model',type=Path)
    parser.add_argument('--seconds',type=int,default=600)
    parser.add_argument('--sync-model-camera-ids',action='store_true',help='Private snapshot only: synchronize merged camera IDs and supplied intrinsics')
    args=parser.parse_args()
    require_start_window(args.seconds+60)
    source=args.source_run.resolve();model=args.model.resolve()
    source.relative_to(BASE/'runs');model.relative_to(source)
    out=source/'triangulation_controls'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
    (out/'sparse').mkdir(parents=True)
    (out/'driver_source.py').write_bytes(Path(__file__).read_bytes())
    hashes={n:digest(model/n) for n in ('cameras.bin','images.bin','points3D.bin')}
    database_hash=digest(source/'database.db')
    # Native database open can update SQLite writer/header metadata. Work on a
    # consistent read-only snapshot instead of the shared cache.
    with closing(sqlite3.connect((source/'database.db').as_uri()+'?mode=ro',uri=True)) as src:
        with closing(sqlite3.connect(out/'working_database.db')) as dst:
            src.backup(dst)
            if args.sync_model_camera_ids:
                import pycolmap
                import numpy as np
                os.chdir(source)
                reconstruction=pycolmap.Reconstruction(model.relative_to(source).as_posix())
                for camera_id,camera in reconstruction.cameras.items():
                    dst.execute('UPDATE cameras SET model=?,width=?,height=?,params=? WHERE camera_id=?',
                                (camera.model.value,camera.width,camera.height,np.asarray(camera.params,dtype='<f8').tobytes(),camera_id))
                has_frames=bool(dst.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='frame_data'").fetchone())
                for image_id,image in reconstruction.images.items():
                    dst.execute('UPDATE images SET camera_id=? WHERE image_id=?',(image.camera_id,image_id))
                    if has_frames:
                        frame=dst.execute('SELECT frame_id FROM frame_data WHERE data_id=? AND sensor_type=0',(image_id,)).fetchone()
                        assert frame and frame[0]==image_id,'Only explicit trivial image/frame identity is supported'
                        reference=dst.execute('SELECT ref_sensor_id,ref_sensor_type FROM rigs WHERE rig_id=?',(image.camera_id,)).fetchone()
                        assert reference==(image.camera_id,0),'Only trivial single-camera rigs are supported'
                        dst.execute('UPDATE frames SET rig_id=? WHERE frame_id=?',(image.camera_id,frame[0]))
                        dst.execute('UPDATE frame_data SET sensor_id=? WHERE frame_id=? AND data_id=? AND sensor_type=0',(image.camera_id,frame[0],image_id))
            dst.commit()
    working_hash=digest(out/'working_database.db')
    def relative(path):return path.relative_to(source).as_posix()
    command=[EXE,'point_triangulator','--database_path',relative(out/'working_database.db'),'--image_path','images',
             '--input_path',relative(model),'--output_path',relative(out/'sparse'),
             '--clear_points','1','--refine_intrinsics','0','--Mapper.fix_existing_frames','1',
             '--Mapper.num_threads','4','--Mapper.ba_use_gpu','0','--Mapper.ba_refine_focal_length','0',
             '--Mapper.ba_refine_principal_point','0','--Mapper.ba_refine_extra_params','0',
             '--Mapper.ba_refine_sensor_from_rig','0','--Mapper.ba_global_max_num_iterations','3',
             '--Mapper.ba_global_max_refinements','1','--Mapper.ba_global_function_tolerance','1e-5',
             '--Mapper.ba_min_num_residuals_for_cpu_multi_threading','1000000000']
    report={'status':'running','input_model':str(model),'input_sha256':hashes,'command':command,
            'database_sha256_before':database_hash,'gpu_used':False,'reference_access':False,
            'working_database_sha256_before':working_hash,'database_policy':'Read-only SQLite backup to dedicated per-attempt writable copy',
            'scope':'Re-triangulation from cached full-inventory matches at fixed supplied cameras; not full camera BA or metrological validation',
            'camera_and_intrinsics_invariance_readback_required':True}
    report['private_database_camera_ids_synchronized']=args.sync_model_camera_ids
    report['private_database_trivial_rigs_synchronized']=args.sync_model_camera_ids
    def save():(out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    save();print(json.dumps({'output':str(out)},ensure_ascii=True),flush=True)
    start=time.monotonic();env=os.environ.copy();env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    try:
        with (out/'triangulation.log').open('w') as log:
            child=subprocess.Popen(command,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
            owned=OwnedJob(child)
            try:
                code=child.wait(timeout=args.seconds)
                report.update(exit_code=code,status='saved_pending_readback' if code==0 else 'failed')
            except subprocess.TimeoutExpired:
                owned.terminate();child.wait(timeout=10);report['status']='timeout'
            finally:owned.close()
        if report['status']=='saved_pending_readback':
            assert all((out/'sparse'/n).exists() for n in hashes)
            with (out/'native_validation.log').open('w') as log:
                result=subprocess.run([EXE,'model_analyzer','--path',relative(out/'sparse')],cwd=source,
                                      stdout=log,stderr=subprocess.STDOUT,timeout=20)
            report['native_validation_passed']=result.returncode==0
            if result.returncode:report['status']='failed_native_validation'
    except Exception as exc:
        report.update(status='failed',error=repr(exc));raise
    finally:
        report['seconds']=time.monotonic()-start
        report['input_unchanged']=all(digest(model/n)==h for n,h in hashes.items())
        report['database_unchanged']=digest(source/'database.db')==database_hash
        save();print(json.dumps({'status':report['status'],'output':str(out)},ensure_ascii=True),flush=True)


if __name__=='__main__':
    main()
