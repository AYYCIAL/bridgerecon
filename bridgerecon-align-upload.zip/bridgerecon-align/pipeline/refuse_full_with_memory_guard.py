"""Bounded CPU re-fusion of completed 1600 depth maps with a larger cache.

No depth estimation, camera change, threshold change or PCD access. A failed
cache attempt is retained; native work is stopped on sustained memory pressure
or lack of first-image progress rather than repeating an hour-long stall.
"""
from pathlib import Path
from datetime import datetime
import argparse
import ctypes
import hashlib
import json
import os
import subprocess
import time
import uuid
from budget_run import OwnedJob
from work_schedule import require_start_window

BASE=Path(__file__).resolve().parent


def available_memory():
    class Memory(ctypes.Structure):
        _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong),
                  ('total',ctypes.c_ulonglong),('available',ctypes.c_ulonglong),
                  ('page_total',ctypes.c_ulonglong),('page_available',ctypes.c_ulonglong),
                  ('virtual_total',ctypes.c_ulonglong),('virtual_available',ctypes.c_ulonglong),
                  ('extended',ctypes.c_ulonglong)]
    state=Memory();state.length=ctypes.sizeof(state)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(state)):raise ctypes.WinError()
    return state.available


def main():
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('attempt',type=Path)
    p.add_argument('--cache-gib',type=int,choices=(3,4,5),default=4)
    p.add_argument('--seconds',type=int,default=3600)
    args=p.parse_args();require_start_window(args.seconds+180)
    source=args.source.resolve();original=args.attempt.resolve();original.relative_to(source)
    metadata=json.loads((original/'report.json').read_text(encoding='utf-8'))
    assert any(s['name']=='stereo' and s['status']=='completed' for s in metadata['stages'])
    assert metadata['settings']['width']==1600 and metadata['registered_images']==578
    assert len(list((original/'dense/stereo/depth_maps').rglob('*.geometric.bin')))==578
    out=source/'fusion_controls'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir()
    (out/'driver_source.py').write_bytes(Path(__file__).read_bytes())
    output=out/'fused_cache4.ply';logfile=out/'fusion.log'
    rel=lambda path:path.relative_to(source).as_posix()
    command=[os.environ.get('COLMAP_EXE', 'colmap'),'stereo_fusion','--workspace_path',rel(original/'dense'),
             '--input_type','geometric','--output_path',rel(output),'--StereoFusion.num_threads','8',
             '--StereoFusion.use_cache','1','--StereoFusion.cache_size',str(args.cache_gib),
             '--StereoFusion.max_image_size','1600','--StereoFusion.min_num_pixels','5']
    protected=[original/'dense/stereo/fusion.cfg']+list((original/'dense/sparse').glob('*.bin'))
    hashes={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in protected}
    report={'status':'prepared','original_attempt':str(original),'command':command,
            'scope':'CPU fusion resource-recovery control, unchanged completed depth maps and geometric thresholds',
            'reference_access':False,'gpu_used':False,'cache_gib':args.cache_gib,
            'available_memory_initial_bytes':available_memory(),'memory_guard_bytes':768*1024**2,
            'first_image_guard_seconds':180,'seconds_limit':args.seconds,'protected_sha256':hashes}
    def save():
        temp=out/'report.tmp';temp.write_text(json.dumps(report,indent=2),encoding='utf-8');temp.replace(out/'report.json')
    save();print(json.dumps({'output':str(out)},ensure_ascii=True),flush=True)
    start=time.monotonic();child=None;owned=None;low_count=0;minimum=available_memory()
    try:
        # Cache plus masks and temporary buffers need headroom. This is a
        # startup guard, not permission to allocate all currently available RAM.
        if available_memory()<(args.cache_gib+1)*1024**3:
            report['status']='insufficient_memory_before_start';return 1
        report['status']='running';save()
        env=os.environ.copy();env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
        with logfile.open('w',encoding='utf-8') as log:
            child=subprocess.Popen(command,cwd=source,stdout=log,stderr=subprocess.STDOUT,env=env,
                                   creationflags=subprocess.CREATE_NO_WINDOW);owned=OwnedJob(child)
            report['pid']=child.pid;save()
            while child.poll() is None:
                time.sleep(3);elapsed=time.monotonic()-start
                free=available_memory();minimum=min(minimum,free)
                low_count=low_count+1 if free<768*1024**2 else 0
                text=logfile.read_text(encoding='utf-8',errors='replace')
                seen=text.count('Fusing image [')
                reason=None
                if elapsed>args.seconds:reason='timeout'
                elif low_count>=4:reason='sustained_low_physical_memory'
                elif elapsed>180 and seen<2:reason='first_image_progress_guard'
                if reason:
                    owned.terminate();child.wait(timeout=20);report['status']=reason;break
            else:
                report.update(status='saved_pending_readback' if child.returncode==0 else 'failed',exit_code=child.returncode)
        if report['status']=='saved_pending_readback':
            import numpy as np
            import open3d as o3d
            cloud=o3d.io.read_point_cloud(str(output));xyz=np.asarray(cloud.points)
            rgb=np.asarray(cloud.colors);normals=np.asarray(cloud.normals)
            report.update(points=len(xyz),finite_xyz=bool(np.isfinite(xyz).all()),
                          finite_normals=bool(len(normals)==len(xyz) and np.isfinite(normals).all()),
                          black_rgb_fraction=float((rgb.max(1)==0).mean()) if len(rgb) else None,
                          output_sha256=hashlib.sha256(output.read_bytes()).hexdigest())
            report['status']='completed_readback' if len(xyz) and report['finite_xyz'] and report['finite_normals'] else 'readback_failed'
        return 0 if report['status']=='completed_readback' else 1
    finally:
        if child is not None and child.poll() is None:
            if owned:owned.terminate()
            else:child.kill()
            child.wait(timeout=20)
        if owned:owned.close()
        report['seconds']=time.monotonic()-start;report['minimum_available_memory_bytes']=minimum
        report['protected_inputs_unchanged']=all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest for path,digest in hashes.items())
        save();print(json.dumps({'status':report['status'],'output':str(out)},ensure_ascii=True),flush=True)


if __name__=='__main__':raise SystemExit(main())
