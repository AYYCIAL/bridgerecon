"""Memory-bounded native COLMAP fusion with declared covisibility contexts.

This changes the fusion context from one global workspace to overlapping tiles.
It is a separately declared processing variant, not identical global fusion.
Every camera remains a core camera once; contexts and overlap are retained.
"""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import time
import uuid
from budget_run import OwnedJob
from work_schedule import require_start_window
from refuse_full_with_memory_guard import available_memory

BASE=Path(__file__).resolve().parent


def digest(path):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(8*1024*1024),b''):value.update(block)
    return value.hexdigest()


def make_manifest(source,attempt,expected_images=578):
    names=[line.strip() for line in (attempt/'dense/stereo/fusion.cfg').read_text().splitlines() if line.strip() and not line.startswith('#')]
    assert len(names)==expected_images and len(set(names))==expected_images
    names=sorted(names)
    db=source/'database.db';db_hash=digest(db)
    connection=sqlite3.connect('file:'+db.as_posix()+'?mode=ro',uri=True)
    records=dict(connection.execute('SELECT image_id,name FROM images'))
    neighbors={name:[] for name in names};registered=set(names)
    for pair_id,count in connection.execute('SELECT pair_id,rows FROM two_view_geometries WHERE rows>=15'):
        a,b=divmod(pair_id,2147483647);na,nb=records[a],records[b]
        if na in registered and nb in registered:
            neighbors[na].append((count,nb));neighbors[nb].append((count,na))
    connection.close();assert digest(db)==db_hash
    tiles=[]
    for start in range(0,len(names),8):
        core=names[start:start+8];context=set(core)
        selected={}
        for name in core:
            selected[name]=[other for _,other in sorted(neighbors[name],key=lambda x:(-x[0],x[1]))[:8]]
            context.update(selected[name])
        tiles.append({'tile':len(tiles),'core':core,'context':sorted(context),'core_neighbor_choices':selected})
    assert sorted(name for tile in tiles for name in tile['core'])==names
    return {'created':datetime.now().astimezone().isoformat(),'registered_names':names,'tiles':tiles,
            'selection':'Lexicographically ordered blocks of eight core images; eight highest verified-match-count neighbors per core, stable-name ties',
            'database_sha256':db_hash,'reference_access':False,'outcome_based_selection':False,
            'limits':'Context restriction changes native global fusion; overlap points are retained, not claimed unique'}


def ply_header(path):
    with path.open('rb') as stream:
        lines=[]
        while True:
            line=stream.readline();lines.append(line)
            if not line or len(lines)>100:raise ValueError('Invalid PLY header')
            if line.strip()==b'end_header':break
        count=next(int(line.split()[-1]) for line in lines if line.startswith(b'element vertex '))
        assert any(line.strip()==b'format binary_little_endian 1.0' for line in lines)
        return lines,stream.tell(),count


def main():
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('attempt',type=Path)
    p.add_argument('--manifest',type=Path);p.add_argument('--resume',type=Path)
    p.add_argument('--max-tiles',type=int,default=0,help='Positive values are partial feasibility runs only')
    p.add_argument('--seconds',type=int,default=10800)
    p.add_argument('--expected-images',type=int,default=578)
    args=p.parse_args();require_start_window(args.seconds+300)
    source=args.source.resolve();attempt=args.attempt.resolve();attempt.relative_to(source)
    metadata=json.loads((attempt/'report.json').read_text(encoding='utf-8'))
    assert metadata['settings']['width']==1600 and metadata['registered_images']==args.expected_images
    assert any(s['name']=='stereo' and s['status']=='completed' for s in metadata['stages'])
    if args.resume:
        out=args.resume.resolve();out.relative_to(source)
        report=json.loads((out/'report.json').read_text(encoding='utf-8'))
        assert report['original_attempt']==str(attempt) and report['source_sha256']==digest(Path(__file__))
        manifest=json.loads((out/'tile_manifest.json').read_text(encoding='utf-8'))
        report.setdefault('resumes',[]).append(datetime.now().astimezone().isoformat())
    else:
        out=source/'tiled_fusion'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir(parents=True)
        manifest=json.loads(args.manifest.read_text(encoding='utf-8')) if args.manifest else make_manifest(source,attempt,args.expected_images)
        (out/'tile_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        (out/'driver_source.py').write_bytes(Path(__file__).read_bytes())
        report={'status':'prepared','original_attempt':str(attempt),'source_sha256':digest(Path(__file__)),
                'manifest_sha256':digest(out/'tile_manifest.json'),'reference_access':False,'gpu_used':False,
                'scope':'Separate tiled native-fusion processing variant on unchanged full-route depth maps',
                'settings':{'core_images':8,'strongest_neighbors_per_core':8,'cache':False,'threads':8,
                            'image_size':1600,'min_num_pixels':5,'check_num_images':50,
                            'max_reproj_error':2,'max_relative_depth_error':.01,'max_normal_error_degrees':10},
                'tiles':[],'overlap_points_retained':True,'unique_point_count':None,
                'workspace_storage':'Prefer hard links; fall back to private copies; remove verified temporary image/map copies after each tile',
                'protected_model_sha256':{str(path):digest(path) for path in (attempt/'dense/sparse').glob('*.bin')}}
    actual=set(line.strip() for line in (attempt/'dense/stereo/fusion.cfg').read_text().splitlines() if line.strip() and not line.startswith('#'))
    assert set(manifest['registered_names'])==actual
    def save():
        temp=out/'report.tmp';temp.write_text(json.dumps(report,indent=2),encoding='utf-8');temp.replace(out/'report.json')
    rel=lambda path:path.relative_to(source).as_posix()
    save();print(json.dumps({'output':str(out)},ensure_ascii=True),flush=True)
    start=time.monotonic();done={t['tile'] for t in report['tiles'] if t['status']=='verified_output'}
    report['status']='running';save()
    try:
        processed=0
        for tile in manifest['tiles']:
            if tile['tile'] in done:continue
            if args.max_tiles and processed>=args.max_tiles:break
            if time.monotonic()-start>args.seconds:raise TimeoutError('Tiled-fusion total work cap')
            require_start_window(720)
            if available_memory()<3*1024**3:raise RuntimeError('Insufficient memory to start another fusion tile')
            folder=out/'tiles'/f"{tile['tile']:03d}";workspace=folder/'dense'
            folder.mkdir(parents=True,exist_ok=True)
            for path in (attempt/'dense/sparse').glob('*'):
                dest=workspace/'sparse'/path.name;dest.parent.mkdir(parents=True,exist_ok=True)
                if not dest.exists():shutil.copy2(path,dest)
            inputs=[]
            for name in tile['context']:
                files=[Path('images')/name,Path('stereo/depth_maps')/(name+'.geometric.bin'),Path('stereo/normal_maps')/(name+'.geometric.bin')]
                for relative in files:
                    original=attempt/'dense'/relative;dest=workspace/relative
                    assert original.is_file();dest.parent.mkdir(parents=True,exist_ok=True)
                    storage='existing'
                    if not dest.exists():
                        try:os.link(original,dest);storage='hardlink'
                        except PermissionError:shutil.copy2(original,dest);storage='private_copy'
                    stat=original.stat()
                    inputs.append({'file':relative.as_posix(),'storage':storage,
                                   'source_size':stat.st_size,'source_mtime_ns':stat.st_mtime_ns})
            (workspace/'stereo/fusion.cfg').write_text('\n'.join(tile['context'])+'\n',encoding='utf-8')
            command=[os.environ.get('COLMAP_EXE', 'colmap'),'stereo_fusion','--workspace_path',rel(workspace),
                     '--input_type','geometric','--output_path',rel(folder/'fused.ply'),
                     '--StereoFusion.num_threads','8','--StereoFusion.use_cache','0',
                     '--StereoFusion.max_image_size','1600','--StereoFusion.min_num_pixels','5']
            row={'tile':tile['tile'],'core':tile['core'],'context':tile['context'],'status':'running','command':command,
                 'inputs':inputs}
            report['tiles'].append(row);save();tic=time.monotonic();owned=None;child=None
            try:
                with (folder/'fusion.log').open('w',encoding='utf-8') as log:
                    child=subprocess.Popen(command,cwd=source,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
                    owned=OwnedJob(child);low=0
                    while child.poll() is None:
                        time.sleep(2);free=available_memory();low=low+1 if free<768*1024**2 else 0
                        if time.monotonic()-tic>600 or low>=6:
                            owned.terminate();child.wait(timeout=20)
                            raise RuntimeError('Tile timeout or sustained memory pressure')
                    if child.returncode:raise RuntimeError(f'Native tile failed: {child.returncode}')
                import numpy as np
                import open3d as o3d
                cloud=o3d.io.read_point_cloud(str(folder/'fused.ply'));xyz=np.asarray(cloud.points);normals=np.asarray(cloud.normals)
                assert len(xyz) and np.isfinite(xyz).all() and np.isfinite(normals).all()
                rgb=np.asarray(cloud.colors)
                row.update(status='verified_output',points=len(xyz),finite_xyz_and_normals=True,
                           black_rgb_fraction=float((rgb.max(1)==0).mean()),output_sha256=digest(folder/'fused.ply'))
                del cloud,xyz,normals,rgb
                for item in inputs:
                    original=attempt/'dense'/item['file'];stat=original.stat()
                    assert stat.st_size==item['source_size'] and stat.st_mtime_ns==item['source_mtime_ns']
                row['original_input_size_and_timestamps_unchanged']=True
                # Only disposable per-tile inputs are removed. Resolve each
                # absolute target and prove it is within this tile's workspace;
                # the completed source depth maps and output cloud remain.
                workspace_root=workspace.resolve();run_root=out.resolve()
                assert workspace_root.is_relative_to(run_root/'tiles')
                for relative in ('images','stereo/depth_maps','stereo/normal_maps'):
                    target=(workspace/relative).resolve()
                    assert target.is_relative_to(workspace_root) and target!=workspace_root
                    if target.exists():shutil.rmtree(target)
                row['temporary_image_and_map_inputs_removed']=True
            finally:
                if child is not None and child.poll() is None:
                    if owned:owned.terminate()
                    else:child.kill()
                    child.wait(timeout=20)
                if owned:owned.close()
                row['seconds']=time.monotonic()-tic;save()
            processed+=1;print('TILE',tile['tile'],row['status'],row['points'],flush=True)
        completed={t['tile'] for t in report['tiles'] if t['status']=='verified_output'}
        if len(completed)==len(manifest['tiles']):
            paths=[out/'tiles'/f'{i:03d}'/'fused.ply' for i in sorted(completed)]
            headers=[ply_header(path) for path in paths]
            signature=lambda lines:[line for line in lines if not line.startswith(b'element vertex ')]
            assert all(signature(h[0])==signature(headers[0][0]) for h in headers)
            total=sum(h[2] for h in headers);merged=out/'dense/fused.ply';merged.parent.mkdir(exist_ok=True)
            with merged.open('wb') as target:
                for line in headers[0][0]:
                    ending=b'\r\n' if line.endswith(b'\r\n') else b'\n'
                    target.write(f'element vertex {total}'.encode()+ending if line.startswith(b'element vertex ') else line)
                for path,(_,offset,_) in zip(paths,headers):
                    with path.open('rb') as stream:stream.seek(offset);shutil.copyfileobj(stream,target,1024*1024)
            report.update(status='completed_tiled_fusion',output_points_including_overlap=total,
                          output_sha256=digest(merged),core_cameras_covered=len(manifest['registered_names']))
        else:report['status']='completed_partial_pilot'
    except Exception as exc:
        report.update(status='stopped',error=repr(exc));raise
    finally:
        report['last_launch_seconds']=time.monotonic()-start
        report['protected_model_unchanged']=all(digest(Path(path))==value for path,value in report['protected_model_sha256'].items())
        save();print(json.dumps({'status':report['status'],'output':str(out)},ensure_ascii=True),flush=True)


if __name__=='__main__':main()
