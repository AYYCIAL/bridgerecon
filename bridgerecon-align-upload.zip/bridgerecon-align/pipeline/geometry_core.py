"""Camera geometry in OpenCV convention; no measured-cloud access."""
import numpy as np
from scipy.spatial.transform import Rotation

def camera_centers(extrinsics):
    return -np.einsum('nij,nj->ni',extrinsics[:,:,:3].transpose(0,2,1),extrinsics[:,:,3])

def project(points, cameras, intrinsics, view_ids):
    rotations=Rotation.from_rotvec(cameras[:,:3]).as_matrix()
    cam=np.einsum('nij,nj->ni',rotations[view_ids],points)+cameras[view_ids,3:]
    pixel=np.einsum('nij,nj->ni',intrinsics[view_ids],cam)
    # Signed denominator; caller explicitly checks positive depths.
    z=np.where(abs(pixel[:,2])<1e-8,np.where(pixel[:,2]>=0,1e-8,-1e-8),pixel[:,2])
    return pixel[:,:2]/z[:,None],cam[:,2]

def triangulate(uv, views, extrinsics, intrinsics):
    rows=[]
    for xy,i in zip(uv,views):
        ray=np.linalg.solve(intrinsics[i],np.r_[xy,1.])
        ray=ray/ray[2];P=extrinsics[i]
        rows.extend([ray[0]*P[2]-P[0],ray[1]*P[2]-P[1]])
    _,_,vt=np.linalg.svd(np.array(rows),full_matrices=False)
    if abs(vt[-1,3])<1e-10:return np.full(3,np.nan)
    return vt[-1,:3]/vt[-1,3]

def point_reprojection(point, uv, views, extrinsics, intrinsics):
    cam=np.einsum('nij,j->ni',extrinsics[views,:,:3],point)+extrinsics[views,:,3]
    pix=np.einsum('nij,nj->ni',intrinsics[views],cam)
    pred=pix[:,:2]/pix[:,2,None]
    return np.linalg.norm(pred-uv,axis=1),cam[:,2]

def max_parallax_degrees(point, views, extrinsics):
    rays=point-camera_centers(extrinsics)[views]
    norms=np.linalg.norm(rays,axis=1)
    if np.any(norms<1e-10):return 0.
    rays=rays/norms[:,None]
    return float(np.rad2deg(np.arccos(np.clip((rays@rays.T).min(),-1,1))))

def normalize_scene(extrinsics, length):
    r0=extrinsics[0,:,:3].copy();t0=extrinsics[0,:,3].copy()
    r=extrinsics[:,:,:3]@r0.T
    t=(extrinsics[:,:,3]-np.einsum('nij,j->ni',r,t0))/length
    return np.concatenate([r,t[:,:,None]],axis=2),r0,t0

def restore_scene(extrinsics, length, r0, t0):
    r=extrinsics[:,:,:3]@r0
    t=np.einsum('nij,j->ni',extrinsics[:,:,:3],t0)+length*extrinsics[:,:,3]
    return np.concatenate([r,t[:,:,None]],axis=2)
