"""Agisoft frame-camera projection in documented edge-origin pixels.

Manual2.2 AppendixD: tangential p1/p2 differ from OpenCV's ordering.
Image pixel centers are (col+.5,row+.5). No fitted adapter parameters.
"""
import numpy as np


def distort(xy,c):
    xy=np.asarray(xy,float);x,y=xy.T;q=x*x+y*y
    k1,k2,k3,k4=[c.get(k,0.) for k in ['k1','k2','k3','k4']]
    p1,p2=c.get('p1',0.),c.get('p2',0.)
    radial=1+q*(k1+q*(k2+q*(k3+q*k4)))
    return np.c_[x*radial+p1*(q+2*x*x)+2*p2*x*y,
                 y*radial+p2*(q+2*y*y)+2*p1*x*y]


def project_camera(points,c):
    points=np.asarray(points,float);z=points[:,2]
    xy=points[:,:2]/np.where(abs(z)>1e-15,z,np.nan)[:,None]
    d=distort(xy,c);f=c['f']
    return np.c_[c['width']*.5+c.get('cx',0.)+(f+c.get('b1',0.))*d[:,0]+c.get('b2',0.)*d[:,1],
                 c['height']*.5+c.get('cy',0.)+f*d[:,1]],z


def rays(pixels,c):
    pixels=np.asarray(pixels,float);f=c['f']
    yd=(pixels[:,1]-c['height']*.5-c.get('cy',0.))/f
    xd=(pixels[:,0]-c['width']*.5-c.get('cx',0.)-c.get('b2',0.)*yd)/(f+c.get('b1',0.))
    target=np.c_[xd,yd];xy=target.copy()
    k1,k2,k3,k4=[c.get(k,0.) for k in ['k1','k2','k3','k4']]
    p1,p2=c.get('p1',0.),c.get('p2',0.)
    for _ in range(15):
        x,y=xy.T;q=x*x+y*y;radial=1+q*(k1+q*(k2+q*(k3+q*k4)))
        dr=k1+q*(2*k2+q*(3*k3+4*k4*q))
        a=radial+2*x*x*dr+6*p1*x+2*p2*y
        b=2*x*y*dr+2*p1*y+2*p2*x
        d=radial+2*y*y*dr+6*p2*y+2*p1*x
        determinant=a*d-b*b
        assert np.all(determinant>0)
        residual=distort(xy,c)-target
        xy-=np.c_[(d*residual[:,0]-b*residual[:,1])/determinant,
                   (a*residual[:,1]-b*residual[:,0])/determinant]
    assert np.max(np.abs(distort(xy,c)-target),initial=0)<1e-10
    return np.c_[xy,np.ones(len(xy))]


def world_from_camera(points,C):
    return np.asarray(points)@C[:3,:3].T+C[:3,3]


def camera_from_world(points,C):
    return (np.asarray(points)-C[:3,3])@C[:3,:3]


def eval_to_original(uv,A,native_shape,original_shape):
    native=(np.c_[uv,np.ones(len(uv))]@np.linalg.inv(A).T)[:,:2]
    return native*np.asarray(original_shape)/np.asarray(native_shape)


def original_to_eval(pixels,A,native_shape,original_shape):
    native=pixels*np.asarray(native_shape)/np.asarray(original_shape)
    return native@A[:2,:2].T+A[:2,2]
