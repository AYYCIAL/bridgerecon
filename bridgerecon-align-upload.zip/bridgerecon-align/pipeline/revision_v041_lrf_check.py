"""Independent metric checks from the survey metadata (no fitting to the checked values).

* Camera centres of each camera configuration against the recorded RTK-fixed positions
  after one 7-parameter similarity per configuration.
* Depth at the principal point against the on-board laser rangefinder (LRF) distance for
  anchor interpolation, calibrated VGGT and COLMAP MVS.
CPU only; reads frozen outputs and the original image headers; writes a new run folder.
"""
import os
from pathlib import Path
from datetime import datetime
import csv, json, re, sys, time
import numpy as np
from scipy.interpolate import LinearNDInterpolator, NearestNDInterpolator

BASE = Path(__file__).resolve().parent; ROOT = BASE.parent; RUNS = BASE / 'runs'
PRIMARY = RUNS / 'global_hybrid_20261019_205203_28fc26c6'
ATTEMPT = RUNS / 'full_route_survey_20261018_221243_8084fdb4/dense_attempts/20261019_205034_ab94308e'
SURVEY = RUNS / 'full_route_survey_20261018_221243_8084fdb4'
CASES = {'C0': 'global_hybrid_20261019_200206_46cdaa3c', 'C1': 'global_hybrid_20261019_202608_c52f1d98',
         'C2': 'global_hybrid_20261019_202306_12e0d87d', 'C3': 'global_hybrid_20261019_202608_f0a87529',
         'C4': 'global_hybrid_20261019_202608_fdd3a7fc', 'C5': 'global_hybrid_20261019_205203_28fc26c6'}
sys.path.insert(0, str(BASE)); sys.path.insert(0, str(PRIMARY))
from global_hybrid_geometry import native_rays, camera_parameters  # noqa: E402
from local_validation import sample  # noqa: E402
from audit_native_depth_maps import map_view  # noqa: E402
from colmap_camera_readback import read_cameras, read_registered  # noqa: E402

FIELDS = ['GpsStatus', 'AltitudeType', 'RtkFlag', 'RtkStdLon', 'RtkStdLat', 'RtkStdHgt', 'GpsLatitude', 'GpsLongitude', 'AbsoluteAltitude',
          'RelativeAltitude', 'GimbalPitchDegree', 'FlightPitchDegree', 'FlightRollDegree', 'LRFStatus', 'LRFTargetDistance', 'LRFTargetAlt',
          'LRFTargetAbsAlt', 'ShutterType', 'DroneModel', 'ProductName', 'UTCAtExposure', 'FlightXSpeed', 'FlightYSpeed']


def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def stats(x):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    if not len(x): return {'n': 0}
    return {'n': int(len(x)), 'median': float(np.median(x)), 'p5': float(np.percentile(x, 5)), 'p25': float(np.percentile(x, 25)),
            'p75': float(np.percentile(x, 75)), 'p95': float(np.percentile(x, 95)), 'mean': float(np.mean(x))}


def xmp(path):
    b = path.open('rb').read(262144); i = b.find(b'<x:xmpmeta'); j = b.find(b'</x:xmpmeta>')
    text = b[i:j].decode('utf-8', 'replace') if i >= 0 else ''
    tags = dict(re.findall(r'drone-dji:(\w+)="([^"]*)"', text))
    return {k: tags.get(k) for k in FIELDS}


def enu(lat, lon, h, lat0, lon0, h0):
    a = 6378137.0; f = 1 / 298.257223563; e2 = f * (2 - f)
    def ecef(la, lo, hh):
        la, lo = np.radians(la), np.radians(lo); n = a / np.sqrt(1 - e2 * np.sin(la) ** 2)
        return np.c_[(n + hh) * np.cos(la) * np.cos(lo), (n + hh) * np.cos(la) * np.sin(lo), (n * (1 - e2) + hh) * np.sin(la)]
    d = ecef(lat, lon, h) - ecef(np.array([lat0]), np.array([lon0]), np.array([h0]))
    la, lo = np.radians(lat0), np.radians(lon0)
    R = np.array([[-np.sin(lo), np.cos(lo), 0], [-np.sin(la) * np.cos(lo), -np.sin(la) * np.sin(lo), np.cos(la)], [np.cos(la) * np.cos(lo), np.cos(la) * np.sin(lo), np.sin(la)]])
    return d @ R.T


def umeyama(src, dst):
    ms, md = src.mean(0), dst.mean(0); X, Y = src - ms, dst - md
    U, S, Vt = np.linalg.svd(Y.T @ X / len(src)); D = np.eye(3); D[2, 2] = np.sign(np.linalg.det(U @ Vt))
    R = U @ D @ Vt; s = np.trace(np.diag(S) @ D) / (X ** 2).sum(1).mean(); return s, R, md - s * R @ ms


def tin_centre(uv, z, centre):
    lin = LinearNDInterpolator(uv, z)(centre[None])[0]
    return float(lin) if np.isfinite(lin) else float(NearestNDInterpolator(uv, z)(centre[None])[0])


def main():
    tic = time.monotonic(); out = RUNS / ('revision_v041_lrf_' + datetime.now().strftime('%Y%m%d_%H%M%S')); out.mkdir()
    (out / 'revision_v041_lrf_check.py').write_bytes(Path(__file__).read_bytes())
    meta = read(SURVEY / 'report.json'); names = {r['index']: r['name'] for r in meta['images']}
    images = read(BASE / 'data_audit/images.json'); folder = Path(os.environ.get('BRIDGERECON_IMAGES', ROOT / 'images'))
    tags = []
    for r in images:
        p = ROOT / r['file'] if (ROOT / r['file']).exists() else next(folder.rglob(Path(r['file']).name))
        tags.append(xmp(p))
    num = lambda k: np.array([float(t[k]) if t[k] not in (None, '') else np.nan for t in tags])
    lat, lon, alt = num('GpsLatitude'), num('GpsLongitude'), num('AbsoluteAltitude')
    lrf = num('LRFTargetDistance'); lrf_ok = np.array([t['LRFStatus'] == 'Normal' for t in tags]) & np.isfinite(lrf) & (lrf > 3)
    rtk = np.array([t['RtkFlag'] == '50' for t in tags])
    P = enu(lat, lon, alt, lat[0], lon[0], alt[0])
    report = {'status': 'running', 'created': datetime.now().astimezone().isoformat(), 'gpu_used': False,
              'metadata': {'drone': sorted({t['DroneModel'] for t in tags}), 'camera': sorted({t['ProductName'] for t in tags}),
                           'gps_status': sorted({t['GpsStatus'] for t in tags}), 'altitude_type': sorted({t['AltitudeType'] for t in tags}),
                           'rtk_fixed_images': int(rtk.sum()), 'images': len(tags), 'shutter': sorted({t['ShutterType'] for t in tags}),
                           'rtk_std_lon_m': stats(num('RtkStdLon')), 'rtk_std_lat_m': stats(num('RtkStdLat')), 'rtk_std_hgt_m': stats(num('RtkStdHgt')),
                           'lrf_normal_images_main': int(lrf_ok[:576].sum()), 'lrf_distance_main_m': stats(lrf[:576][lrf_ok[:576]]),
                           'relative_altitude_main_m': stats(num('RelativeAltitude')[:576]), 'utc_first': tags[0]['UTCAtExposure'], 'utc_last_main': tags[575]['UTCAtExposure']}}

    # 1. Camera centres against RTK positions (one similarity per configuration, all 576 main-route images).
    cams = {}
    for label, run in CASES.items():
        prep = Path(read(RUNS / run / 'report.json')['preparation']); g = np.load(prep / 'global_cameras.npz')
        E, idx = g['extrinsics'], g['image_indices']; sel = idx < 576; order = np.argsort(idx[sel])
        C = -np.einsum('nji,nj->ni', E[sel][order][:, :, :3], E[sel][order][:, :, 3]); T = P[:576]
        s, R, t = umeyama(C, T); fitted = (s * (R @ C.T)).T + t; d = fitted - T
        cams[label] = {'similarity_scale': float(s), 'residual_3d_m': stats(np.linalg.norm(d, axis=1)), 'horizontal_m': stats(np.linalg.norm(d[:, :2], axis=1)),
                       'vertical_abs_m': stats(abs(d[:, 2])), 'rms_3d_m': float(np.sqrt((np.linalg.norm(d, axis=1) ** 2).mean()))}
    report['camera_centres_vs_rtk'] = cams

    # 2. Depth along the optical axis at the principal point versus LRF distance.
    centre_input = np.array([800 * (518 / 1600) - 0.5, 600 * (392 / 1200) - 0.5])  # principal point (800, 600) in the 518x392 input grid
    rows = [{'index': i, 'lrf_m': float(lrf[i]) if lrf_ok[i] else None, 'rtk_fixed': bool(rtk[i])} for i in range(576)]
    for label in ['C1', 'C2', 'C3', 'C4', 'C5']:
        run = RUNS / CASES[label]; rep = read(run / 'report.json'); prep = Path(rep['preparation']); views = {v['index']: v for v in read(prep / 'report.json')['views']}
        owner = {}
        for c in rep['chunks']:
            for slot, i in enumerate(c['image_indices']): owner.setdefault(i, (c, slot))
        cache = {}
        for i in range(576):
            a = np.load(prep / views[i]['file']); use = a['train_eligible'] & np.isfinite(a['train_z']) & (a['train_z'] > 0)
            rows[i][label + '_A1'] = float(np.median(a['train_z'][use])); rows[i][label + '_A3'] = tin_centre(a['train_uv'][use], a['train_z'][use], centre_input)
            c, slot = owner[i]; key = c['input']
            if key not in cache: cache = {key: np.load(key)['depth']}
            dmap = cache[key][slot, ..., 0]; d = float(sample(dmap, centre_input[None])[0])
            q = c['similarity']['scale'] * c['depth_fit']['views'][slot]['applied_scale']
            rows[i][label + '_V3'] = d * q if d > 0 else None
            rows[i][label + '_V1'] = d * c['similarity']['scale'] if d > 0 else None
    # MVS 1600 (C5 cameras): sample the geometric depth map at the undistorted principal point; local spread in +/-10 px.
    original = read(Path(read(PRIMARY / 'report.json')['preparation']) / 'native_cameras.json')
    native = read_cameras(ATTEMPT / 'dense/sparse'); poses = read_registered(ATTEMPT / 'dense/sparse')
    for i in range(576):
        pose = poses[names[i]]; und = native[pose['camera_id']]; fx, fy, cx, cy, _ = camera_parameters(und)
        m = map_view(ATTEMPT / 'dense/stereo/depth_maps' / (names[i] + '.geometric.bin'))[..., 0]
        x, y = int(round(cx)), int(round(cy)); win = np.array(m[y - 10:y + 11, x - 10:x + 11], float); win[~(win > 0)] = np.nan
        rows[i]['MVS'] = float(win[10, 10]) if np.isfinite(win[10, 10]) else (float(np.nanmedian(win)) if np.isfinite(win).any() else None)
        rows[i]['MVS_window_range_m'] = float(np.nanmax(win) - np.nanmin(win)) if np.isfinite(win).sum() > 20 else None
    with (out / 'per_image_centre_depths.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    flat = np.array([r['MVS_window_range_m'] is not None and r['MVS_window_range_m'] < 1.0 for r in rows])
    ok = np.array([r['lrf_m'] is not None for r in rows]); L = np.array([r['lrf_m'] if r['lrf_m'] else np.nan for r in rows])
    comp = {}
    for col in [c + '_' + k for c in ['C1', 'C2', 'C3', 'C4', 'C5'] for k in ['A1', 'A3', 'V3']] + ['C5_V1', 'MVS']:
        v = np.array([r.get(col) if r.get(col) is not None else np.nan for r in rows], float)
        for scope, msk in [('all_lrf', ok), ('locally_flat_centre', ok & flat)]:
            good = msk & np.isfinite(v)
            ratio = v[good] / L[good]; resid = (ratio / np.median(ratio) - 1) * L[good] if good.any() else np.array([])
            comp.setdefault(col, {})[scope] = {'ratio_to_lrf': stats(ratio), 'difference_m': stats(v[good] - L[good]), 'abs_difference_m': stats(abs(v[good] - L[good])),
                                               'abs_residual_after_median_ratio_m': stats(abs(resid))}
    report['centre_depth_vs_lrf'] = comp; report['flat_centre_images'] = int((ok & flat).sum())
    report['definitions'] = {'centre_pixel_input': centre_input.tolist(), 'flat': 'MVS depth range within +/-10 px (1600-px image) below 1 m',
                             'A1': 'median calibration-anchor depth', 'A3': 'piecewise-linear anchor interpolation at the principal point',
                             'V1/V3': 'VGGT depth at the principal point times s_k (V1) or s_k q_ki (V3)', 'MVS': 'COLMAP 1600-px geometric depth at the principal point',
                             'lrf': 'LRFTargetDistance with LRFStatus Normal; nominal coaxial with the camera axis; manufacturer accuracy not re-verified'}
    report.update(status='completed', seconds=time.monotonic() - tic)
    (out / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding='utf-8'); print('REPORT', out)


if __name__ == '__main__':
    main()
