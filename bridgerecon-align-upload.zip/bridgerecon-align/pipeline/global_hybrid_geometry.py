"""Distortion-aware camera geometry and training-only scalar depth fitting."""
import numpy as np
from scipy.spatial.transform import Rotation
from geometry_core import camera_centers
from route_chunk_geometry import transform_extrinsics
from local_validation import sample,inside

VARIANTS=['camera_aligned_raw','global_camera','chunk_depth_scale','view_depth_scale']


def camera_parameters(camera):
    p=np.array(camera['params'],float);kind=camera['model']
    if kind=='SIMPLE_RADIAL':return p[0],p[0],p[1],p[2],p[3]
    if kind=='SIMPLE_PINHOLE':return p[0],p[0],p[1],p[2],0.
    if kind=='PINHOLE':return p[0],p[1],p[2],p[3],0.
    raise ValueError('Unsupported native camera '+kind)


def native_rays(uv,camera,A):
    native=(np.c_[uv,np.ones(len(uv))]@np.linalg.inv(A).T)[:,:2]
    fx,fy,cx,cy,k=camera_parameters(camera)
    distorted=(native-[cx,cy])/[fx,fy];rd=np.linalg.norm(distorted,axis=1);ru=rd.copy()
    for _ in range(12):
        derivative=1+3*k*ru*ru
        if np.any(derivative<=0):raise ValueError('Nonmonotonic radial projection')
        ru-=(ru+k*ru**3-rd)/derivative
    assert np.max(abs(ru+k*ru**3-rd),initial=0)<1e-9
    ratio=np.divide(ru,rd,out=np.ones_like(ru),where=rd>1e-15)
    return np.c_[distorted*ratio[:,None],np.ones(len(uv))]


def unproject_native(uv,depth,E,camera,A):
    return (native_rays(uv,camera,A)*np.asarray(depth)[:,None]-E[:,3])@E[:,:3]


def project_native(xyz,E,camera,A):
    points=np.asarray(xyz)@E[:,:3].T+E[:,3];z=points[:,2]
    denominator=np.where(abs(z)<1e-12,np.nan,z);xy=points[:,:2]/denominator[:,None]
    fx,fy,cx,cy,k=camera_parameters(camera)
    uv=xy*(1+k*np.sum(xy*xy,axis=1))[:,None]*[fx,fy]+[cx,cy]
    return uv@A[:2,:2].T+A[:2,2],z


def camera_alignment(local,global_E):
    rotations=global_E[:,:,:3].transpose(0,2,1)@local[:,:,:3]
    R=Rotation.from_matrix(rotations).mean().as_matrix()
    a=camera_centers(local);b=camera_centers(global_E)
    x=(a-a.mean(axis=0))@R.T;y=b-b.mean(axis=0)
    scale=float(np.sum(x*y)/np.sum(x*x))
    if not np.isfinite(scale) or scale<=0:raise ValueError('Unsupported camera-motion similarity')
    model=(scale,R,b.mean(axis=0)-scale*R@a.mean(axis=0))
    fitted=transform_extrinsics(local,model)
    angles=np.degrees(Rotation.from_matrix(fitted[:,:,:3]@global_E[:,:,:3].transpose(0,2,1)).magnitude())
    return model,{'motion_scale':scale,'camera_center_rms_global_units':float(np.sqrt(np.mean(np.sum((camera_centers(fitted)-b)**2,axis=1)))),
                  'camera_rotation_p95_deg':float(np.percentile(angles,95)),
                  'scope':'Fit agreement to source SfM, not independent camera accuracy'}


def fit_depth_scales(data,anchors,motion_scale):
    ratios=[];per_view=[]
    for slot,anchor in enumerate(anchors):
        uv=anchor['train_uv'];z=anchor['train_z'];eligible=anchor['train_eligible']&inside(uv)
        d=sample(data['depth'][slot,...,0],uv);c=sample(data['depth_conf'][slot],uv)
        good=eligible&(z>0)&(d>0)&(c>=1.2)&np.isfinite(z)&np.isfinite(d)
        log_ratio=np.log(z[good]/(motion_scale*d[good]))
        ratios.append(log_ratio)
        per_view.append({'training_anchors':int(good.sum()),'raw_scale':float(np.exp(np.median(log_ratio))) if len(log_ratio)>=20 else None})
    pooled=np.concatenate(ratios)
    supported=len(pooled)>=100
    chunk=float(np.exp(np.median(pooled))) if supported else 1.
    for view in per_view:
        raw=view['raw_scale'];valid=supported and raw is not None and .8<=raw/chunk<=1.25
        view.update(applied_scale=raw if valid else chunk,view_specific_accepted=bool(valid),
                    fallback_reason=None if valid else ('chunk_insufficient_support' if not supported else 'view_support_or_relative_scale_bound'))
    return {'chunk_supported':bool(supported),'pooled_training_observations':len(pooled),'chunk_scale':chunk,
            'views':per_view,'checking_residual_access':False}
