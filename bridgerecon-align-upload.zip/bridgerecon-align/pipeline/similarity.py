"""Positive-scale rigid similarity; no affine warp or reference geometry."""
import numpy as np

def fit_similarity(source,target):
    source=np.asarray(source,float);target=np.asarray(target,float)
    mx=source.mean(axis=0);my=target.mean(axis=0)
    x=source-mx;y=target-my
    u,d,vt=np.linalg.svd(x.T@y/len(x))
    sign=np.ones(3);sign[-1]=np.sign(np.linalg.det(vt.T@u.T))
    rot=vt.T@np.diag(sign)@u.T
    variance=np.mean(np.sum(x*x,axis=1))
    if variance<1e-12:raise ValueError('Degenerate source scale')
    scale=float(np.sum(d*sign)/variance)
    if scale<=0:raise ValueError('Non-positive scale')
    trans=my-scale*(rot@mx)
    return scale,rot,trans

def apply_similarity(points,model):
    scale,rotation,translation=model
    return scale*np.asarray(points)@rotation.T+translation

def robust_similarity(source,target,threshold,seed=20261017):
    source=np.asarray(source);target=np.asarray(target)
    if len(source)<12:raise ValueError('At least 12 unique landmarks required')
    rng=np.random.default_rng(seed);best=None;best_score=(-1,-np.inf)
    for _ in range(300):
        ids=rng.choice(len(source),3,replace=False)
        if np.linalg.svd(source[ids]-source[ids].mean(axis=0),compute_uv=False)[1]<1e-5:continue
        try:model=fit_similarity(source[ids],target[ids])
        except ValueError:continue
        errors=np.linalg.norm(apply_similarity(source,model)-target,axis=1)
        mask=errors<threshold;score=(int(mask.sum()),-float(np.median(errors[mask])) if mask.any() else -np.inf)
        if score>best_score:best_score=score;best=mask
    if best is None or best.sum()<12:raise ValueError('No supported similarity')
    for _ in range(3):
        model=fit_similarity(source[best],target[best])
        errors=np.linalg.norm(apply_similarity(source,model)-target,axis=1)
        updated=errors<threshold
        if updated.sum()<12:break
        best=updated
    model=fit_similarity(source[best],target[best])
    return model,best,np.linalg.norm(apply_similarity(source,model)-target,axis=1)

def resize_crop_transform(width,height,box,output_width=518,output_height=392):
    """Original pixel centers -> crop pixel centers, matching PIL resize."""
    x0,y0,x1,y1=box;sx=output_width/(x1-x0);sy=output_height/(y1-y0)
    return np.array([[sx,0,sx*(.5-x0)-.5],[0,sy,sy*(.5-y0)-.5],[0,0,1.]])
