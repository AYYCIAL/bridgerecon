"""Interpolate cached 2D matches at exact sparse feature coordinates."""
import numpy as np
import cv2
from scipy.spatial import cKDTree


def local_affine(source,target,anchors):
    source=np.asarray(source,float);target=np.asarray(target,float);anchors=np.asarray(anchors,float)
    output=np.full_like(anchors,np.nan);quality=np.full(len(anchors),np.inf);valid=np.zeros(len(anchors),bool)
    if len(source)<6:return output,valid,quality
    distance,nearest=cKDTree(source).query(anchors,k=min(12,len(source)))
    for i,(anchor,d,ids) in enumerate(zip(anchors,distance,nearest)):
        use=d<=20.
        if use.sum()<6:continue
        x=source[ids[use]]-anchor;y=target[ids[use]];d=d[use]
        singular=np.linalg.svd(x-x.mean(axis=0),compute_uv=False)
        if singular[1]/max(singular[0],1e-12)<.05:continue
        hull=cv2.convexHull(x.astype('float32'))
        if cv2.pointPolygonTest(hull,(0.,0.),False)<0:continue
        B=np.c_[x,np.ones(len(x))];base=1/(1+(d/8.)**2);weight=base.copy()
        for _ in range(8):
            fit=np.linalg.lstsq(B*np.sqrt(weight)[:,None],y*np.sqrt(weight)[:,None],rcond=None)[0]
            error=np.linalg.norm(B@fit-y,axis=1);weight=base*np.minimum(1.,1./np.maximum(error,1e-12))
        median=float(np.median(error));jac=np.linalg.svd(fit[:2],compute_uv=False)
        if median>3 or jac.min()<.1 or jac.max()>10:continue
        output[i]=fit[2];quality[i]=median;valid[i]=True
    return output,valid,quality


if __name__=='__main__':
    y,x=np.mgrid[0:81:8,0:81:8];source=np.c_[x.ravel(),y.ravel()].astype(float)
    M=np.array([[1.1,.2],[-.1,.8]]);target=source@M+[3.,-2.]
    anchors=np.array([[30.3,35.7],[41.1,51.2],[-2.,40.]])
    predicted,valid,error=local_affine(source,target,anchors)
    assert valid.tolist()==[True,True,False]
    assert np.max(abs(predicted[:2]-(anchors[:2]@M+[3.,-2.])))<1e-10
    print('PASS: exact feature-coordinate affine transfer and extrapolation rejection')
