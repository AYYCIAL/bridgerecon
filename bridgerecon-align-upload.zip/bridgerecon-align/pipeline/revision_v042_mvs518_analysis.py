"""v0.42: full-route COLMAP MVS at 518 px (primary C5 cameras) against V3 and MVS at 1600 px.

Quality on the fixed pair inventory (own support, pairs common to V3 and both MVS settings, route-block
bootstrap as in v0.41), depth at the principal point against the rangefinder (v0.41 definitions), the
recorded job time and the sampled device memory. CPU only; reads frozen outputs and the new attempt;
writes runs/revision_v042_mvs518_<stamp>/report.json.
"""
from pathlib import Path
from datetime import datetime
import argparse, csv, json, shutil, sys, time
import numpy as np

BASE = Path(__file__).resolve().parent; RUNS = BASE / 'runs'
sys.path.insert(0, str(BASE))
from revision_v041_analysis import PRIMARY, MVS, MVS_DEPTH, block_histograms, quantile_from_hist, stats  # noqa: E402
from audit_native_depth_maps import map_view  # noqa: E402
from colmap_camera_readback import read_cameras, read_registered  # noqa: E402
from global_hybrid_geometry import camera_parameters  # noqa: E402


def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))


def centre_depths(attempt, names, half):
    """Geometric depth at the undistorted principal point; nan-median of a +/-half window if the centre is invalid."""
    native = read_cameras(attempt / 'dense/sparse'); poses = read_registered(attempt / 'dense/sparse'); out = np.full(576, np.nan)
    for i in range(576):
        pose = poses[names[i]]; fx, fy, cx, cy, _ = camera_parameters(native[pose['camera_id']])
        m = map_view(attempt / 'dense/stereo/depth_maps' / (names[i] + '.geometric.bin'))[..., 0]
        x, y = int(round(cx)), int(round(cy)); win = np.array(m[y - half:y + half + 1, x - half:x + half + 1], float); win[~(win > 0)] = np.nan
        out[i] = win[half, half] if np.isfinite(win[half, half]) else (np.nanmedian(win) if np.isfinite(win).any() else np.nan)
    return out


def lrf_stats(v, L, flat):
    res = {}
    for scope, m in [('all', np.isfinite(L)), ('flat', np.isfinite(L) & flat)]:
        gd = m & np.isfinite(v); ratio = v[gd] / L[gd]; resid = abs((ratio / np.median(ratio) - 1) * L[gd])
        res[scope] = {'n': int(gd.sum()), 'bias_pct': float((np.median(ratio) - 1) * 100), 'scatter_median_m': float(np.median(resid)), 'scatter_p95_m': float(np.percentile(resid, 95))}
    return res


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--attempt', type=Path, required=True); ap.add_argument('--evaluation', type=Path, required=True)
    ap.add_argument('--ledger-job', required=True); ap.add_argument('--gpu-samples', type=Path); args = ap.parse_args()
    tic = time.monotonic(); out = RUNS / ('revision_v042_mvs518_' + datetime.now().strftime('%Y%m%d_%H%M%S')); out.mkdir()
    (out / 'revision_v042_mvs518_analysis.py').write_bytes(Path(__file__).read_bytes())
    attempt, evaluation = args.attempt.resolve(), args.evaluation.resolve(); state = read(attempt / 'report.json'); ev = read(evaluation / 'report.json')
    assert state['status'] == 'depth_maps_completed' and state['input_unchanged'] and state['settings']['width'] == 518 and Path(ev['attempt']) == attempt
    p = np.load(PRIMARY / 'checking_pairs.npz'); s = np.load(PRIMARY / 'checking_samples.npz'); m16 = np.load(MVS / 'checking_pairs.npz'); m5 = np.load(evaluation / 'checking_pairs.npz')
    for other in (m16, m5): assert np.array_equal(p['source'], other['source']) and np.array_equal(p['target'], other['target'])
    errors = {'V3': p['errors'][:, 3], 'MVS518': m5['errors'], 'MVS1600': m16['errors']}; support = {'V3': p['supported'][:, 3], 'MVS518': m5['supported'], 'MVS1600': m16['supported']}
    full = len(p['source']); common = support['V3'] & support['MVS518'] & support['MVS1600']; five = p['supported'].all(axis=1) & support['MVS1600']
    report = {'status': 'running', 'created': datetime.now().astimezone().isoformat(), 'gpu_used': False, 'attempt': str(attempt), 'evaluation': str(evaluation),
              'settings': state['settings'], 'methods': {}, 'common_pairs': int(common.sum()), 'full_pairs': full}
    for k in errors:
        e, ok = errors[k], support[k]
        report['methods'][k] = {'support_fraction': float(ok.mean()), 'success_below2px_full_inventory': float(np.sum(ok & (e < 2)) / full), 'own_support': stats(e[ok]),
                                'three_method_common': stats(e[common]), 'v041_five_method_set_where_supported': stats(e[five & ok]),
                                'pairs_on_v041_five_method_set_supported': int((five & ok).sum())}
    # Route-block bootstrap (72 groups of eight source photographs), identical to v0.41.
    block = s['view'][p['source']] // 8; edges = np.geomspace(1e-3, 1e3, 6001); rng = np.random.default_rng(20261023)
    w = np.stack([np.bincount(rng.integers(0, 72, 72), minlength=72) for _ in range(2000)]).astype(float)
    med, p95 = {}, {}
    for k in errors:
        h = w @ block_histograms(errors[k], common, block, edges); med[k] = quantile_from_hist(h, edges, .5); p95[k] = quantile_from_hist(h, edges, .95)
    boot = {'median': {}, 'p95': {}, 'differences_median': {}}
    for k in errors:
        boot['median'][k] = {'point': float(np.median(errors[k][common])), 'ci95': np.percentile(med[k], [2.5, 97.5]).tolist()}
        boot['p95'][k] = {'point': float(np.percentile(errors[k][common], 95)), 'ci95': np.percentile(p95[k], [2.5, 97.5]).tolist()}
    for a, b in [('MVS518', 'V3'), ('MVS1600', 'MVS518'), ('MVS1600', 'V3')]:
        d = med[a] - med[b]; boot['differences_median'][f'{a}-{b}'] = {'point': boot['median'][a]['point'] - boot['median'][b]['point'], 'ci95': np.percentile(d, [2.5, 97.5]).tolist(), 'fraction_resamples_positive': float(np.mean(d > 0))}
    blocks = {k: np.array([np.median(errors[k][common & (block == g)]) for g in range(72)]) for k in errors}
    boot['blocks_MVS518_below_V3'] = int(np.sum(blocks['MVS518'] < blocks['V3'])); boot['blocks_MVS1600_below_MVS518'] = int(np.sum(blocks['MVS1600'] < blocks['MVS518']))
    report['bootstrap_three_method_common'] = boot
    # Depth at the principal point against the rangefinder (flat set and LRF values from the v0.41 run).
    lrf_run = sorted(RUNS.glob('revision_v041_lrf_*'))[-1]; rows = list(csv.DictReader((lrf_run / 'per_image_centre_depths.csv').open(encoding='utf-8')))
    L = np.array([float(r['lrf_m']) if r['lrf_m'] not in ('', 'None') else np.nan for r in rows])
    flat = np.array([r['MVS_window_range_m'] not in ('', 'None') and float(r['MVS_window_range_m']) < 1.0 for r in rows])
    mvs1600 = np.array([float(r['MVS']) if r['MVS'] not in ('', 'None') else np.nan for r in rows])
    names = {r['index']: r['name'] for r in read(BASE / 'runs/full_route_survey_20261018_221243_8084fdb4/report.json')['images']}
    half = int(round(10 * 518 / 1600)); d518 = centre_depths(attempt, names, half)
    report['centre_depth_vs_lrf'] = {'MVS518': lrf_stats(d518, L, flat), 'MVS1600_reproduced': lrf_stats(mvs1600, L, flat), 'lrf_run': lrf_run.name,
                                     'window_half_px_518': half, 'centre_valid_518': int(np.isfinite(d518).sum())}
    with (out / 'centre_depths_mvs518.csv').open('w', newline='', encoding='utf-8') as f:
        wr = csv.writer(f); wr.writerow(['index', 'lrf_m', 'mvs518_m', 'mvs1600_m']); wr.writerows([[i, L[i], d518[i], mvs1600[i]] for i in range(576)])
    # Time and memory.
    ledger = read(BASE / 'gpu_ledger.json'); job = next(j for j in ledger['jobs'] if j['id'] == args.ledger_job); readback = read(attempt / 'depth_maps_readback.json')
    report['timing'] = {'ledger_job': job['id'], 'ledger_name': job['name'], 'charged_seconds': job['charged_seconds'], 'status': job['status'],
                        'launch_seconds': state['launches'][-1]['seconds'], 'stages': [{k: st.get(k) for k in ('name', 'seconds', 'status')} for st in state['stages']],
                        'mvs1600_charged_seconds': next(j['charged_seconds'] for j in ledger['jobs'] if j['id'] == '20261019_205033_0dbb08'),
                        'positive_depth_fraction': readback['positive_depth_fraction'], 'negative_depth_count': readback['negative_depth_count'],
                        'depth_map_shape': readback['maps'][0]['shape']}
    if args.gpu_samples:
        shutil.copy(args.gpu_samples, out / 'gpu_samples.csv'); t0 = datetime.fromisoformat(job['started_utc']).timestamp(); t1 = datetime.fromisoformat(job['ended_utc']).timestamp()
        used = []
        for line in args.gpu_samples.read_text(encoding='utf-8').splitlines():
            parts = [x.strip() for x in line.split(',')]
            if len(parts) < 3: continue
            stamp = datetime.strptime(parts[0], '%Y/%m/%d %H:%M:%S.%f').astimezone().timestamp()
            if t0 <= stamp <= t1: used.append(float(parts[1].split()[0]))
        report['timing']['device_memory_MiB'] = {'samples': len(used), 'max': max(used) if used else None, 'median': float(np.median(used)) if used else None,
                                                 'note': 'nvidia-smi memory.used every 2 s within the job window, started after launch; includes other processes'}
    report.update(status='completed', seconds=time.monotonic() - tic)
    (out / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding='utf-8'); print('REPORT', out)


if __name__ == '__main__':
    main()
