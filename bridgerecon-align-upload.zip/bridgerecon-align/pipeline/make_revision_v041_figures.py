"""v0.41 manuscript figures from frozen outputs: unified labels, units and panel letters.

Plotting only. Inputs are the recorded run summaries/arrays and the v0.41 review-response
analysis run; no reconstruction, fitting or GPU use.
"""
from pathlib import Path
import json, re, sys
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle

ROOT = Path(__file__).resolve().parent.parent
E = ROOT / 'experiments'; RUNS = E / 'runs'; OUT = ROOT / 'paper/figures'
PRIMARY = RUNS / 'global_hybrid_20261019_205203_28fc26c6'
MVS = RUNS / 'native_mvs_checking_20261020_001654_cd47ff08'
SUMMARY = RUNS / 'full_hybrid_summary_20261019_210510_6aff3186'
EVENING = RUNS / 'evening_comparison_20261020_002449_7579120e'
SEAMS = RUNS / 'full_hybrid_seams_20261019_211732_4f0b9df9'
META = RUNS / 'metashape_checking_20261021_195938'
RESOURCES = RUNS / 'revision_resources_20261022_140332_9fe28f50'
ANALYSIS = sorted(RUNS.glob('revision_v041_analysis_*'))[-1]

plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9.5, 'pdf.fonttype': 42, 'axes.spines.top': False,
                     'axes.spines.right': False, 'legend.frameon': False})
VAR = ['camera_aligned_raw', 'global_camera', 'chunk_depth_scale', 'view_depth_scale']
VLAB = {'camera_aligned_raw': 'V0 aligned VGGT', 'global_camera': 'V1 global cameras',
        'chunk_depth_scale': 'V2 chunk scale', 'view_depth_scale': 'V3 per-image scale'}
COL = {'camera_aligned_raw': '#8c8c8c', 'global_camera': '#c49a4a', 'chunk_depth_scale': '#6c9bb6',
       'view_depth_scale': '#155a86', 'mvs1600': '#18866d', 'metashape': '#ae4769',
       'anchor_constant': '#d95f02', 'anchor_plane': '#e6ab02', 'anchor_tin': '#7570b3'}
CASES = ['original_free', 'free_no_position_100', 'free_position10_100', 'fixed_no_position_100', 'fixed_position10_100', 'shared_height1_converged']
CLAB = ['C0 initial solution', 'C1 free intrinsics', 'C2 free + position prior', 'C3 fixed focal', 'C4 fixed focal + position prior', 'C5 shared + height prior']
CCOL = ['#bdbdbd', '#8c8c8c', '#c49a4a', '#9ecae1', '#4a90b8', '#155a86']
CSTY = ['-', '--', '-', '-', '--', '-']


def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(fig, name):
    fig.savefig(OUT / (name + '.png'), dpi=220, bbox_inches='tight', facecolor='white')
    fig.savefig(OUT / (name + '.pdf'), dpi=220, bbox_inches='tight', facecolor='white'); plt.close(fig)
def letter(ax, s): ax.text(-0.11, 1.03, s, transform=ax.transAxes, fontsize=11, fontweight='bold', va='bottom')
def cdf(ax, x, label, color, ls='-', lw=1.7):
    x = np.sort(x[np.isfinite(x)]); ax.plot(x, np.arange(1, len(x) + 1) / len(x), ls, color=color, lw=lw, label=label)


def workflow():
    fig, ax = plt.subplots(figsize=(13, 4.6)); ax.set(xlim=(0, 13), ylim=(0, 4.6)); ax.axis('off')
    navy, line = '#16394d', '#557888'
    def box(x, y, w, h, title, body, tint='#eef4f7'):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.02,rounding_size=0.06', fc=tint, ec=line, lw=0.9))
        ax.text(x + .12, y + h - .12, title, ha='left', va='top', weight='bold', fontsize=9.6, color=navy)
        ax.text(x + .12, y + h - .45, body, ha='left', va='top', fontsize=8.6, color='#324e5b', linespacing=1.35)
    def arrow(a, b): ax.add_patch(FancyArrowPatch(a, b, arrowstyle='-|>', mutation_scale=12, lw=1.1, color=line, shrinkA=2, shrinkB=2))
    for x, t in [(0.15, 'Inputs'), (4.55, 'Depth calibration (training-free)'), (8.95, 'Assessment on held-out evidence')]:
        ax.text(x, 4.45, t, fontsize=10, weight='bold', color='#147a72', va='center')
    box(0.15, 3.0, 4.0, 1.2, 'UAV survey', 'Two-pass nadir route, 576 images\n8064×6048 originals; 1600 px for SfM')
    box(0.15, 1.6, 4.0, 1.2, 'Global SfM (COLMAP)', 'Cameras C0–C5 and sparse points\nHash split: 80% anchors / 20% evaluation')
    box(0.15, 0.2, 4.0, 1.2, 'Frozen VGGT', '12-image chunks, stride 8, 4 shared\nDepth d and confidence c at 518×392')
    box(4.55, 3.0, 4.0, 1.2, 'V0 / V1: camera placement', 'V0: chunk similarity ($s_k$) to SfM cameras\nV1: SfM poses and rays, depth $s_k\\,d$')
    box(4.55, 1.6, 4.0, 1.2, 'V2: pooled chunk scale', r'$q_k=\exp\,\mathrm{median}\,\log[z/(s_k\,d)]$' + '\n' + r'at least 100 anchors, confidence $\geq 1.2$', '#e3f1ed')
    box(4.55, 0.2, 4.0, 1.2, 'V3: bounded per-image scale', r'$q_{ki}$ from $\geq 20$ anchors of image $i$' + '\n' + r'accepted within $[0.8,\,1.25]\,q_k$', '#e3f1ed')
    box(8.95, 3.0, 3.9, 1.2, 'Cross-view consistency', '691,694 directed evaluation pairs\nDiscrepancy, support, <2 px success')
    box(8.95, 1.6, 3.9, 1.2, 'Seams and strata', '71 overlaps, repeated images\nBridge-associated image regions')
    box(8.95, 0.2, 3.9, 1.2, 'Reference methods and cost', 'Anchor-only A1–A3; COLMAP MVS;\nMetashape; time and GPU memory')
    for y in (3.6, 2.2, 0.8): arrow((4.15, y), (4.55, y))
    arrow((6.55, 3.0), (6.55, 2.8)); arrow((6.55, 1.6), (6.55, 1.4))
    for y in (3.6, 2.2, 0.8): arrow((8.55, y), (8.95, y))
    save(fig, 'sfm_vggt_workflow_v041')


def survey():
    d = read(E / 'data_audit/images.json'); lat = np.array([r['GpsLatitude'] for r in d]); lon = np.array([r['GpsLongitude'] for r in d])
    R = 6378137.0; x = np.radians(lon - lon[0]) * R * np.cos(np.radians(lat[0])); y = np.radians(lat - lat[0]) * R
    P = np.c_[x, y]; c = P[:576].mean(0); _, _, vt = np.linalg.svd(P[:576] - c, full_matrices=False); u = vt[0]
    if u @ (P[281] - P[0]) < 0: u = -u
    v = np.array([-u[1], u[0]]); A = (P - c) @ u; B = (P - c) @ v
    fig = plt.figure(figsize=(13, 6.2), layout='constrained'); gs = fig.add_gridspec(2, 1, height_ratios=[1, 1.15])
    ax = fig.add_subplot(gs[0])
    ax.plot(A[:282], B[:282], '-', color='#155a86', lw=1.4, label='Pass 1, images 0–281')
    ax.plot(A[282:574], B[282:574], '-', color='#d95f02', lw=1.4, label='Pass 2, images 282–573')
    ax.plot(A[573:576], B[573:576], '-', color='#8c8c8c', lw=1.4, label='Turn, images 574–575')
    ax.scatter(A[576:586], B[576:586], marker='^', s=26, color='#7570b3', zorder=3, label='Oblique, 21–31 m, not reconstructed')
    ax.scatter(A[586:588], B[586:588], marker='*', s=70, color='#18866d', zorder=3, label='Near-nadir at 41 m (calibration only)')
    for s in list(range(0, 561, 8)) + [564]:
        ax.plot([A[s]], [B[s]], '|', color='#155a86' if s <= 281 else '#d95f02', ms=6, alpha=.6)
    ax.annotate('', xy=(A[200], B[200] - 3), xytext=(A[120], B[120] - 3), arrowprops=dict(arrowstyle='->', color='#155a86'))
    ax.annotate('', xy=(A[480], B[480] + 3), xytext=(A[400], B[400] + 3), arrowprops=dict(arrowstyle='->', color='#d95f02'))
    ax.set(xlabel='Along-route distance from route centre (m)', ylabel='Across-route (m)', ylim=(-20, 60))
    ax.legend(loc='upper center', ncol=3, fontsize=8.3, bbox_to_anchor=(0.5, 1.32)); ax.grid(alpha=.15); letter(ax, '(a)')
    ax.text(0.995, 0.04, 'GNSS image positions; ticks mark chunk starts; 2.0 m spacing, 96.2 m relative altitude', transform=ax.transAxes, ha='right', fontsize=8, color='#324e5b')
    ax2 = fig.add_subplot(gs[1]); img = Image.open(OUT / 'bridge_observations_v035.png'); ax2.imshow(img); ax2.axis('off'); letter(ax2, '(b)')
    save(fig, 'survey_geometry_v041')
    return {'route_axis_heading_deg': float(np.degrees(np.arctan2(u[0], u[1]))), 'pass1_across_median_m': float(np.median(B[:282])), 'pass2_across_median_m': float(np.median(B[282:574])),
            'pass_separation_median_m': float(np.median(B[282:574]) - np.median(B[:282])), 'spacing_median_m': float(np.median(np.hypot(np.diff(x[:576]), np.diff(y[:576]))))}


def gsd_axis(ax, metres_per_px, label):
    sec = ax.secondary_xaxis('top', functions=(lambda p: p * metres_per_px, lambda m: m / metres_per_px)); sec.set_xlabel(label, fontsize=8.5); sec.tick_params(labelsize=8)


def camera_depth(gsd):
    curves = read(SUMMARY / 'common_support_cdf.json')
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.4), layout='constrained')
    for k in VAR:
        cv = curves['shared_height1_converged/' + k]; ax[0].plot(cv['pixels'], cv['q'], color=COL[k], lw=1.8, label=VLAB[k])
    for case, lab, col, ls in zip(CASES, CLAB, CCOL, CSTY):
        cv = curves[case + '/view_depth_scale']; ax[1].plot(cv['pixels'], cv['q'], ls, color=col, lw=1.6 if case != CASES[-1] else 2.2, label=lab)
    for a, t in zip(ax, ['Camera configuration C5 (primary)', 'Variant V3 under six camera configurations']):
        a.set(xlim=(0, 10), ylim=(0, 1), xlabel='Cross-view reprojection discrepancy (pixels, 518×392 grid)', ylabel='Cumulative fraction of 560,404 common pairs', title=t)
        a.grid(alpha=.2); a.legend(loc='lower right', fontsize=8.3)
    gsd_axis(ax[0], gsd, 'Image-space distance at ground scale (m, C5)')
    letter(ax[0], '(a)'); letter(ax[1], '(b)'); save(fig, 'camera_depth_consistency_v041')


def anchor_baselines():
    p = np.load(PRIMARY / 'checking_pairs.npz'); m = np.load(MVS / 'checking_pairs.npz'); b = np.load(ANALYSIS / 'baseline_pairs.npz')
    err = {'view_depth_scale': p['errors'][:, 3], 'mvs1600': m['errors']}; sup = {'view_depth_scale': p['supported'][:, 3], 'mvs1600': m['supported']}
    for k in ['anchor_constant', 'anchor_plane', 'anchor_tin']: err[k] = b[k]; sup[k] = b[k + '_supported']
    common = b['common5'] & sup['anchor_constant'] & sup['anchor_plane'] & sup['anchor_tin']
    lab = {'view_depth_scale': 'V3 per-image scale', 'mvs1600': 'COLMAP MVS 1600 px', 'anchor_tin': 'A3 anchor TIN', 'anchor_plane': 'A2 anchor plane', 'anchor_constant': 'A1 constant anchor depth'}
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.4), layout='constrained')
    for k in ['anchor_constant', 'anchor_plane', 'anchor_tin', 'view_depth_scale', 'mvs1600']:
        cdf(ax[0], err[k][common], lab[k], COL[k], '--' if k.startswith('anchor') else '-')
    ax[0].set(xlim=(0, 6), ylim=(0, 1), xlabel='Cross-view reprojection discrepancy (pixels, 518×392 grid)', ylabel=f'Cumulative fraction of {int(common.sum()):,} common pairs', title='Network-free anchor interpolation versus calibrated VGGT')
    ax[0].legend(loc='lower right', fontsize=8.3); ax[0].grid(alpha=.2)
    edges = [0, 5, 10, 20, 40, 80, 300]; base = b['baseline_m']; centres = []; counts = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        sel = common & (base >= lo) & (base < hi); centres.append(np.sqrt(max(lo, 2.5) * hi)); counts.append(int(sel.sum()))
    for k in ['anchor_constant', 'anchor_tin', 'view_depth_scale', 'mvs1600']:
        med = [np.median(err[k][common & (base >= lo) & (base < hi)]) for lo, hi in zip(edges[:-1], edges[1:])]
        ax[1].plot(centres, med, 'o' + ('--' if k.startswith('anchor') else '-'), color=COL[k], lw=1.6, ms=4, label=lab[k])
    ax[1].set(xscale='log', yscale='log', xlabel='Distance between the two camera centres of a pair (m)', ylabel='Median discrepancy (pixels)', title='Dependence on pair baseline')
    for c_, n_ in zip(centres, counts): ax[1].text(c_, 0.125, f'n = {n_:,}', ha='center', fontsize=7.3, color='#555555')
    ax[1].set_ylim(0.1, 20); ax[1].legend(loc='upper left', fontsize=8.3); ax[1].grid(alpha=.2, which='both')
    letter(ax[0], '(a)'); letter(ax[1], '(b)'); save(fig, 'anchor_baselines_v041')
    return {'common_pairs': int(common.sum()), 'bin_counts': counts}


def seams(normaliser):
    vals = np.load(SEAMS / 'seam_normalized_differences.npz')['values']; rep = read(SEAMS / 'report.json')
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.4), layout='constrained')
    for k, v in enumerate(VAR): cdf(ax[0], 100 * vals[:, k], VLAB[v], COL[v])
    ax[0].set(xlim=(0, 15), ylim=(0, 1), xlabel='Seam discrepancy (% of image anchor depth)', ylabel='Cumulative fraction of 674,935 samples', title='71 adjacent-chunk overlaps')
    ax[0].legend(loc='lower right', fontsize=8.3); ax[0].grid(alpha=.2)
    gsd_axis(ax[0], normaliser / 100, f'Approximate distance (m) at a {normaliser:.0f}-m range (rangefinder-corrected)')
    idx = np.arange(1, len(rep['seams']) + 1); worse = []
    for v in VAR:
        p95 = np.array([100 * s['metrics'][v]['p95'] for s in rep['seams']]); ax[1].plot(idx, p95, color=COL[v], lw=1.2, label=VLAB[v])
    raw = np.array([s['metrics']['camera_aligned_raw']['p95'] for s in rep['seams']]); v3 = np.array([s['metrics']['view_depth_scale']['p95'] for s in rep['seams']])
    worse = np.where(v3 > raw)[0]
    ax[1].scatter(idx[worse], 100 * v3[worse], s=36, facecolor='none', edgecolor='k', zorder=4, label='V3 P95 above V0')
    turn = [i for i, s in enumerate(rep['seams'], 1) if min(s['common_images']) <= 281 < max(s['common_images'])]
    for t in turn: ax[1].axvspan(t - .5, t + .5, color='#f0e0c0', alpha=.6, lw=0)
    ax[1].set(yscale='log', xlabel='Overlap index along the route', ylabel='P95 seam discrepancy (%)', title='Per-overlap tail (shaded: overlaps spanning the turn)')
    ax[1].legend(loc='upper left', fontsize=8, ncol=2); ax[1].grid(alpha=.2, which='both')
    letter(ax[0], '(a)'); letter(ax[1], '(b)'); save(fig, 'seam_consistency_v041')
    return {'p95_worse_overlaps': [int(i + 1) for i in worse], 'turn_overlaps': turn}


def route_basis():
    prep = Path(read(PRIMARY / 'report.json')['preparation']); g = np.load(prep / 'global_cameras.npz')
    Ex = g['extrinsics']; idx = g['image_indices']; C = -np.einsum('nji,nj->ni', Ex[:, :, :3], Ex[:, :, 3])
    main = C[idx < 576]; centre = np.median(main, axis=0); _, _, vt = np.linalg.svd(main[:, :2] - main[:, :2].mean(0), full_matrices=False)
    u = vt[0]; order = main[np.argsort(idx[idx < 576])]
    if u @ (order[281, :2] - order[0, :2]) < 0: u = -u
    return centre, np.array([[u[0], u[1], 0], [-u[1], u[0], 0], [0, 0, 1]])


def ply(p, max_n=None, seed=38, step=None):
    with p.open('rb') as f:
        lines = []
        while True:
            line = f.readline(); lines.append(line)
            if line.strip() == b'end_header': break
        offset = f.tell()
    h = b''.join(lines).decode('ascii'); n = int(re.search(r'element vertex (\d+)', h)[1]); types = {'float': '<f4', 'uchar': 'u1'}
    dt = np.dtype([(name, types[t]) for t, name in re.findall(r'property (\w+) (\w+)', h)])
    a = np.memmap(p, dtype=dt, offset=offset, mode='r', shape=(n,))
    if step: a = np.array(a[::step])
    elif max_n and n > max_n: a = a[np.sort(np.random.default_rng(seed).choice(n, max_n, replace=False))]
    xyz = np.column_stack([a[k] for k in 'xyz']).astype(float); cols = [k for k in a.dtype.names if k in ('red', 'r')]
    rgb = np.column_stack([a[k] for k in (['red', 'green', 'blue'] if 'red' in a.dtype.names else ['r', 'g', 'b'])]) / 255
    ok = np.isfinite(xyz).all(1); return xyz[ok], rgb[ok], n


def fixed_context(centre, basis):
    hybrid = RESOURCES / 'hybrid_280'; titles = ['V1 global cameras', 'V2 chunk scale', 'V3 per-image scale']; coords = []
    for v in ['global_camera', 'chunk_depth_scale', 'view_depth_scale']:
        xyz, rgb, n = ply(hybrid / v / 'samples.ply', step=6); coords.append(((xyz - centre) @ basis.T, rgb))
    zref = np.median(coords[-1][0][:, 2]); coords = [(c - np.array([0., 0., zref]), rgb) for c, rgb in coords]
    allc = np.vstack([c for c, _ in coords]); lo = np.percentile(allc, 1, axis=0); hi = np.percentile(allc, 99, axis=0); pad = (hi - lo) * .06; lo -= pad; hi += pad
    fig, axes = plt.subplots(2, 3, figsize=(13, 5.6), layout='constrained', gridspec_kw={'height_ratios': [2.2, 1]})
    for col, ((c, rgb), t) in enumerate(zip(coords, titles)):
        for r, (dim, name) in enumerate([(1, 'Across-route (m)'), (2, 'Height rel. V3 median (m)')]):
            ax = axes[r, col]; msk = (c[:, 0] >= lo[0]) & (c[:, 0] <= hi[0]) & (c[:, dim] >= lo[dim]) & (c[:, dim] <= hi[dim])
            ax.scatter(c[msk, 0], c[msk, dim], s=.6, c=rgb[msk], linewidths=0, rasterized=True)
            ax.set(xlim=(lo[0], hi[0]), ylim=(lo[dim], hi[dim]), xlabel='Along-route (m)', ylabel=name); ax.set_aspect('equal'); ax.grid(alpha=.12)
            if r == 0: ax.set_title(t, fontsize=10)
    letter(axes[0, 0], '(a)'); letter(axes[1, 0], '(b)'); save(fig, 'fixed_context_geometry_v041')


def clouds(centre, basis):
    a, ar, na = ply(PRIMARY / 'view_depth_scale/samples.ply', max_n=400000)
    q = RUNS / 'full_route_survey_20261018_221243_8084fdb4/tiled_fusion/20261020_001647_a4b006a9/dense/fused.ply'
    b, br, nb = ply(q, max_n=600000)
    c, _, _ = ply(RESOURCES / 'hybrid_280/view_depth_scale/samples.ply', step=4)
    A = (a - centre) @ basis.T; Bc = (b - centre) @ basis.T; roi = (c - centre) @ basis.T
    joined = np.vstack([A, Bc]); lo = np.percentile(joined, .5, axis=0); hi = np.percentile(joined, 99.5, axis=0)
    rx = np.percentile(roi[:, 0], [5, 95]); ry = np.array([-23., 23.])
    fig, axes = plt.subplots(2, 2, figsize=(13, 4.9), layout='constrained', gridspec_kw={'width_ratios': [2.6, 1]})
    for row, (xyz, rgb, name) in enumerate([(A, ar, 'Calibrated VGGT (V3)'), (Bc, br, 'COLMAP MVS 1600 px')]):
        for col in range(2):
            ax = axes[row, col]
            if col == 0: xl, yl = (lo[0], hi[0]), (max(lo[1], -75), min(hi[1], 75))
            else: xl, yl = tuple(rx), tuple(ry)
            msk = (xyz[:, 0] >= xl[0]) & (xyz[:, 0] <= xl[1]) & (xyz[:, 1] >= yl[0]) & (xyz[:, 1] <= yl[1]); ids = np.flatnonzero(msk)
            if len(ids) > 220000: ids = np.sort(np.random.default_rng(38).choice(ids, 220000, replace=False))
            ax.set_facecolor('#f7f9fa'); ax.scatter(xyz[ids, 0], xyz[ids, 1], s=.3 if col == 0 else .7, c=rgb[ids], linewidths=0, rasterized=True)
            ax.set(xlim=xl, ylim=yl, xlabel='Along-route (m)', ylabel='Across-route (m)'); ax.set_aspect('equal', adjustable='box'); ax.tick_params(labelsize=8); ax.grid(alpha=.12)
            ax.set_title(name + (' · full route' if col == 0 else ' · images 280–291'), fontsize=9.5, loc='left')
            if col == 0: ax.add_patch(Rectangle((rx[0], ry[0]), rx[1] - rx[0], ry[1] - ry[0], fc='none', ec='#147a72', lw=1.1))
    letter(axes[0, 0], '(a)'); letter(axes[0, 1], '(b)'); save(fig, 'full_route_clouds_v041')
    return {'vggt_records': na, 'mvs_records': nb}


def mvs_height():
    curves = read(EVENING / 'common_support_cdf.json')
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.4), layout='constrained')
    for k in VAR:
        cv = curves['same_camera_native_comparison/' + k]; ax[0].plot(cv['pixels'], cv['q'], color=COL[k], lw=1.8, label=VLAB[k])
    cv = curves['same_camera_native_comparison/native_mvs']; ax[0].plot(cv['pixels'], cv['q'], color=COL['mvs1600'], lw=1.8, label='COLMAP MVS 1600 px')
    for key, lab, col in [('height_0.5', r'$\sigma_v$ = 0.5 m', '#9ecae1'), ('height_1', r'$\sigma_v$ = 1 m (primary)', '#155a86'), ('height_2', r'$\sigma_v$ = 2 m', '#d95f02')]:
        cv = curves['height_sensitivity_view_scale/' + key]; ax[1].plot(cv['pixels'], cv['q'], color=col, lw=1.8, label=lab)
    ax[0].set(title='Same cameras, 553,678 common pairs', ylabel='Cumulative fraction of common pairs'); ax[1].set(title='V3 under three vertical position priors (593,121 pairs)')
    for a in ax: a.set(xlim=(0, 6), ylim=(0, 1), xlabel='Cross-view reprojection discrepancy (pixels, 518×392 grid)'); a.grid(alpha=.2); a.legend(loc='lower right', fontsize=8.3)
    letter(ax[0], '(a)'); letter(ax[1], '(b)'); save(fig, 'mvs_height_comparison_v041')


def metashape():
    r = read(META / 'report.json')
    with np.load(PRIMARY / 'checking_pairs.npz') as f: he = f['errors']
    with np.load(MVS / 'checking_pairs.npz') as f: ne = f['errors']
    with np.load(META / 'checking_pairs.npz') as f: me = f['errors'][:, 0]
    with np.load(META / 'common_inventory.npz') as f: common = f['common_pairs']
    labels = [VLAB[k] for k in VAR] + ['COLMAP MVS 1600 px', 'Metashape depth layers']; colors = [COL[k] for k in VAR] + [COL['mvs1600'], COL['metashape']]
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.5), layout='constrained', gridspec_kw={'width_ratios': [1.05, 1]})
    for lab, col, e in zip(labels, colors, [he[:, k] for k in range(4)] + [ne, me]): cdf(ax[0], e[common], lab, col)
    ax[0].set(xlim=(0, 4), ylim=(0, 1), xlabel='Cross-view reprojection discrepancy (pixels, 518×392 grid)', ylabel=f'Cumulative fraction of {int(common.sum()):,} common pairs', title='Six-method common pairs')
    ax[0].legend(loc='lower right', fontsize=8.3); ax[0].grid(alpha=.2)
    rows = [row for row in r['rows'] if row['stratum'] == 'all']; y = np.arange(6)
    support = np.array([row['support_fraction'] * 100 for row in rows]); success = np.array([row['success_below2px_full_inventory'] * 100 for row in rows])
    ax[1].barh(y, support, height=.68, color=colors, alpha=.25, label='Supported'); ax[1].barh(y, success, height=.36, color=colors, label='Supported and < 2 px')
    for yi, s, ok in zip(y, support, success): ax[1].text(s + .8, yi, f'{s:.1f}% / {ok:.1f}%', va='center', fontsize=8)
    ax[1].set(yticks=y, yticklabels=labels, xlim=(0, 115), xlabel='Percentage of all 691,694 evaluation pairs', title='Support and success on the full inventory'); ax[1].invert_yaxis()
    ax[1].legend(loc='lower right', fontsize=8); ax[1].grid(axis='x', alpha=.2)
    letter(ax[0], '(a)'); letter(ax[1], '(b)'); save(fig, 'metashape_comparison_v041')


def main():
    analysis = read(ANALYSIS / 'report.json'); gsd = analysis['camera_configurations']['C5']['ground_sample_m_per_vggt_px']
    # C5 depths are 11.8% longer than the laser ranges (revision_v041_lrf run); the relative seam metric is
    # scale-invariant, so its metre axis uses the range-corrected median anchor depth.
    lrf = read(sorted(RUNS.glob('revision_v041_lrf_*'))[-1] / 'report.json')
    bias = lrf['centre_depth_vs_lrf']['C5_V3']['all_lrf']['ratio_to_lrf']['median']
    normaliser = analysis['seam_metric_magnitude']['median_normaliser_m'] / bias
    prov = {'analysis_run': str(ANALYSIS.relative_to(ROOT)), 'gsd_c5_m_per_vggt_px': gsd, 'seam_normaliser_m_range_corrected': normaliser, 'c5_range_bias': bias}
    workflow(); prov['survey'] = survey(); camera_depth(gsd); prov['anchor'] = anchor_baselines(); prov['seams'] = seams(normaliser)
    centre, basis = route_basis(); fixed_context(centre, basis); prov['clouds'] = clouds(centre, basis); mvs_height(); metashape()
    (OUT / 'revision_v041_figure_provenance.json').write_text(json.dumps(prov, indent=1, default=float), encoding='utf-8'); print(json.dumps(prov, default=float))


if __name__ == '__main__':
    main()
