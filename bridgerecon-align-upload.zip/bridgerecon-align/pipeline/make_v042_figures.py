"""v0.42 figure: range bias and image-space discrepancy of V3 against the focal length of C1-C8.

Plotting only, from stored reports and pair arrays: the v0.41 analysis and rangefinder runs (C1-C5)
and the v0.42 RTK summary (C6-C8). Writes paper/figures/camera_constraints_v042.{png,pdf} and a
provenance record.
"""
from pathlib import Path
import json, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent; RUNS = ROOT / 'experiments/runs'; OUT = ROOT / 'paper/figures'
CASES = {'C1': 'global_hybrid_20261019_202608_c52f1d98', 'C2': 'global_hybrid_20261019_202306_12e0d87d', 'C3': 'global_hybrid_20261019_202608_f0a87529',
         'C4': 'global_hybrid_20261019_202608_fdd3a7fc', 'C5': 'global_hybrid_20261019_205203_28fc26c6'}
NEW = {'C6': 'R10', 'C7': 'R03', 'C8': 'RF'}
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9.5, 'pdf.fonttype': 42, 'axes.spines.top': False,
                     'axes.spines.right': False, 'legend.frameon': False})
INK = '#155a86'; GUIDE = '#8c8c8c'


def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def letter(ax, s): ax.text(-0.11, 1.03, s, transform=ax.transAxes, fontsize=11, fontweight='bold', va='bottom')


def main(rtk_run):
    an = read(sorted(RUNS.glob('revision_v041_analysis_*'))[-1] / 'report.json'); lrf = read(sorted(RUNS.glob('revision_v041_lrf_*'))[-1] / 'report.json'); rtk = read(rtk_run / 'report.json')
    rows = {}
    for c, run in CASES.items():
        rows[c] = {'f': an['camera_configurations'][c]['focal_px_1600'], 'bias': (lrf['centre_depth_vs_lrf'][f'{c}_V3']['all_lrf']['ratio_to_lrf']['median'] - 1) * 100,
                   'rtk': lrf['camera_centres_vs_rtk'][c]['residual_3d_m']['median'], 'run': RUNS / run}
    for c, label in NEW.items():
        if label not in rtk['cases']: continue
        r = rtk['cases'][label]
        rows[c] = {'f': r['main_camera']['params'][0], 'bias': r['centre_depth_vs_lrf']['V3/all']['bias_pct'], 'rtk': r['camera_centres_vs_rtk']['residual_3d_m']['median'], 'run': ROOT / 'experiments' / r['run']}
    pairs = {c: np.load(v['run'] / 'checking_pairs.npz') for c, v in rows.items()}
    common = np.logical_and.reduce([p['supported'][:, 3] for p in pairs.values()])
    for c, p in pairs.items(): rows[c]['v3_median_common'] = float(np.median(p['errors'][common, 3]))
    f0 = {c: rows[c]['f'] / (1 + rows[c]['bias'] / 100) for c in ['C5', 'C6', 'C7', 'C8'] if c in rows}; f0_med = float(np.median(list(f0.values())))
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.4), layout='constrained')
    near = [c for c in rows if rows[c]['rtk'] < 2]; far = [c for c in rows if rows[c]['rtk'] >= 2]
    fx = np.linspace(1040, 1380, 50); ax[0].plot(fx, (fx / f0_med - 1) * 100, '--', color=GUIDE, lw=1.2, label=f'Bias proportional to $f$ (zero at {f0_med:.0f} px)')
    ax[0].axhline(0, color='#444444', lw=0.8)
    for a, key in zip(ax, ['bias', 'v3_median_common']):
        a.plot([rows[c]['f'] for c in near], [rows[c][key] for c in near], 'o', ms=8, color=INK, mec='white', mew=1.2, label='Camera centres within 1.1 m of RTK')
        a.plot([rows[c]['f'] for c in far], [rows[c][key] for c in far], 'o', ms=8, mfc='white', mec=INK, mew=1.6, label='Camera centres 6–16 m from RTK')
        for c in rows:
            if c == 'C4': continue
            text = 'C3, C4' if c == 'C3' else c
            offset = (-20, 6) if c == 'C2' else (8, -13) if (c == 'C8' and key == 'bias') else (7, 5)  # C1/C2 are 18 px apart; C8 sits on the guide line
            a.annotate(text, (rows[c]['f'], rows[c][key]), xytext=offset, textcoords='offset points', fontsize=8.5, color='#333333')
        a.set(xlim=(1040, 1385), xlabel='Focal length $f$ of the main-route camera (pixels at 1600×1200)'); a.grid(alpha=.2)
    ax[0].set(ylabel='Bias of V3 depth at the principal point\nrelative to the rangefinder (%)', title='Range bias (576 photographs)')
    ax[1].set(ylabel='V3 median discrepancy (pixels)', title=f'Image-space discrepancy ({int(common.sum()):,} pairs common to {min(rows)}–{max(rows)})')
    ax[1].set_ylim(0, max(rows[c]['v3_median_common'] for c in rows) * 1.25)
    ax[0].legend(loc='upper left', fontsize=8.3); ax[1].legend(loc='lower right', fontsize=8.3)
    letter(ax[0], '(a)'); letter(ax[1], '(b)')
    for ext in ('png', 'pdf'): fig.savefig(OUT / f'camera_constraints_v042.{ext}', dpi=220, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    prov = {'rtk_run': str(rtk_run.relative_to(ROOT)), 'common_pairs_C1_C8': int(common.sum()), 'f0_px_per_case': f0, 'f0_median_px': f0_med,
            'rows': {c: {k: (str(v.relative_to(ROOT)) if isinstance(v, Path) else v) for k, v in r.items()} for c, r in rows.items()}}
    (OUT / 'revision_v042_figure_provenance.json').write_text(json.dumps(prov, indent=1), encoding='utf-8'); print(json.dumps(prov, indent=1))


if __name__ == '__main__':
    main(Path(sys.argv[1]).resolve())
