"""Export fixed-pinhole COLMAP MVS depths into the common 518-pixel image grid.

Camera/world scale is retained. No point-cloud alignment or physical scale fit.
Holes are retained using complete bilinear support rather than interpolated fills.
"""
from pathlib import Path
import argparse,json,os,subprocess
import numpy as np
from scipy.spatial.transform import Rotation
from local_validation import sample


def read_depth(path):
    with Path(path).open('rb') as f:
        header=bytearray();separators=0
        while separators<3:
            value=f.read(1)
            if not value or len(header)>100:raise ValueError('Invalid COLMAP depth header')
            header.extend(value);separators+=value==b'&'
        width,height,channels=map(int,header.decode('ascii').split('&')[:3])
        data=np.frombuffer(f.read(),dtype='<f4')
    if len(data)!=width*height*channels:raise ValueError('Dense map length mismatch')
    return data.reshape((width,height,channels),order='F').transpose(1,0,2).squeeze()


def main():
    p=argparse.ArgumentParser();p.add_argument('run',type=Path);p.add_argument('common',type=Path);args=p.parse_args()
    run=args.run.resolve();common=args.common.resolve()
    report=json.loads((run/'report.json').read_text(encoding='utf-8'))
    if 'Fixed approximate EXIF' not in report['camera_policy']:raise ValueError('This exporter requires the declared fixed zero-distortion camera control')
    original=report['sparse']['cameras'][0]['parameters'];f,cx,cy,k=original
    if abs(k)>1e-12:raise ValueError('A nonlinear distortion model cannot use this pinhole export')
    source=dict(np.load(common/'optimized_predictions.npz'));n,h,w=source['depth'].shape[:3]
    text=run/'dense/sparse_text';text.mkdir(exist_ok=True)
    completed=subprocess.run([os.environ.get('COLMAP_EXE','colmap'),'model_converter','--input_path','dense/sparse',
        '--output_path','dense/sparse_text','--output_type','TXT'],cwd=run,capture_output=True,text=True)
    if completed.returncode:raise RuntimeError(completed.stderr[-2000:])
    cameras={}
    for line in (text/'cameras.txt').read_text().splitlines():
        if not line or line.startswith('#'):continue
        values=line.split();model=values[1];parameters=list(map(float,values[4:]))
        if model=='PINHOLE':fx,fy,px,py=parameters
        elif model=='SIMPLE_PINHOLE':fx,px,py=parameters;fy=fx
        elif model=='SIMPLE_RADIAL' and abs(parameters[3])<1e-12:fx,px,py,_=parameters;fy=fx
        else:raise ValueError('Unexpected undistorted camera model: '+model)
        cameras[int(values[0])]=np.array([[fx,0,px],[0,fy,py],[0,0,1.]])
    images={}
    for line in (text/'images.txt').read_text().splitlines():
        if not line or line.startswith('#'):continue
        v=line.split()
        if len(v)<10 or not v[9].lower().endswith('.jpg'):continue
        qw,qx,qy,qz=map(float,v[1:5]);R=Rotation.from_quat([qx,qy,qz,qw]).as_matrix();t=np.array(list(map(float,v[5:8])))
        images[int(Path(v[9]).stem)]=(v[9],int(v[8]),np.c_[R,t])
    image_records={r['index']:r for r in report['images']}
    yy,xx=np.mgrid[:h,:w];grid=np.c_[xx.ravel(),yy.ravel(),np.ones(h*w)]
    depth=np.zeros((n,h,w,1),dtype='float32');conf=np.zeros((n,h,w),dtype='float32')
    E=np.repeat(np.eye(3,4)[None],n,axis=0);K=source['intrinsics'].copy();records=[]
    for slot,index in enumerate(source['image_indices']):
        index=int(index)
        if index not in images:records.append({'image':index,'registered':False});continue
        name,camera,E[slot]=images[index]
        A=np.array(image_records[index]['original_to_input']);T=source['original_to_input'][slot]@np.linalg.inv(A)
        # Sparse COLMAP coordinates place the first pixel center at (.5,.5).
        # OpenCV/PIL common-grid centers are integer coordinates. COLMAP 3.13
        # MVS depth geometry itself uses integer lattice indices with its K;
        # retain that lattice when sampling the stored depth map (no extra shift).
        colmap_to_cv=np.array([[1.,0,-.5],[0,1.,-.5],[0,0,1.]])
        virtual=T@colmap_to_cv@np.array([[f,0,cx],[0,f,cy],[0,0,1.]])
        mapped=(grid@np.linalg.inv(virtual).T)@cameras[camera].T
        uv=mapped[:,:2]/mapped[:,2,None]
        raw=read_depth(run/'dense/stereo/depth_maps'/(name+'.geometric.bin'))
        valid=np.isfinite(raw)&(raw>0)
        values=sample(np.where(valid,raw,0),uv)
        support=(sample(valid.astype('float32'),uv)>.999)&(values>0)
        depth[slot,...,0]=np.where(support,values,0).reshape(h,w)
        conf[slot]=np.where(support,2.,0.).reshape(h,w);K[slot]=virtual
        records.append({'image':index,'registered':True,'supported_common_pixels':int(support.sum()),'total_common_pixels':h*w,
                        'original_dense_shape':list(raw.shape)})
    result={**source,'depth':depth,'depth_conf':conf,'extrinsics':E,'intrinsics':K}
    np.savez_compressed(run/'dense_in_common_pixels.npz',**result)
    (run/'common_grid_report.json').write_text(json.dumps({'scope':'Image-coordinate remapping only; original arbitrary world scale retained',
        'common':str(common),'records':records,'hole_policy':'Require full bilinear valid-depth support; do not fill holes',
        'pixel_convention':'COLMAP sparse half-pixel origin converted to OpenCV integer centers; retain COLMAP 3.13 MVS integer depth-ray lattice',
        'convention_sources':['https://colmap.github.io/database.html','https://raw.githubusercontent.com/colmap/colmap/3.13.0/src/colmap/mvs/fusion.cc'],
        'reference_access':False},indent=2),encoding='utf-8')
    print('REPORT',run/'common_grid_report.json',flush=True)


if __name__=='__main__':main()
