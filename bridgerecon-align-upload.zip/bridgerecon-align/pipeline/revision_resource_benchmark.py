"""Bounded new-process operating-point study; frozen scientific drivers unchanged."""
from pathlib import Path
from datetime import datetime,timezone
import ctypes,json,os,subprocess,sys,time,uuid,re
from ctypes import wintypes
import numpy as np
from work_schedule import require_start_window

BASE=Path(__file__).resolve().parent;ROOT=BASE.parent
SOURCE=BASE/'runs/full_route_survey_20261018_221243_8084fdb4'
MODEL=SOURCE/'triangulation_controls/20261019_204600_0533f33d/sparse'
PREP=SOURCE/'hybrid_preparations/control_20261019_204352_934f2647'
STARTS=[0,280,564]

def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')

def family_rss(root):
    class Entry(ctypes.Structure):
        _fields_=[('size',wintypes.DWORD),('usage',wintypes.DWORD),('pid',wintypes.DWORD),('heap',ctypes.c_size_t),('module',wintypes.DWORD),('threads',wintypes.DWORD),('parent',wintypes.DWORD),('priority',wintypes.LONG),('flags',wintypes.DWORD),('exe',wintypes.WCHAR*260)]
    class Memory(ctypes.Structure):
        _fields_=[('cb',wintypes.DWORD),('faults',wintypes.DWORD),('peak',ctypes.c_size_t),('working',ctypes.c_size_t),('quota_peak',ctypes.c_size_t),('quota',ctypes.c_size_t),('nonpaged_peak',ctypes.c_size_t),('nonpaged',ctypes.c_size_t),('pagefile',ctypes.c_size_t),('peakpagefile',ctypes.c_size_t)]
    kernel=ctypes.WinDLL('kernel32',use_last_error=True);psapi=ctypes.WinDLL('psapi')
    kernel.CreateToolhelp32Snapshot.restype=wintypes.HANDLE;kernel.OpenProcess.restype=wintypes.HANDLE
    kernel.Process32FirstW.argtypes=[wintypes.HANDLE,ctypes.POINTER(Entry)];kernel.Process32NextW.argtypes=kernel.Process32FirstW.argtypes
    kernel.CloseHandle.argtypes=[wintypes.HANDLE];psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(Memory),wintypes.DWORD]
    snap=kernel.CreateToolhelp32Snapshot(2,0);e=Entry();e.size=ctypes.sizeof(e);parents={}
    ok=kernel.Process32FirstW(snap,ctypes.byref(e))
    while ok:parents[e.pid]=e.parent;ok=kernel.Process32NextW(snap,ctypes.byref(e))
    kernel.CloseHandle(snap);ids={root}
    for _ in range(8):ids|={p for p,parent in parents.items() if parent in ids}
    total=0
    for pid in ids:
        handle=kernel.OpenProcess(0x0400|0x0010,False,pid)
        if handle:
            m=Memory();m.cb=ctypes.sizeof(m)
            if psapi.GetProcessMemoryInfo(handle,ctypes.byref(m),m.cb):total+=m.working
            kernel.CloseHandle(handle)
    return total/1024**2

def main():
    require_start_window(3650)
    out=BASE/'runs'/('revision_resources_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir()
    report={'status':'running','starts':STARTS,'views_per_context':12,'created_at':datetime.now(timezone.utc).isoformat(),'cases':[],
      'protocol':'Fresh processes and output files; no prediction-cache reuse. OS/filesystem caches not flushed. Fixed saved global cameras; same12-image context per method. Three route locations chosen by index, not outcome. Descriptive operating points, not blind efficacy trials.',
      'scope':'Depth-production and required VGGT correction separately recorded; upstream SfM and downstream unique-surface fusion excluded; no end-to-end speedup claim',
      'resource_measurement':'2s samples of total device memory (includes desktop/other applications) and sum of family process working sets (shared pages may be double counted). Observed peaks are sampled values, not exact allocator peaks.',
      'source_model':str(MODEL),'gpu_used':True,'reference_access':False}
    write(out/'report.json',report);write(BASE/'data_audit/revision_resource_active.json',{'output':str(out)})
    print('OUTPUT',out,flush=True)
    def run(label,command,timeout=600):
        require_start_window(timeout+30);row={'label':label,'command':command,'status':'running'};report['cases'].append(row);write(out/'report.json',report)
        logpath=out/(label+'.log');start=time.monotonic();gpu=[];rss=[]
        with logpath.open('w',encoding='utf-8') as log:
            child=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
            while child.poll() is None:
                rss.append(family_rss(child.pid))
                try:
                    v=subprocess.run(['nvidia-smi','--query-gpu=memory.used','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=5,creationflags=subprocess.CREATE_NO_WINDOW)
                    if v.returncode==0:gpu.append(float(v.stdout.strip().splitlines()[0]))
                except (OSError,ValueError,subprocess.TimeoutExpired):pass
                if time.monotonic()-start>timeout:raise RuntimeError('Case timed out; outer owned GPU job must terminate descendants')
                time.sleep(2)
        row.update(status='completed' if child.returncode==0 else 'failed',exit_code=child.returncode,wall_seconds=time.monotonic()-start,observed_device_peak_MiB=max(gpu,default=None),observed_family_working_set_peak_MiB=max(rss,default=None),log=str(logpath))
        write(out/'report.json',report)
        if child.returncode:raise RuntimeError(logpath.read_text(encoding='utf-8',errors='replace')[-1200:])
        return row,logpath.read_text(encoding='utf-8',errors='replace')
    try:
        for start in STARTS:
            row,text=run(f'vggt_{start}',[sys.executable,'-u',str(BASE/'run_vggt_route_chunks.py'),'--starts',str(start)])
            match=re.search(r'^REPORT (.+)$',text,re.M);assert match,text[-300:];raw=Path(match[1].strip());row['raw_output']=str(raw)
            hybrid=out/f'hybrid_{start}';hybrid.mkdir()
            correction,_=run(f'correction_{start}',[sys.executable,'-u',str(BASE/'run_global_hybrid.py'),'--worker','--out',str(hybrid),'--preparation',str(PREP),'--source',str(raw),'--starts',str(start)])
            correction['hybrid_output']=str(hybrid)
            for width in (518,1600):
                item,text=run(f'mvs{width}_{start}',[sys.executable,'-u',str(BASE/'dense_saved_route.py'),str(SOURCE),str(MODEL),'--start-index',str(start),'--count','12','--width',str(width),'--iterations','3','--sources','10','--seconds','540','--depth-only'])
                lines=[l for l in text.splitlines() if l.startswith('{')]
                item['dense_output']=json.loads(lines[-1])['output'];item['hybrid_output']=str(hybrid)
                write(out/'report.json',report)
        report['status']='completed'
    except Exception as e:report.update(status='failed',error=repr(e));raise
    finally:write(out/'report.json',report);print('REPORT',out,flush=True)

if __name__=='__main__':main()
