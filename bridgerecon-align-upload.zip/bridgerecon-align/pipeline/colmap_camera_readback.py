"""Minimal COLMAP binary camera/registered-pose readback, without dense tracks."""
from pathlib import Path
import struct
import numpy as np
from scipy.spatial.transform import Rotation

MODELS={0:('SIMPLE_PINHOLE',3),1:('PINHOLE',4),2:('SIMPLE_RADIAL',4)}


def unpack(stream,fmt):
    size=struct.calcsize('<'+fmt);data=stream.read(size)
    if len(data)!=size:raise ValueError('Truncated COLMAP binary')
    return struct.unpack('<'+fmt,data)


def read_cameras(folder):
    result={}
    with (Path(folder)/'cameras.bin').open('rb') as stream:
        for _ in range(unpack(stream,'Q')[0]):
            cid,kind,width,height=unpack(stream,'iiQQ');name,count=MODELS[kind]
            result[cid]={'model':name,'width':width,'height':height,'params':list(unpack(stream,'d'*count))}
        assert not stream.read(1)
    return result


def read_registered(folder):
    result={}
    with (Path(folder)/'images.bin').open('rb') as stream:
        for _ in range(unpack(stream,'Q')[0]):
            image_id=unpack(stream,'i')[0];q=np.array(unpack(stream,'dddd'));t=np.array(unpack(stream,'ddd'));cid=unpack(stream,'i')[0]
            name=bytearray()
            while True:
                char=stream.read(1)
                if char==b'\0':break
                if not char:raise ValueError('Unterminated image name')
                name.extend(char)
            count=unpack(stream,'Q')[0];stream.seek(count*24,1)
            R=Rotation.from_quat(q[[1,2,3,0]]).as_matrix()
            result[name.decode('utf-8')]={'image_id':image_id,'camera_id':cid,'extrinsics':np.c_[R,t],'point2D_count':count}
        assert not stream.read(1)
    return result
