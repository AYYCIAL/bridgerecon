"""Image-only validation on fixed checking observations and crop boundaries."""
import numpy as np
import cv2


def sample(array, uv):
    uv=np.asarray(uv,dtype=np.float32).reshape(-1,2)
    if len(uv)>30000:
        return np.concatenate([sample(array,uv[i:i+30000]) for i in range(0,len(uv),30000)])
    return cv2.remap(np.asarray(array,dtype=np.float32),uv[:,0,None],uv[:,1,None],
                     cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=0).ravel()


def unproject(uv, depth, extrinsic, intrinsic):
    camera=(np.c_[uv,np.ones(len(uv))]@np.linalg.inv(intrinsic).T)*np.asarray(depth)[:,None]
    return (camera-extrinsic[:,3])@extrinsic[:,:3]


def project_world(xyz, extrinsic, intrinsic):
    camera=np.asarray(xyz)@extrinsic[:,:3].T+extrinsic[:,3]
    homogeneous=camera@intrinsic.T
    denominator=np.where(abs(homogeneous[:,2])<1e-10,1e-10,homogeneous[:,2])
    return homogeneous[:,:2]/denominator[:,None],camera[:,2]


def inside(uv, width=518, height=392, margin=3):
    uv=np.asarray(uv)
    return (uv[:,0]>=margin)&(uv[:,0]<width-margin)&(uv[:,1]>=margin)&(uv[:,1]<height-margin)


def statistics(values):
    x=np.asarray(values);x=x[np.isfinite(x)]
    return {'n':int(len(x)),'median':float(np.median(x)) if len(x) else None,
            'p95':float(np.percentile(x,95)) if len(x) else None}


def coarse_in_crop(coarse, views, transforms, height=392, width=518):
    y,x=np.mgrid[:height,:width];uv=np.c_[x.ravel(),y.ravel()]
    depths=[];confidence=[]
    for view,B in zip(views,transforms):
        base=(np.c_[uv,np.ones(len(uv))]@np.linalg.inv(B).T)[:,:2]
        depths.append(sample(coarse['depth'][view,...,0],base).reshape(height,width))
        confidence.append(sample(coarse['depth_conf'][view],base).reshape(height,width))
    return np.array(depths),np.array(confidence)


def fixed_check_pairs(tracks, views, transforms, old_depth, old_conf, confidence_min=1.2):
    pairs=[]
    for tr in tracks:
        observations=[]
        for slot,view in enumerate(views):
            if view not in tr['views']:continue
            uv=(transforms[slot]@np.r_[tr['uv'][tr['views'].index(view)],1])[:2]
            if not inside(uv[None])[0]:continue
            d=sample(old_depth[slot],uv[None])[0];c=sample(old_conf[slot],uv[None])[0]
            if d>0 and np.isfinite(d) and c>=confidence_min:observations.append((slot,uv))
        for i,u in observations:
            for j,v in observations:
                if i!=j:pairs.append({'track':tr['id'],'source':i,'target':j,'source_uv':u.tolist(),'target_uv':v.tolist()})
    return pairs


def evaluate_pairs(pairs,depth,conf,extrinsics,K,confidence_min=1.2,query=None):
    errors=np.full(len(pairs),np.nan);relative_depth=np.full(len(pairs),np.nan);valid=np.zeros(len(pairs),bool)
    for n,p in enumerate(pairs):
        i,j=p['source'],p['target'];u=np.array(p['source_uv'])[None];v=np.array(p['target_uv'])[None]
        if query is None:
            ds=sample(depth[i],u)[0];dt=sample(depth[j],v)[0]
            cs=sample(conf[i],u)[0];ct=sample(conf[j],v)[0]
        else:
            ds,cs=query(i,u);dt,ct=query(j,v)
            ds,cs,dt,ct=float(ds[0]),float(cs[0]),float(dt[0]),float(ct[0])
        if not(np.isfinite(ds) and np.isfinite(dt) and ds>0 and dt>0 and cs>=confidence_min and ct>=confidence_min):continue
        world=unproject(u,[ds],extrinsics[i],K[i]);pred,z=project_world(world,extrinsics[j],K[j])
        if z[0]<=0 or not np.isfinite(pred).all() or not inside(pred)[0]:continue
        errors[n]=np.linalg.norm(pred[0]-v[0]);relative_depth[n]=abs(z[0]-dt)/dt;valid[n]=True
    return {'pixel_error':errors,'relative_depth_error':relative_depth,'valid':valid}


def seam_inventory(old_depth,old_conf,confidence_min=1.2):
    h,w=old_depth.shape[-2:];y,x=np.mgrid[8:h-8:16,8:w-8:16]
    uv=np.c_[x.ravel(),y.ravel()];distance=np.minimum.reduce([uv[:,0],uv[:,1],w-1-uv[:,0],h-1-uv[:,1]])
    uv=uv[distance<40];entries=[]
    for slot in range(len(old_depth)):
        ds=sample(old_depth[slot],uv);cs=sample(old_conf[slot],uv)
        entries.extend((slot,p.tolist(),float(d)) for p,d,c in zip(uv,ds,cs) if d>0 and np.isfinite(d) and c>=confidence_min)
    return entries


def evaluate_seam(entries,depth,conf,K,length,confidence_min=1.2):
    discrepancy=np.full(len(entries),np.nan);valid=np.zeros(len(entries),bool)
    for n,(i,uv,old) in enumerate(entries):
        d=sample(depth[i],[uv])[0];c=sample(conf[i],[uv])[0]
        if d<=0 or not np.isfinite(d) or c<confidence_min:continue
        ray=np.linalg.solve(K[i],np.r_[uv,1.])
        discrepancy[n]=abs(d-old)*np.linalg.norm(ray)/length;valid[n]=True
    return discrepancy,valid


def decision(pairs,before,after,seam,seam_valid,settings):
    fixed_tracks=len({p['track'] for p in pairs})
    supported_tracks=len({p['track'] for p,k in zip(pairs,after['valid']) if k})
    paired=before['valid']&after['valid']
    old=statistics(before['pixel_error'][paired]);new=statistics(after['pixel_error'][paired])
    oldcv=statistics(before['relative_depth_error'][paired]);newcv=statistics(after['relative_depth_error'][paired])
    seam_stats=statistics(seam);support=float(after['valid'].mean()) if len(pairs) else 0
    ssupport=float(seam_valid.mean()) if len(seam_valid) else 0
    reasons=[]
    if fixed_tracks<settings['min_check_tracks']:reasons.append('insufficient_check_tracks')
    if supported_tracks/max(fixed_tracks,1)<settings['min_support']:reasons.append('checking_track_support_loss')
    if support<settings['min_support']:reasons.append('checking_support_loss')
    if new['n']==0 or any(new[k]>old[k]+settings['pixel_tolerance'] for k in ['median','p95']):reasons.append('checking_reprojection_worse')
    if newcv['n']==0 or any(newcv[k]>oldcv[k]+settings['relative_depth_tolerance'] for k in ['median','p95']):reasons.append('cross_view_depth_worse')
    if ssupport<settings['min_support']:reasons.append('seam_support_loss')
    if seam_stats['n']==0 or seam_stats['p95']>settings['seam_p95_limit_normalized']:reasons.append('seam_disagreement')
    return {'fixed_tracks':fixed_tracks,'supported_tracks':supported_tracks,'fixed_directed_pairs':len(pairs),
            'track_support_fraction':supported_tracks/max(fixed_tracks,1),
            'supported_directed_pairs':int(after['valid'].sum()),'pair_support_fraction':support,
            'before_reprojection_px_paired':old,'after_reprojection_px_paired':new,
            'before_relative_depth_paired':oldcv,'after_relative_depth_paired':newcv,
            'fixed_seam_samples':len(seam),'seam_support_fraction':ssupport,'seam_normalized':seam_stats,
            'gate_pass':not reasons,'rejection_reasons':reasons,
            'note':'Paired residual statistics accompany fixed-denominator support counts; image-only, not external accuracy'}
