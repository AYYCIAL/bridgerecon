"""Native MVS on the frozen VGGT image endpoints, with explicit support."""
from pathlib import Path
from datetime import datetime
import hashlib,json,time,uuid
import numpy as np
from audit_native_depth_maps import map_view
from colmap_camera_readback import read_cameras,read_registered
from global_hybrid_geometry import native_rays,camera_parameters,project_native
from local_validation import statistics,inside
from work_schedule import require_start_window

BASE=Path(__file__).resolve().parent
SOURCE=BASE/'runs/full_route_survey_20261018_221243_8084fdb4'
ATTEMPT=SOURCE/'dense_attempts/20261019_205034_ab94308e'
HYBRID=BASE/'runs/global_hybrid_20261019_205203_28fc26c6'

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,r):p.write_text(json.dumps(r,indent=2),encoding='utf-8')


def sample_positive(values,uv):
    """Exact bilinear weights; require four positive finite neighboring depths."""
    h,w=values.shape;uv=np.asarray(uv);x=np.floor(uv[:,0]).astype(int);y=np.floor(uv[:,1]).astype(int)
    valid=np.isfinite(uv).all(axis=1)&(x>=0)&(y>=0)&(x+1<w)&(y+1<h)
    result=np.full(len(uv),np.nan);ids=np.where(valid)[0];xx=x[ids];yy=y[ids]
    four=np.c_[values[yy,xx],values[yy,xx+1],values[yy+1,xx],values[yy+1,xx+1]]
    good=np.isfinite(four).all(axis=1)&(four>0).all(axis=1);valid[ids[~good]]=False
    dx=uv[ids,0]-xx;dy=uv[ids,1]-yy
    weight=np.c_[(1-dx)*(1-dy),dx*(1-dy),(1-dx)*dy,dx*dy]
    result[ids[good]]=np.sum(weight[good]*four[good],axis=1)
    return result,valid


def main():
    require_start_window(900);tic=time.monotonic();state=read(ATTEMPT/'report.json')
    assert state['status']=='depth_maps_completed' and state['input_unchanged']
    maps_audit=read(ATTEMPT/'depth_maps_readback.json');assert maps_audit['status']=='completed' and maps_audit['all_records_finite']
    out=BASE/'runs'/('native_mvs_checking_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir()
    for name in ['evaluate_native_mvs_checking.py','colmap_camera_readback.py','audit_native_depth_maps.py']:(out/name).write_bytes((BASE/name).read_bytes())
    hybrid=read(HYBRID/'report.json');prep=Path(hybrid['preparation']);anchors=read(prep/'report.json');records={v['index']:v for v in anchors['views']}
    original=read(prep/'native_cameras.json');native=read_cameras(ATTEMPT/'dense/sparse');poses=read_registered(ATTEMPT/'dense/sparse')
    metadata=read(SOURCE/'report.json');names={r['index']:r['name'] for r in metadata['images']}
    assert set(poses)=={names[i] for i in range(576)}
    with np.load(HYBRID/'checking_samples.npz') as data:
        ids=data['ids'];views=data['view'];uv=data['uv'];reference=data['reference_z'];hybrid_valid=data['valid'];hybrid_z=data['predicted_z']
    with np.load(HYBRID/'checking_pairs.npz') as data:
        si=data['source'];ti=data['target'];hybrid_errors=data['errors'];hybrid_support=data['supported']
    depth=np.full(len(ids),np.nan);xyz=np.full((len(ids),3),np.nan);valid=np.zeros(len(ids),bool);view_models={};rows=[]
    for index in range(576):
        if index%24==0:require_start_window(120)
        where=np.where(views==index)[0];a=dict(np.load(prep/records[index]['file']));E=a['extrinsics'];A=a['native_to_input'];camera=original[str(int(a['camera_id']))]
        name=names[index];pose=poses[name];assert np.max(abs(E-pose['extrinsics']))<1e-8
        undistorted=native[pose['camera_id']];fx,fy,cx,cy,k=camera_parameters(undistorted);assert k==0
        rays=native_rays(uv[where],camera,A);pixels=rays[:,:2]*[fx,fy]+[cx,cy]
        file=ATTEMPT/'dense/stereo/depth_maps'/(name+'.geometric.bin');mapped=map_view(file)
        assert mapped.shape==(undistorted['height'],undistorted['width'],1)
        # Native COLMAP ComputePointAtDepth uses integer col,row and the unchanged
        # MVS K. Therefore this query has no additional +/-0.5 pixel translation.
        d,good=sample_positive(mapped[...,0],pixels);depth[where]=d
        xyz[where]=(rays*d[:,None]-E[:,3])@E[:,:3]
        valid[where]=good&np.isfinite(reference[where])&(reference[where]>0)
        view_models[index]=(E,camera,A);rows.append({'index':index,'checking_observations':len(where),'supported':int(valid[where].sum())});del mapped
    errors=np.full(len(si),np.nan);support=np.zeros(len(si),bool)
    for index,(E,camera,A) in view_models.items():
        selected=np.where(views[ti]==index)[0];pixel,z=project_native(xyz[si[selected]],E,camera,A)
        good=valid[si[selected]]&valid[ti[selected]]&(z>0)&np.isfinite(pixel).all(axis=1)&inside(pixel)
        residual=np.linalg.norm(pixel-uv[ti[selected]],axis=1);errors[selected[good]]=residual[good];support[selected[good]]=True
    np.savez_compressed(out/'checking_samples.npz',ids=ids,view=views,uv=uv,reference_z=reference,predicted_z=depth,valid=valid)
    np.savez_compressed(out/'checking_pairs.npz',source=si,target=ti,errors=errors,supported=support)
    relative=abs(depth-reference)/reference;paired_pairs=support&hybrid_support.all(axis=1);paired_obs=valid&hybrid_valid.all(axis=1)
    paired={}
    for column,variant in enumerate(hybrid['variants']):
        paired[variant]={'pairs':statistics(hybrid_errors[paired_pairs,column]),
                         'depth_relative':statistics((abs(hybrid_z[:,column]-reference)/reference)[paired_obs])}
    metrics={'full_observations':len(ids),'full_pairs':len(si),'supported_observation_fraction':float(valid.mean()),
             'supported_pair_fraction':float(support.mean()),'reprojection_pixels':statistics(errors),
             'fixed_inventory_success_below2px':float((errors<2).mean()),'depth_relative_abs_error':statistics(relative[valid])}
    report={'status':'completed','created':datetime.now().astimezone().isoformat(),'attempt':str(ATTEMPT),'hybrid':str(HYBRID),
            'attempt_report_sha256':sha(ATTEMPT/'report.json'),'hybrid_report_sha256':sha(HYBRID/'report.json'),
            'same_image_endpoint_inventory':True,'native_registered_images':len(poses),'metrics':metrics,'views':rows,
            'paired_common_pairs':int(paired_pairs.sum()),'paired_common_observations':int(paired_obs.sum()),'paired_hybrid':paired,
            'paired_native':{'pairs':statistics(errors[paired_pairs]),'depth_relative':statistics(relative[paired_obs])},
            'reference_access':False,'gpu_used':False,'seconds':time.monotonic()-tic,
            'coordinate_protocol':'Original distorted feature edge-origin to VGGT center-origin invert A; original radial inverse; native undistorted K to MVS array coordinates, no additional half-pixel shift',
            'support_rule':'Four positive finite geometric depth samples for bilinear interpolation; full checking inventory retained',
            'scope':'Descriptive conditional image consistency; native MVS fits all image texture, different fitting access and resolution from VGGT controls; source SfM initialized with all tracks; not physical accuracy',
            'resolution':'Native MVS maximum1600; VGGT518x392. Strong quality baseline, not a matched-resolution throughput experiment'}
    write(out/'report.json',report);print(json.dumps({k:v for k,v in report.items() if k not in ['views']}));print('REPORT',out,flush=True)


if __name__=='__main__':main()
