"""Stand-in for the authors' local quiet-hours guard.

The original module refused to start a job that would run past an authorised daily stop time recorded
in a local work_schedule.json. It never changed any computation; this stand-in always permits.
"""


def work_window(policy_path=None, now_utc=None):
    return {'seconds_available': float('inf'), 'deadline_utc': '9999-12-31T00:00:00+00:00', 'stop_by_local': None,
            'resume_mode': 'not enforced in the public release', 'authorization': None}


def require_start_window(requested_seconds, policy_path=None, now_utc=None):
    return work_window(policy_path, now_utc)
