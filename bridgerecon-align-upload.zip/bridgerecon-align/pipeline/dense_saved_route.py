"""Bounded MVS from saved route cameras. Run with CUDA Python via budget_run.

Optional contiguous subset is a runtime/geometry pilot with global cameras,
not an independently reconstructed comparison window. No PCD is accessed.
"""
from pathlib import Path
from datetime import datetime
import argparse
import hashlib
import json
import os
import subprocess
import time
import uuid
import numpy as np
import pycolmap
from work_schedule import require_start_window

BASE = Path(__file__).resolve().parent
EXE = os.environ.get('COLMAP_EXE', 'colmap')


def hashes(model):
    return {n: hashlib.sha256((model / n).read_bytes()).hexdigest()
            for n in ('cameras.bin', 'images.bin', 'points3D.bin')}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source_run', type=Path)
    parser.add_argument('model', type=Path)
    parser.add_argument('--start-index', type=int, default=120)
    parser.add_argument('--count', type=int, default=24, help='0 means all registered images')
    parser.add_argument('--indices',type=int,nargs='+',help='Explicit saved-camera context, independently declared coverage pilot')
    parser.add_argument('--width', type=int, default=1600)
    parser.add_argument('--iterations', type=int, default=3)
    parser.add_argument('--sources', type=int, default=10)
    parser.add_argument('--fusion-min-pixels', type=int, default=5)
    parser.add_argument('--fusion-cache', type=int, choices=(0, 1), default=0,
                        help='1 bounds fusion image/depth memory by the 2 GiB cache; always use an explicit image-size cap')
    parser.add_argument('--seconds', type=int, default=1800)
    parser.add_argument('--resume', type=Path)
    parser.add_argument('--depth-only', action='store_true', help='Save native depth maps; use separately declared bounded tiled fusion')
    args = parser.parse_args()
    if min(args.width, args.iterations, args.sources, args.seconds, args.fusion_min_pixels) <= 0 or args.count < 0:
        parser.error('Invalid resource limits')
    require_start_window(args.seconds + 30)
    source = args.source_run.resolve()
    source.relative_to(BASE / 'runs')
    model = args.model.resolve()
    relative = model.relative_to(source).as_posix()
    input_hash = hashes(model)
    metadata = json.loads((source / 'report.json').read_text(encoding='utf-8'))
    indices = {row['name']: row['index'] for row in metadata['images']}
    settings = {'width': args.width, 'iterations': args.iterations, 'sources': args.sources,
                'start_index': args.start_index, 'count': args.count,
                'geometric_consistency': True, 'cache_gb': 2, 'fusion_min_pixels': args.fusion_min_pixels,
                'fusion_use_cache':bool(args.fusion_cache),'fusion_max_image_size':args.width}
    if args.depth_only:settings['depth_only']=True
    if args.indices:
        if len(set(args.indices))!=len(args.indices) or min(args.indices)<0:parser.error('Invalid explicit image indices')
        settings['explicit_image_indices']=sorted(args.indices)
    out = args.resume.resolve() if args.resume else source / 'dense_attempts' / (
        datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:8])
    out.relative_to(source)
    os.chdir(source)
    if args.resume:
        report = json.loads((out / 'report.json').read_text(encoding='utf-8'))
        if report['input_sha256'] != input_hash or report['settings'] != settings:
            raise ValueError('Resume requires the identical saved input and settings')
        report.setdefault('resumes', []).append(datetime.now().astimezone().isoformat())
    else:
        out.mkdir(parents=True)
        (out / 'input_sparse').mkdir()
        (out / 'driver_source.py').write_bytes(Path(__file__).read_bytes())
        reconstruction = pycolmap.Reconstruction(relative)
        keep = {key for key, image in reconstruction.images.items()
                if (indices[image.name] in args.indices if args.indices else
                    args.count == 0 or args.start_index <= indices[image.name] < args.start_index + args.count)}
        if args.indices:assert {indices[reconstruction.images[key].name] for key in keep}==set(args.indices)
        for image_id in list(reconstruction.images):
            if image_id not in keep:
                reconstruction.deregister_image(image_id)
        if reconstruction.num_reg_images() < 3 or reconstruction.num_points3D() < 10:
            raise ValueError('Insufficient saved-camera support in selected subset')
        reconstruction.write((out / 'input_sparse').relative_to(source).as_posix())
        report = {'status': 'prepared', 'input_model': str(model), 'input_sha256': input_hash,
                  'settings': settings, 'registered_images': reconstruction.num_reg_images(),
                  'input_points': reconstruction.num_points3D(),
                  'selected_image_indices': sorted(indices[reconstruction.images[i].name] for i in reconstruction.reg_image_ids()),
                  'scope': 'Saved image-only cameras; subset timing/geometry pilot' if args.count else
                           'All registered cameras in supplied image-only model; attempted inventory coverage separately recorded',
                  'reference_access': False, 'stages': [], 'launches': [],
                  'runtime_includes_camera_estimation': False}
        if report['selected_image_indices']==list(range(576)):
            report['scope']='All576 main-route photographs; common dense-output domain; supplied camera initializer also used two lower-altitude photos'
        if args.indices:report['scope']='Explicit context using saved global cameras; coverage feasibility pilot, not an independent end-to-end comparison'

    def save():
        tmp = out / 'report.tmp'
        tmp.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, out / 'report.json')

    start = time.perf_counter()
    report['status'] = 'running'
    launch = {'started': datetime.now().astimezone().isoformat(), 'limit_seconds': args.seconds}
    report['launches'].append(launch)
    save()
    print(json.dumps({'output': str(out)}, ensure_ascii=True), flush=True)

    def rel(path):
        return path.relative_to(source).as_posix()

    def stage(name, arguments):
        remaining = args.seconds - (time.perf_counter() - start)
        if remaining <= 0:
            raise subprocess.TimeoutExpired(name, args.seconds)
        command = [EXE] + arguments
        entry = {'name': name, 'command': command, 'status': 'running'}
        report['stages'].append(entry)
        save()
        tic = time.perf_counter()
        with (out / (name + '.log')).open('a', encoding='utf-8') as log:
            result = subprocess.run(command, cwd=source, stdout=log, stderr=subprocess.STDOUT,
                                    timeout=remaining)
        entry.update(seconds=time.perf_counter() - tic, exit_code=result.returncode,
                     status='completed' if result.returncode == 0 else 'failed')
        save()
        if result.returncode:
            raise RuntimeError(f'{name} failed with exit code {result.returncode}')

    try:
        if not any(s['name'] == 'undistort' and s['status'] == 'completed' for s in report['stages']):
            stage('undistort', ['image_undistorter', '--image_path', 'images', '--input_path', rel(out / 'input_sparse'),
                               '--output_path', rel(out / 'dense'), '--max_image_size', str(args.width),
                               '--num_patch_match_src_images', str(args.sources)])
        if not any(s['name'] == 'stereo' and s['status'] == 'completed' for s in report['stages']):
            stage('stereo', ['patch_match_stereo', '--workspace_path', rel(out / 'dense'),
                            '--PatchMatchStereo.max_image_size', str(args.width),
                            '--PatchMatchStereo.num_iterations', str(args.iterations),
                            '--PatchMatchStereo.geom_consistency', '1', '--PatchMatchStereo.cache_size', '2'])
        if args.depth_only:
            report['status']='depth_maps_completed'
            report['fusion_policy']='Separately declared eight-core/eight-neighbor tiled fusion; no global-fusion attempt'
        else:
            stage('fusion', ['stereo_fusion', '--workspace_path', rel(out / 'dense'), '--input_type', 'geometric',
                             '--output_path', rel(out / 'dense/fused.ply'), '--StereoFusion.num_threads', '8',
                             '--StereoFusion.cache_size', '2', '--StereoFusion.use_cache', str(args.fusion_cache),
                             '--StereoFusion.max_image_size',str(args.width),
                             '--StereoFusion.min_num_pixels', str(args.fusion_min_pixels)])
            with (out / 'dense/fused.ply').open('rb') as stream:
                for _ in range(100):
                    line = stream.readline().decode('ascii').strip()
                    if line.startswith('element vertex '):report['dense_points'] = int(line.split()[-1])
                    if line == 'end_header':break
            report['status'] = 'completed' if report.get('dense_points', 0) else 'completed_empty_dense'
        report['geometry_readback_required'] = True
    except subprocess.TimeoutExpired as exc:
        report.update(status='timeout', error=repr(exc))
    except Exception as exc:
        report.update(status='failed', error=repr(exc))
    finally:
        launch['seconds'] = time.perf_counter() - start
        report['input_unchanged'] = hashes(model) == input_hash
        save()
        print(json.dumps({'status': report['status'], 'output': str(out)}, ensure_ascii=True), flush=True)
    return 0 if report['status'] in ('completed','depth_maps_completed') and report['input_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
