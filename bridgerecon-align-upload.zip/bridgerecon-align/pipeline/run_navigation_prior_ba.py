"""Training-only points and withheld navigation IDs in bounded pose-prior BA."""
from pathlib import Path
from datetime import datetime
import argparse,hashlib,json,os,subprocess,sys,time,uuid
import numpy as np
from geometry_core import camera_centers
from similarity import fit_similarity,apply_similarity
from global_hybrid_geometry import project_native
from probe_cached_side_pnp import nominal_positions
from budget_run import OwnedJob
from work_schedule import require_start_window

BASE=Path(__file__).resolve().parent
SOURCE=BASE/'runs/full_route_survey_20261018_221243_8084fdb4'
PREP=SOURCE/'hybrid_preparations/20261019_194608_05d2032e'


def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,r):p.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
def nav_check(index):return int.from_bytes(hashlib.sha256(f'navigation-v1|{index}'.encode()).digest()[:8],'big')%5==0
def stats(v):return {'n':len(v),'median':float(np.median(v)),'p95':float(np.percentile(v,95))}


def worker(out,sigma,fixed_exif=False,resume=None,iterations=100,solver_seconds=240.,share_camera=False,height_sigma=None,quadratic_position=False):
    import pycolmap
    started=time.monotonic();os.chdir(SOURCE)
    preparation=read(PREP/'report.json');assert preparation['status']=='completed'
    initial_model=resume/'sparse' if resume else PREP/'fitted_sparse'
    if resume:
        previous=read(resume/'report.json');assert previous['status']=='completed' and previous['navigation_standard_deviation_assumption_metres']==sigma
        assert previous.get('calibration','Free shared focal/radial, fixed principal point').startswith('Fixed')==fixed_exif
        assert previous.get('shared_physical_camera_hypothesis',False)==share_camera
        assert previous.get('height_standard_deviation_assumption_metres')==height_sigma
        assert previous.get('prior_position_loss','Cauchy scale7.815')==('quadratic' if quadratic_position else 'Cauchy scale7.815')
    model=pycolmap.Reconstruction(initial_model.relative_to(SOURCE).as_posix())
    metadata=read(SOURCE/'report.json');names={v['name']:v['index'] for v in metadata['images']};inventory=read(BASE/'data_audit/images.json')
    images=sorted(model.images.values(),key=lambda im:names[im.name]);indices=np.array([names[im.name] for im in images]);image_ids=np.array([im.image_id for im in images])
    if share_camera:
        lens=read(BASE/'data_audit/image_lens_metadata_20261019.json')
        assert lens['shared_header_lens_hypothesis_supported'] and lens['classes'][0]['body_serial_sha256']
        assert lens['classes'][0]['digital_zoom']==1. and lens['classes'][0]['focal35_mm']==24.
        for image in images:
            if image.camera_id!=1:
                image.reset_camera_ptr();image.camera_id=1;image.camera=model.cameras[1]
        assert all(image.has_camera_ptr() and image.camera_id==1 for image in images)
    positions=nominal_positions(inventory)[indices];held=np.array([nav_check(int(i)) for i in indices]);centers=np.array([im.projection_center() for im in images])
    initial=fit_similarity(centers[~held],positions[~held])
    model.transform(pycolmap.Sim3d(initial[0],pycolmap.Rotation3d(initial[1]),initial[2]))
    if fixed_exif:
        for camera in model.cameras.values():
            assert camera.model.name=='SIMPLE_RADIAL'
            camera.params=np.array([camera.width*24./36.,camera.width/2.,camera.height/2.,0.])
    initial_centers=np.array([model.images[int(i)].projection_center() for i in image_ids])
    np.savez_compressed(out/'navigation_split.npz',image_ids=image_ids,image_indices=indices,checking=held,nominal_positions=positions)
    report={'status':'prepared','created':datetime.now().astimezone().isoformat(),'reference_access':False,'gpu_used':False,
            'source_preparation':str(PREP),'source_preparation_sha256':sha(PREP/'report.json'),
            'source_model_sha256':{n:sha(initial_model/n) for n in ['cameras.bin','images.bin','points3D.bin']},
            'initial_model':str(initial_model),'continuation_source':str(resume) if resume else None,
            'maximum_additional_iterations':iterations,'maximum_solver_seconds':solver_seconds,
            'navigation_standard_deviation_assumption_metres':sigma,'navigation_precision_known':False,
            'shared_physical_camera_hypothesis':share_camera,'height_standard_deviation_assumption_metres':height_sigma,
            'prior_position_loss':'quadratic' if quadratic_position else 'Cauchy scale7.815',
            'used_camera_ids':sorted({im.camera_id for im in images}),
            'calibration':'Fixed approximate 24mm-equivalent focal, centered principal point, zero radial; not survey calibration' if fixed_exif else 'Free shared focal/radial, fixed principal point',
            'training_navigation_cameras':int((~held).sum()),'withheld_navigation_cameras':int(held.sum()),
            'scope':'Navigation consistency on position-term-withheld cameras; source images still fitted and all-navigation audit previously inspected',
            'initial_train_navigation_error':stats(np.linalg.norm(initial_centers[~held]-positions[~held],axis=1)),
            'initial_withheld_navigation_error':stats(np.linalg.norm(initial_centers[held]-positions[held],axis=1))}
    write(out/'report.json',report)
    config=pycolmap.BundleAdjustmentConfig()
    for image_id in image_ids:config.add_image(int(image_id))
    covariance=np.diag([sigma*sigma,sigma*sigma,(height_sigma if height_sigma is not None else sigma)**2])
    priors={int(image_id):pycolmap.PosePrior(position,covariance,pycolmap.PosePriorCoordinateSystem.CARTESIAN)
            for image_id,position,is_check in zip(image_ids,positions,held) if not is_check}
    options=pycolmap.BundleAdjustmentOptions();options.use_gpu=False;options.refine_focal_length=True;options.refine_extra_params=True;options.refine_principal_point=False
    if fixed_exif:options.refine_focal_length=False;options.refine_extra_params=False
    options.solver_options.max_num_iterations=iterations;options.solver_options.max_solver_time_in_seconds=solver_seconds;options.solver_options.num_threads=4
    options.solver_options.function_tolerance=1e-6;options.solver_options.gradient_tolerance=1e-4;options.solver_options.parameter_tolerance=1e-7
    prior_options=pycolmap.PosePriorBundleAdjustmentOptions();prior_options.use_robust_loss_on_prior_position=not quadratic_position;prior_options.ransac_max_error=3*sigma
    report.update(status='optimizing',ba_options=str(options),prior_options=str(prior_options));write(out/'report.json',report)
    if sigma:
        adjuster=pycolmap.create_pose_prior_bundle_adjuster(options,prior_options,config,priors,model)
        summary=adjuster.solve()
    else:
        first=int(image_ids[0]);far=int(image_ids[np.argmax(np.linalg.norm(initial_centers-initial_centers[0],axis=1))])
        config.set_constant_cam_pose(first)
        translation=model.images[far].cam_from_world.translation-model.images[first].cam_from_world.translation
        config.set_constant_cam_positions(far,[int(np.argmax(abs(translation)))])
        adjuster=pycolmap.create_default_bundle_adjuster(options,config,model)
        summary=adjuster.solve()
    report['solver']={'brief':summary.BriefReport(),'message':summary.message,'termination':str(summary.termination_type),
                      'solution_usable':summary.IsSolutionUsable(),'initial_cost':summary.initial_cost,'final_cost':summary.final_cost,
                      'successful_steps':summary.num_successful_steps,'unsuccessful_steps':summary.num_unsuccessful_steps,'solver_seconds':summary.total_time_in_seconds}
    assert summary.IsSolutionUsable(),'Unusable native pose-prior result'
    images=[model.images[int(i)] for i in image_ids];E=np.array([im.cam_from_world.matrix() for im in images]);centers=camera_centers(E)
    # Record direct native frame, then use only training navigation to fix any remaining output gauge.
    report['native_frame_navigation_error']=stats(np.linalg.norm(centers-positions,axis=1))
    final=fit_similarity(centers[~held],positions[~held]);model.transform(pycolmap.Sim3d(final[0],pycolmap.Rotation3d(final[1]),final[2]))
    images=[model.images[int(i)] for i in image_ids];E=np.array([im.cam_from_world.matrix() for im in images]);centers=camera_centers(E)
    report['train_navigation_error']=stats(np.linalg.norm(centers[~held]-positions[~held],axis=1));report['withheld_navigation_error']=stats(np.linalg.norm(centers[held]-positions[held],axis=1))
    cameras={str(cid):{'model':c.model.name,'width':c.width,'height':c.height,'params':c.params.tolist()} for cid,c in model.cameras.items()}
    errors=[];positive=0;total=0
    for image,e in zip(images,E):
        obs=[p for p in image.points2D if p.has_point3D()]
        xyz=np.array([model.points3D[p.point3D_id].xyz for p in obs]);uv=np.array([p.xy for p in obs])
        projected,z=project_native(xyz,e,cameras[str(image.camera_id)],np.eye(3))
        errors.extend(np.linalg.norm(projected-uv,axis=1));positive+=int((z>0).sum());total+=len(z)
    report.update(training_reprojection_pixels=stats(np.array(errors)),training_positive_depth_fraction=positive/total,native_cameras=cameras,
                  stored_coordinate_units='Navigation metres with unknown navigation accuracy; no survey calibration')
    destination=out/'sparse';destination.mkdir();model.write(destination.relative_to(SOURCE).as_posix())
    np.savez_compressed(out/'cameras.npz',extrinsics=E,image_indices=indices,image_ids=image_ids,nominal_positions=positions,centers=centers,navigation_checking=held)
    with np.load(PREP/'split.npz') as split:assert set(model.points3D)==set(map(int,split['selected_training_ids'])) and not set(model.points3D).intersection(map(int,split['checking_ids']))
    report.update(status='completed',source_unchanged=all(sha(initial_model/n)==h for n,h in report['source_model_sha256'].items()),
                  output_sha256={n:sha(destination/n) for n in report['source_model_sha256']},seconds=time.monotonic()-started)
    assert report['source_unchanged'];write(out/'report.json',report);print('REPORT',out,flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--sigma',type=float,choices=[0.,5.,10.,20.],default=10.);p.add_argument('--worker',action='store_true');p.add_argument('--out',type=Path)
    p.add_argument('--fixed-exif',action='store_true');p.add_argument('--resume',type=Path)
    p.add_argument('--share-camera',action='store_true');p.add_argument('--height-sigma',type=float,choices=[.5,1.,2.])
    p.add_argument('--quadratic-position',action='store_true')
    p.add_argument('--iterations',type=int,default=100);p.add_argument('--solver-seconds',type=float,default=240.);args=p.parse_args()
    assert 1<=args.iterations<=500 and 1<=args.solver_seconds<=600
    if args.worker:
        try:worker(args.out.resolve(),args.sigma,args.fixed_exif,args.resume.resolve() if args.resume else None,args.iterations,args.solver_seconds,args.share_camera,args.height_sigma,args.quadratic_position)
        except Exception as exc:
            path=args.out/'report.json';r=read(path) if path.exists() else {};r.update(status='failed',error=repr(exc));write(path,r);raise
        return
    require_start_window(args.solver_seconds+360)
    out=SOURCE/'navigation_prior_controls'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir(parents=True)
    (out/'driver_source.py').write_bytes(Path(__file__).read_bytes());env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='-1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',PYTHONIOENCODING='utf-8')
    with (out/'worker.log').open('w',encoding='utf-8') as log:
        command=[sys.executable,'-u',str(Path(__file__).resolve()),'--worker','--out',str(out),'--sigma',str(args.sigma)]
        if args.fixed_exif:command.append('--fixed-exif')
        if args.resume:command.extend(['--resume',str(args.resume.resolve())])
        if args.share_camera:command.append('--share-camera')
        if args.height_sigma is not None:command.extend(['--height-sigma',str(args.height_sigma)])
        if args.quadratic_position:command.append('--quadratic-position')
        command.extend(['--iterations',str(args.iterations),'--solver-seconds',str(args.solver_seconds)])
        child=subprocess.Popen(command,cwd=BASE.parent,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW);owned=OwnedJob(child)
        try:code=child.wait(timeout=args.solver_seconds+300)
        except subprocess.TimeoutExpired:owned.terminate();child.wait(timeout=15);raise
        finally:owned.close()
    print('REPORT',out)
    if code:print((out/'worker.log').read_text(encoding='utf-8',errors='replace')[-3500:]);raise SystemExit(code)


if __name__=='__main__':main()
