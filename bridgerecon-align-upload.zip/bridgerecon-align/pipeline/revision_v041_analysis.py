"""v0.41 review-response analyses computed from frozen outputs only.

Anchor-only depth baselines (no network), pair-baseline geometry, route-block
bootstrap intervals, depth-scale statistics, camera intrinsics and timing ledgers.
CPU only; no reconstruction, no GPU, no change to any existing run directory.
"""
from pathlib import Path
from datetime import datetime
import hashlib, json, sys, time
import numpy as np
from scipy.interpolate import LinearNDInterpolator, NearestNDInterpolator

BASE = Path(__file__).resolve().parent
RUNS = BASE / 'runs'
PRIMARY = RUNS / 'global_hybrid_20261019_205203_28fc26c6'
MVS = RUNS / 'native_mvs_checking_20261020_001654_cd47ff08'
SEAMS = RUNS / 'full_hybrid_seams_20261019_211732_4f0b9df9'
VGGT_CHUNKS = RUNS / 'vggt_route_chunks_20261019_195231_d0fd7976'
MVS_DEPTH = RUNS / 'full_route_survey_20261018_221243_8084fdb4/dense_attempts/20261019_205034_ab94308e'
CASES = {'C0': 'global_hybrid_20261019_200206_46cdaa3c', 'C1': 'global_hybrid_20261019_202608_c52f1d98',
         'C2': 'global_hybrid_20261019_202306_12e0d87d', 'C3': 'global_hybrid_20261019_202608_f0a87529',
         'C4': 'global_hybrid_20261019_202608_fdd3a7fc', 'C5': 'global_hybrid_20261019_205203_28fc26c6'}
VARIANTS = ['camera_aligned_raw', 'global_camera', 'chunk_depth_scale', 'view_depth_scale']
sys.path.insert(0, str(BASE))
sys.path.insert(0, str(PRIMARY))  # the run's own copy of the evaluation geometry
from global_hybrid_geometry import unproject_native, project_native, native_rays  # noqa: E402
from local_validation import inside  # noqa: E402


def read(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stats(x):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    return {'n': int(len(x)), 'median': float(np.median(x)) if len(x) else None,
            'p95': float(np.percentile(x, 95)) if len(x) else None}


def robust_plane(points):
    """Least-squares plane refitted on points within 3 scaled MADs of the first fit."""
    keep = np.ones(len(points), bool)
    for _ in range(3):
        centre = points[keep].mean(axis=0)
        _, _, vt = np.linalg.svd(points[keep] - centre, full_matrices=False)
        normal = vt[2]; distance = (points - centre) @ normal
        mad = np.median(abs(distance[keep] - np.median(distance[keep]))) * 1.4826 + 1e-9
        keep = abs(distance) <= 3 * mad
    return normal, centre


def anchor_baselines(samples, prep, cameras):
    """Depth at each checking sample from calibration anchors only (training IDs)."""
    n = len(samples['ids']); depth = {k: np.full(n, np.nan) for k in ('anchor_constant', 'anchor_plane', 'anchor_tin')}
    views = {v['index']: v for v in prep['views']}; models = {}
    for index in np.unique(samples['view']):
        a = np.load(PRIMARY_PREP / views[int(index)]['file'])
        uv, z = a['train_uv'], a['train_z']
        use = a['train_eligible'] & inside(uv) & np.isfinite(z) & (z > 0)
        E, A = a['extrinsics'], a['native_to_input']; camera = cameras[str(int(a['camera_id']))]
        rows = np.where(samples['view'] == index)[0]; quv = samples['uv'][rows]
        depth['anchor_constant'][rows] = np.median(z[use])
        normal, centre = robust_plane(a['train_xyz'][use])
        rays = native_rays(quv, camera, A) @ E[:, :3]          # world directions with unit camera z
        origin = -E[:, :3].T @ E[:, 3]
        denom = rays @ normal
        depth['anchor_plane'][rows] = np.where(abs(denom) > 1e-9, ((centre - origin) @ normal) / denom, np.nan)
        linear = LinearNDInterpolator(uv[use], z[use]); nearest = NearestNDInterpolator(uv[use], z[use])
        tin = linear(quv); missing = ~np.isfinite(tin); tin[missing] = nearest(quv[missing])
        depth['anchor_tin'][rows] = tin
        models[int(index)] = {'E': E, 'A': A, 'camera': camera, 'anchors': int(use.sum())}
    return depth, models


def pair_errors(xyz, valid, uv, view, source, target, models):
    errors = np.full(len(source), np.nan); supported = np.zeros(len(source), bool)
    for index, vm in models.items():
        sel = np.where(view[target] == index)[0]
        if not len(sel): continue
        pixel, z = project_native(xyz[source[sel]], vm['E'], vm['camera'], vm['A'])
        good = valid[source[sel]] & valid[target[sel]] & (z > 0) & np.isfinite(pixel).all(axis=1) & inside(pixel)
        e = np.linalg.norm(pixel - uv[target[sel]], axis=1)
        errors[sel[good]] = e[good]; supported[sel[good]] = True
    return errors, supported


def block_histograms(errors, mask, block, edges):
    h = np.zeros((72, len(edges) - 1))
    for b in range(72):
        sel = mask & (block == b)
        h[b] = np.histogram(np.clip(errors[sel], edges[0], edges[-1] * 0.999999), edges)[0]
    return h


def quantile_from_hist(h, edges, q):
    c = np.cumsum(h, axis=-1); target = q * c[..., -1:]
    i = np.argmax(c >= target, axis=-1)
    return np.sqrt(edges[i] * edges[i + 1])  # geometric bin centre


def main():
    tic = time.monotonic(); stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    out = RUNS / ('revision_v041_analysis_' + stamp); out.mkdir()
    (out / 'revision_v041_analysis.py').write_bytes(Path(__file__).read_bytes())
    primary = read(PRIMARY / 'report.json'); prep = read(PRIMARY_PREP / 'report.json')
    cameras = read(PRIMARY_PREP / 'native_cameras.json')
    s = dict(np.load(PRIMARY / 'checking_samples.npz')); p = dict(np.load(PRIMARY / 'checking_pairs.npz'))
    m = dict(np.load(MVS / 'checking_pairs.npz'))
    assert np.array_equal(p['source'], m['source']) and np.array_equal(p['target'], m['target'])
    si, ti, view, uv = p['source'], p['target'], s['view'], s['uv']
    report = {'status': 'running', 'created': datetime.now().astimezone().isoformat(), 'gpu_used': False,
              'inputs': {'primary_report_sha256': sha(PRIMARY / 'report.json'), 'mvs_report_sha256': sha(MVS / 'report.json'),
                         'preparation_report_sha256': sha(PRIMARY_PREP / 'report.json')},
              'scope': 'Frozen arrays only; same fixed pair inventory; calibration anchors only for baselines; no checking depth used'}

    # 1. Re-evaluate the stored per-image VGGT variant through this code path (must reproduce exactly).
    depth, models = anchor_baselines(s, prep, cameras)
    err_check, sup_check = pair_errors(s['xyz'][:, 3], s['valid'][:, 3], uv, view, si, ti, models)
    stored, stored_sup = p['errors'][:, 3], p['supported'][:, 3]
    reproduced = bool(np.array_equal(sup_check, stored_sup) and np.allclose(err_check[stored_sup], stored[stored_sup], atol=1e-9))
    report['reproduces_stored_view_scale_errors'] = reproduced; assert reproduced

    # 2. Anchor-only baselines on the identical inventory and support rule.
    refz = s['reference_z']; methods = {}; errors = {}; support = {}
    for k in range(4):
        errors[VARIANTS[k]] = p['errors'][:, k]; support[VARIANTS[k]] = p['supported'][:, k]
    errors['native_mvs1600'] = m['errors']; support['native_mvs1600'] = m['supported']
    for name, z in depth.items():
        xyz = np.empty((len(z), 3))
        for index, vm in models.items():
            rows = np.where(view == index)[0]
            xyz[rows] = unproject_native(uv[rows], z[rows], vm['E'], vm['camera'], vm['A'])
        zc = np.empty(len(z))
        for index, vm in models.items():
            rows = np.where(view == index)[0]; zc[rows] = (xyz[rows] @ vm['E'][:, :3].T + vm['E'][:, 3])[:, 2]
        valid = np.isfinite(xyz).all(axis=1) & (zc > 0) & np.isfinite(refz) & (refz > 0)
        e, ok = pair_errors(xyz, valid, uv, view, si, ti, models)
        errors[name], support[name] = e, ok
        rel = abs(z - refz) / refz; rel[~valid] = np.nan
        methods[name] = {'depth_relative_abs_error': stats(rel)}
    common5 = support['camera_aligned_raw'] & support['global_camera'] & support['chunk_depth_scale'] & support['view_depth_scale'] & support['native_mvs1600']
    assert int(common5.sum()) == 553678
    full = len(si)
    for name in errors:
        e, ok = errors[name], support[name]
        methods.setdefault(name, {}).update({
            'full_pairs': full, 'support_fraction': float(ok.mean()), 'success_below2px_full_inventory': float(np.sum(ok & (e < 2)) / full),
            'own_support': stats(e[ok]), 'five_method_common': stats(e[common5]),
            'view_scale_support_common': stats(e[support['view_depth_scale'] & ok])})
    report['methods'] = methods; report['five_method_common_pairs'] = int(common5.sum())

    # 3. Pair geometry: baseline length, intersection angle and flight pass.
    centres = {i: -vm['E'][:, :3].T @ vm['E'][:, 3] for i, vm in models.items()}
    C = np.array([centres[i] for i in range(576)])
    ref_xyz = np.full((len(view), 3), np.nan); views = {v['index']: v for v in prep['views']}
    for index in models:
        a = np.load(PRIMARY_PREP / views[index]['file']); lookup = dict(zip(a['checking_ids'].tolist(), range(len(a['checking_ids']))))
        rows = np.where(view == index)[0]
        idx = np.array([lookup.get(int(i), -1) for i in s['ids'][rows]])
        ok = idx >= 0; ref_xyz[rows[ok]] = a['checking_xyz'][idx[ok]]
    vs, vt = view[si], view[ti]
    baseline = np.linalg.norm(C[vs] - C[vt], axis=1)
    X = ref_xyz[si]; r1 = X - C[vs]; r2 = X - C[vt]
    angle = np.degrees(np.arccos(np.clip(np.sum(r1 * r2, 1) / (np.linalg.norm(r1, axis=1) * np.linalg.norm(r2, axis=1)), -1, 1)))
    passes = np.where(np.arange(576) <= 281, 1, np.where(np.arange(576) <= 573, 2, 3))
    cross = passes[vs] != passes[vt]
    edges_b = [0, 5, 10, 20, 40, 80, 1e9]; geometry = {'baseline_m': stats(baseline), 'baseline_percentiles_5_25_50_75_95': np.percentile(baseline, [5, 25, 50, 75, 95]).tolist(),
                                                         'intersection_angle_deg': stats(angle), 'cross_pass_fraction': float(cross.mean()),
                                                         'cross_pass_fraction_common5': float(cross[common5].mean()), 'bins': []}
    common_all = common5 & support['anchor_constant'] & support['anchor_plane'] & support['anchor_tin']
    for lo, hi in zip(edges_b[:-1], edges_b[1:]):
        sel = common_all & (baseline >= lo) & (baseline < hi)
        geometry['bins'].append({'baseline_m': [lo, hi if hi < 1e8 else None], 'pairs_eight_method_common': int(sel.sum()),
                                 'median_px': {k: (float(np.median(errors[k][sel])) if sel.any() else None) for k in ['view_depth_scale', 'native_mvs1600', 'anchor_constant', 'anchor_plane', 'anchor_tin']}})
    for label, sel in [('same_pass', common_all & ~cross), ('cross_pass', common_all & cross)]:
        geometry[label] = {'pairs': int(sel.sum()), 'median_px': {k: float(np.median(errors[k][sel])) for k in ['view_depth_scale', 'native_mvs1600', 'anchor_constant', 'anchor_plane', 'anchor_tin']}}
    report['pair_geometry'] = geometry

    # 4. Route-block bootstrap (72 groups of eight source images), common five-method pairs plus baselines.
    block = vs // 8; edges = np.geomspace(1e-3, 1e3, 6001); rng = np.random.default_rng(20261023); B = 2000
    names = ['camera_aligned_raw', 'global_camera', 'chunk_depth_scale', 'view_depth_scale', 'native_mvs1600', 'anchor_constant', 'anchor_plane', 'anchor_tin']
    weights = np.stack([np.bincount(rng.integers(0, 72, 72), minlength=72) for _ in range(B)]).astype(float)
    boot = {}
    for domain, mask in [('five_method_common', common5), ('eight_method_common', common_all)]:
        med, p95 = {}, {}
        for k in names:
            resampled = weights @ block_histograms(errors[k], mask, block, edges)
            med[k] = quantile_from_hist(resampled, edges, .5); p95[k] = quantile_from_hist(resampled, edges, .95)
            del resampled
        point = {k: float(np.nanmedian(errors[k][mask])) for k in names}
        res = {'pairs': int(mask.sum()), 'median': {}, 'p95': {}, 'differences_vs_view_scale_median': {}}
        for k in names:
            res['median'][k] = {'point': point[k], 'ci95': np.percentile(med[k], [2.5, 97.5]).tolist()}
            res['p95'][k] = {'point': float(np.nanpercentile(errors[k][mask], 95)), 'ci95': np.percentile(p95[k], [2.5, 97.5]).tolist()}
            if k != 'view_depth_scale':
                d = med[k] - med['view_depth_scale']
                res['differences_vs_view_scale_median'][k] = {'point': point[k] - point['view_depth_scale'], 'ci95': np.percentile(d, [2.5, 97.5]).tolist(),
                                                              'fraction_resamples_positive': float(np.mean(d > 0))}
        per_block = {k: [float(np.nanmedian(errors[k][mask & (block == b)])) for b in range(72)] for k in names}
        res['blocks_where_method_beats_view_scale'] = {k: int(np.sum(np.array(per_block[k]) < np.array(per_block['view_depth_scale']))) for k in names if k != 'view_depth_scale'}
        res['per_block_median_px'] = per_block
        boot[domain] = res
    report['bootstrap'] = {'groups': 72, 'definition': 'source image index // 8', 'resamples': B, 'seed': 20261023,
                           'histogram': 'log bins 1e-3..1e3 px, 6000 bins; quantiles at geometric bin centres', **boot}

    # 5. Scale statistics of the frozen calibration.
    chunks = primary['chunks']; q = np.array([c['depth_fit']['chunk_scale'] for c in chunks])
    motion = np.array([c['similarity']['scale'] for c in chunks])
    ratio = np.array([v['applied_scale'] / c['depth_fit']['chunk_scale'] for c in chunks for v in c['depth_fit']['views']])
    anchors = np.array([v['training_anchors'] for c in chunks for v in c['depth_fit']['views']])
    pooled = np.array([c['depth_fit']['pooled_training_observations'] for c in chunks])
    combined = motion * q
    report['scales'] = {'chunks': len(chunks), 'view_scale_acceptances': primary['actual_view_scale_acceptances'], 'view_scale_candidates': primary['total_view_scale_candidates'],
                        'pooled_q': {'min': float(q.min()), 'median': float(np.median(q)), 'max': float(q.max()), 'cv': float(q.std() / q.mean())},
                        'combined_depth_multiplier_cv': float(combined.std() / combined.mean()),
                        'view_to_chunk_ratio_percentiles_0_5_50_95_100': np.percentile(ratio, [0, 5, 50, 95, 100]).tolist(),
                        'view_anchor_percentiles_0_5_50_95_100': np.percentile(anchors, [0, 5, 50, 95, 100]).tolist(),
                        'pooled_anchor_percentiles_0_5_50_95_100': np.percentile(pooled, [0, 5, 50, 95, 100]).tolist(),
                        'per_chunk': [{'start': c['start'], 'q': c['depth_fit']['chunk_scale'], 'similarity_scale': c['similarity']['scale']} for c in chunks]}

    # 6. Camera intrinsics, convergence and implied ground sampling for each camera configuration.
    configurations = {}
    for label, run in CASES.items():
        r = read(RUNS / run / 'report.json'); pr_path = Path(r['preparation']); pr = read(pr_path / 'report.json')
        ids = {v['camera_id'] for v in pr['views'] if v['index'] < 576}
        cams = {k: v for k, v in pr['native_cameras'].items() if int(k) in ids}
        zs = []
        for v in pr['views']:
            if v['index'] >= 576: continue
            a = np.load(pr_path / v['file']); use = a['train_eligible'] & np.isfinite(a['train_z']) & (a['train_z'] > 0)
            zs.append(np.median(a['train_z'][use]))
        f = cams[str(min(ids))]['params'][0]; zmed = float(np.median(zs))
        configurations[label] = {'main_route_camera': cams[str(min(ids))], 'calibration': pr.get('camera_control_calibration'),
                                 'solver': (pr.get('camera_control_solver') or {}).get('brief'),
                                 'median_anchor_depth_m': zmed, 'focal_px_1600': f,
                                 'ground_sample_m_per_vggt_px': zmed / (f * 0.32375), 'ground_sample_m_per_1600_px': zmed / f}
    report['camera_configurations'] = configurations

    # 7. Seam metric magnitude: normalised differences times the image's fixed normaliser.
    seam = read(SEAMS / 'report.json'); vals = np.load(SEAMS / 'seam_normalized_differences.npz')['values']
    z_by_view = {}
    for v in prep['views']:
        if v['index'] >= 576: continue
        a = np.load(PRIMARY_PREP / v['file']); use = np.isfinite(a['train_z']) & (a['train_z'] > 0)
        z_by_view[v['index']] = float(np.median(a['train_z'][use]))
    report['seam_metric_magnitude'] = {'median_normaliser_m': float(np.median(list(z_by_view.values()))),
                                       'normaliser_percentiles_5_50_95_m': np.percentile(list(z_by_view.values()), [5, 50, 95]).tolist(),
                                       'normalised': {VARIANTS[k]: stats(vals[:, k]) for k in range(4)},
                                       'approx_metres_at_median_normaliser': {VARIANTS[k]: {q: float(np.percentile(vals[:, k], qq) * np.median(list(z_by_view.values())))
                                                                                           for q, qq in [('median', 50), ('p95', 95)]} for k in range(4)}}

    # 8. Full-route processing ledgers already recorded by the original jobs.
    vg = read(VGGT_CHUNKS / 'report.json'); md = read(MVS_DEPTH / 'report.json')
    inference = [c['inference_seconds'] for c in vg['chunks'] if c.get('inference_seconds') is not None]
    report['full_route_timing'] = {
        'vggt_model_load_s': vg['model_load_seconds'], 'vggt_chunk_seconds_sum_72': float(sum(c['seconds'] for c in vg['chunks'])),
        'vggt_chunks_measured_in_job': len(inference), 'vggt_forward_seconds_measured': stats(inference),
        'vggt_peak_allocated_MiB_max': float(max(c['peak_allocated_MiB'] for c in vg['chunks'] if c.get('peak_allocated_MiB') is not None)),
        'vggt_peak_reserved_MiB_max': float(max(c['peak_reserved_MiB'] for c in vg['chunks'] if c.get('peak_reserved_MiB') is not None)),
        'calibration_and_evaluation_four_variants_s': primary['seconds'],
        'mvs1600_undistort_s': next(st['seconds'] for st in md['stages'] if st['name'] == 'undistort'),
        'mvs1600_launch_s': md['launches'][0]['seconds'], 'mvs1600_settings': md['settings'],
        'note': 'Separate single launches on the RTX 4060 Laptop GPU; SfM excluded; nine VGGT chunks carried over from identical-setting earlier jobs with their own recorded seconds.'}
    report.update(status='completed', seconds=time.monotonic() - tic)
    (out / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding='utf-8')
    np.savez_compressed(out / 'baseline_pairs.npz', **{k: errors[k] for k in ['anchor_constant', 'anchor_plane', 'anchor_tin']},
                        **{k + '_supported': support[k] for k in ['anchor_constant', 'anchor_plane', 'anchor_tin']},
                        baseline_m=baseline, intersection_deg=angle, cross_pass=cross, common5=common5)
    print('REPORT', out)


PRIMARY_PREP = Path(read(PRIMARY / 'report.json')['preparation'])
if __name__ == '__main__':
    main()
