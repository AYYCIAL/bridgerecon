"""Fixed-inventory, common-support and image-only envelope strata of saved runs."""
from pathlib import Path
from datetime import datetime
import csv,hashlib,json,time,uuid
import numpy as np
from bridge_roi_audit import fit_strips
from global_hybrid_geometry import VARIANTS
from local_validation import statistics
from work_schedule import require_start_window

BASE=Path(__file__).resolve().parent
CASES={
 'original_free':'global_hybrid_20261019_200206_46cdaa3c',
 'free_no_position_100':'global_hybrid_20261019_202608_c52f1d98',
 'free_position10_100':'global_hybrid_20261019_202306_12e0d87d',
 'fixed_no_position_100':'global_hybrid_20261019_202608_f0a87529',
 'fixed_position10_100':'global_hybrid_20261019_202608_fdd3a7fc',
 'shared_height1_converged':'global_hybrid_20261019_205203_28fc26c6'}

def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,r):p.write_text(json.dumps(r,indent=2),encoding='utf-8')


def freeze_masks(run,out):
    """Never read errors here: only input RGB, immutable ownership and mask rules."""
    fixed=read(run/'frozen_parameters.json');owners={int(k):v for k,v in fixed['ownership'].items()}
    masks=None;qualified=np.zeros(576,bool);records=[]
    for chunk in fixed['chunks']:
        require_start_window(120)
        with np.load(chunk['input']) as data:rgb=data['rgb']
        if masks is None:masks=np.zeros((576,*rgb.shape[1:3]),bool)
        for slot,index in enumerate(chunk['image_indices']):
            if owners[index]['start']!=chunk['start']:continue
            candidates=[]
            for turns in [0,1]:
                mask,record=fit_strips(np.rot90(rgb[slot],turns));candidates.append((mask,record))
            turn=next((i for i,(mask,record) in enumerate(candidates) if mask is not None),None)
            row={'index':index,'qualified':turn is not None,'tested_original_and_ccw90':[{k:v for k,v in rec.items() if k not in ['left_pixels','right_pixels']} for mask,rec in candidates]}
            if turn is not None:
                masks[index]=np.rot90(candidates[turn][0],-turn);qualified[index]=True;row['selected_ccw_turns']=turn
            records.append(row)
        del rgb
    np.savez_compressed(out/'frozen_envelopes.npz',masks=masks,qualified=qualified)
    write(out/'envelope_inventory.json',{'qualified_photos':int(qualified.sum()),'total_photos':576,'rows':sorted(records,key=lambda r:r['index']),
          'reference_access':False,'error_access':False,'warning':'Painted-strip envelope, not semantic or physical-boundary truth'})
    print('MASKS_FROZEN',int(qualified.sum()),flush=True)
    return masks,qualified


def main():
    require_start_window(1800);tic=time.monotonic()
    out=BASE/'runs'/('full_hybrid_summary_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir()
    (out/'driver_source.py').write_bytes(Path(__file__).read_bytes());(out/'bridge_roi_audit.py').write_bytes((BASE/'bridge_roi_audit.py').read_bytes())
    paths={case:BASE/'runs'/folder for case,folder in CASES.items()};mainpath=paths['shared_height1_converged']
    masks,qualified=freeze_masks(mainpath,out);masksha=sha(out/'frozen_envelopes.npz')
    common_observations=None;common_pairs=None;inventory=None
    for case,path in paths.items():
        r=read(path/'report.json');assert r['status']=='completed' and r['unique_photos']==576 and r['source_predictions_unchanged']
        with np.load(path/'checking_samples.npz') as data:
            current={key:data[key] for key in ['ids','view','uv']};valid=data['valid'].all(axis=1)
        with np.load(path/'checking_pairs.npz') as pairs:
            current.update(source=pairs['source'],target=pairs['target']);supported=pairs['supported'].all(axis=1)
        if inventory is None:inventory=current
        else:
            for key in inventory:assert np.array_equal(inventory[key],current[key]),(case,key)
        common_observations=valid if common_observations is None else common_observations&valid
        common_pairs=supported if common_pairs is None else common_pairs&supported
        del current,valid,supported
    # Freeze the identical denominators before computing any group error summary.
    np.savez_compressed(out/'common_inventory.npz',**inventory,common_observations=common_observations,common_pairs=common_pairs)
    x=np.rint(inventory['uv'][:,0]).astype(int);y=np.rint(inventory['uv'][:,1]).astype(int);views=inventory['view']
    inside=masks[views,y,x]&qualified[views];outside=~masks[views,y,x]&qualified[views];del masks
    si,ti=inventory['source'],inventory['target']
    strata={'all':np.ones(len(si),bool),'both_inside_envelope':inside[si]&inside[ti],
            'at_least_one_outside_in_qualified_view':outside[si]|outside[ti]}
    strata['unresolved']=~(strata['both_inside_envelope']|strata['at_least_one_outside_in_qualified_view'])
    assert np.sum(strata['both_inside_envelope'])+np.sum(strata['at_least_one_outside_in_qualified_view'])+np.sum(strata['unresolved'])==len(si)
    source_block=views[si]//8;rows=[];sources=[];curves={};blockrows=[]
    for case,path in paths.items():
        r=read(path/'report.json');sources.append({'case':case,'report':str(path.relative_to(BASE)/'report.json'),'sha256':sha(path/'report.json')})
        with np.load(path/'checking_pairs.npz') as data:errors=data['errors'];supported=data['supported']
        with np.load(path/'checking_samples.npz') as data:
            z=data['predicted_z'];ref=data['reference_z'];valid=data['valid'];relative=np.abs(z-ref[:,None])/ref[:,None]
        baseline_blocks=np.array([np.median(errors[common_pairs&(source_block==b),0]) for b in range(72)])
        for k,variant in enumerate(VARIANTS):
            for stratum,mask in strata.items():
                current=mask&common_pairs
                row={'case':case,'variant':variant,'stratum':stratum,'fixed_pairs':int(mask.sum()),'supported_pairs':int(supported[mask,k].sum()),
                     'support_fraction':float(supported[mask,k].mean()) if mask.any() else None,
                     'success_below2px_full_inventory':float((errors[mask,k]<2).mean()) if mask.any() else None,
                     'original_support_error':statistics(errors[mask,k]),'common_support_error':statistics(errors[current,k])}
                rows.append(row)
            values=relative[common_observations,k];all_depth=relative[valid[:,k],k]
            rows[-4]['common_support_depth_relative']=statistics(values);rows[-4]['original_support_depth_relative']=statistics(all_depth)
            blocks=np.array([np.median(errors[common_pairs&(source_block==b),k]) for b in range(72)])
            blockrows.append({'case':case,'variant':variant,'valid_blocks':int(np.isfinite(blocks).sum()),
                              'improved_blocks_against_own_camera_aligned_raw':int((blocks<baseline_blocks).sum()),
                              'per_block_median_pixels':blocks.tolist(),'raw_block_median_pixels':baseline_blocks.tolist()})
            quantiles=np.linspace(0,1,501);curves[f'{case}/{variant}']={'q':quantiles.tolist(),'pixels':np.quantile(errors[common_pairs,k],quantiles).tolist()}
        print('SUMMARIZED',case,flush=True);del errors,supported,z,ref,relative,valid
    report={'status':'completed','created':datetime.now().astimezone().isoformat(),'sources':sources,'cases':CASES,'variants':VARIANTS,
            'same_observation_and_pair_inventory':True,'observations':len(views),'pairs':len(si),'common_observations':int(common_observations.sum()),
            'common_pairs_all24_configurations':int(common_pairs.sum()),'configurations':len(CASES)*len(VARIANTS),
            'qualified_envelope_photographs':int(qualified.sum()),'envelope_sha256':masksha,'rows':rows,'blocks':blockrows,
            'reference_access':False,'independent_bridges':1,'time_seconds':time.monotonic()-tic,
            'scope':'Later development; original all-track SfM initializer reused checking tracks; navigation accuracy unknown; no physical accuracy',
            'depth_comparison_caveat':'Each camera model has its own retriangulated depth reference; identical image endpoints, not identical 3D reference',
            'block_inference':'72 spatially correlated groups from the same bridge; not independent experimental replicates'}
    assert sha(out/'frozen_envelopes.npz')==masksha
    write(out/'report.json',report);write(out/'common_support_cdf.json',curves)
    columns=['case','variant','stratum','fixed_pairs','supported_pairs','support_fraction','success_below2px_full_inventory','common_pairs','median_pixels','p95_pixels','depth_median','depth_p95']
    with (out/'paired_results.csv').open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,columns);writer.writeheader()
        for row in rows:
            d={k:row[k] for k in columns if k in row};e=row['common_support_error'];d.update(common_pairs=e['n'],median_pixels=e['median'],p95_pixels=e['p95'])
            if 'common_support_depth_relative' in row:d.update(depth_median=row['common_support_depth_relative']['median'],depth_p95=row['common_support_depth_relative']['p95'])
            writer.writerow(d)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    for variant in VARIANTS:
        c=curves['shared_height1_converged/'+variant];axes[0].plot(c['pixels'],c['q'],label=variant.replace('_',' '))
    for case in CASES:
        c=curves[case+'/view_depth_scale'];axes[1].plot(c['pixels'],c['q'],label=case.replace('_',' '))
    for ax in axes:ax.set(xlim=(0,10),ylim=(0,1),xlabel='Checking pair discrepancy (VGGT pixels)',ylabel='Cumulative fraction on common support');ax.legend(fontsize=7);ax.grid(alpha=.2)
    axes[0].set_title('Shared-height cameras: depth components');axes[1].set_title('View depth scale: camera controls')
    fig.suptitle('Same checking pairs; conditional image consistency, one bridge')
    fig.savefig(out/'paired_consistency.png',dpi=180);fig.savefig(out/'paired_consistency.pdf');plt.close(fig)
    print('REPORT',out,flush=True)


def summarize_evening(queue_override=None):
    """Use only completed queued outputs; never infer results from the plan."""
    queue_path=Path(queue_override) if queue_override else BASE/'runs/evening_controls_20261019_211411_9e7faa0c/report.json'
    queue=read(queue_path)
    if queue['status']!='completed_with_stage_statuses' or not queue.get('native_mvs_checking'):
        print(json.dumps({'status':'not_ready','queue_status':queue['status']}));return
    heights=queue['height_controls']
    if len(heights)!=2 or not all(row['status']=='completed' for row in heights):
        print(json.dumps({'status':'incomplete_height_controls','height_controls':heights}));return
    require_start_window(900);started=time.monotonic()
    primary=BASE/'runs'/CASES['shared_height1_converged'];native=Path(queue['native_mvs_checking'])
    sources={'primary':primary,'native_mvs':native}
    sources.update({f"height_{row['height_sigma']:g}":Path(row['hybrid']) for row in heights})
    records={};identity=None
    for name,path in sources.items():
        report=read(path/'report.json');assert report['status']=='completed'
        with np.load(path/'checking_samples.npz') as data:
            inventory={key:data[key] for key in ['ids','view','uv']}
            records[name]={'reference':data['reference_z'],'predicted':data['predicted_z'],'valid':data['valid']}
        with np.load(path/'checking_pairs.npz') as data:
            inventory.update(source=data['source'],target=data['target']);records[name].update(errors=data['errors'],support=data['supported'])
        if identity is None:identity=inventory
        else:
            for key in identity:assert np.array_equal(identity[key],inventory[key]),(name,key)
    assert np.array_equal(records['native_mvs']['reference'],records['primary']['reference'],equal_nan=True)
    groups={
        'same_camera_native_comparison':[(v,'primary',k) for k,v in enumerate(VARIANTS)]+[('native_mvs','native_mvs',None)],
        'height_sensitivity_view_scale':[('height_0.5','height_0.5',3),('height_1','primary',3),('height_2','height_2',3)]}
    envelope=BASE/'runs/full_hybrid_summary_20261019_210510_6aff3186/frozen_envelopes.npz'
    with np.load(envelope) as data:masks=data['masks'];qualified=data['qualified']
    views=identity['view'];uv=identity['uv'];x=np.rint(uv[:,0]).astype(int);y=np.rint(uv[:,1]).astype(int)
    inside=masks[views,y,x]&qualified[views];outside=~masks[views,y,x]&qualified[views];del masks
    si,ti=identity['source'],identity['target'];strata={'all':np.ones(len(si),bool),'both_inside_envelope':inside[si]&inside[ti],
            'at_least_one_outside_in_qualified_view':outside[si]|outside[ti]}
    strata['unresolved']=~(strata['both_inside_envelope']|strata['at_least_one_outside_in_qualified_view'])
    out=BASE/'runs'/('evening_comparison_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir()
    (out/'driver_source.py').write_bytes(Path(__file__).read_bytes());rows=[];curves={};common_counts={};blocks=[]
    for group,methods in groups.items():
        common=np.ones(len(si),bool);common_obs=np.ones(len(views),bool)
        for label,name,column in methods:
            item=records[name];common&=item['support'] if column is None else item['support'][:,column]
            common_obs&=item['valid'] if column is None else item['valid'][:,column]
        common_counts[group]={'pairs':int(common.sum()),'observations':int(common_obs.sum())}
        for label,name,column in methods:
            item=records[name];error=item['errors'] if column is None else item['errors'][:,column]
            support=item['support'] if column is None else item['support'][:,column]
            predicted=item['predicted'] if column is None else item['predicted'][:,column]
            valid=item['valid'] if column is None else item['valid'][:,column]
            ref=item['reference'];relative=np.full(len(ref),np.nan);good=np.isfinite(ref)&(ref>0)
            relative[good]=abs(predicted[good]-ref[good])/ref[good]
            for stratum,mask in strata.items():
                row={'group':group,'method':label,'stratum':stratum,'full_pairs':int(mask.sum()),
                     'support_fraction':float(support[mask].mean()) if mask.any() else None,
                     'success_below2px_full_inventory':float((error[mask]<2).mean()) if mask.any() else None,
                     'own_support_pixels':statistics(error[mask]),'common_support_pixels':statistics(error[mask&common])}
                if stratum=='all':row.update(common_depth_relative=statistics(relative[common_obs]),own_depth_relative=statistics(relative[valid]),
                                            full_observation_support_fraction=float(valid.mean()))
                rows.append(row)
            quantile=np.linspace(0,1,501);curves[group+'/'+label]={'q':quantile.tolist(),'pixels':np.quantile(error[common],quantile).tolist()}
            medians=[]
            for block in range(72):
                selected=common&(views[si]//8==block);medians.append(float(np.median(error[selected])) if selected.any() else None)
            blocks.append({'group':group,'method':label,'correlated_blocks':72,'median_pixels_by_block':medians})
    camera_rows=[]
    for row in heights:
        control=read(Path(row['control'])/'report.json')
        camera_rows.append({'height_sigma':row['height_sigma'],'control':row['control'],'control_report_sha256':sha(Path(row['control'])/'report.json'),
                            'solver':control['solver'],'navigation':control['withheld_navigation_error'],
                            'training_reprojection_pixels':control['training_reprojection_pixels'],'camera_params':control['native_cameras']['1']['params']})
    ledger=read(BASE/'gpu_ledger.json');jobs=[]
    for job in ledger['jobs']:
        if job.get('name') in ['vggt_main_route_hybrid_inputs','corrected_shared_height_main576_dense1600']:
            jobs.append({k:job.get(k) for k in ['name','status','charged_seconds','started_utc','ended_utc']})
    completion=read(BASE/'runs/corrected_dense_completion_20261019_210219_c6544bdd/report.json')
    report={'status':'completed','created':datetime.now().astimezone().isoformat(),'rows':rows,'groups':common_counts,'blocks':blocks,
            'same_observation_and_pair_inventory':True,'observations':len(views),'pairs':len(si),'envelope_sha256':sha(envelope),
            'sources':[{'label':name,'path':str(path),'report_sha256':sha(path/'report.json')} for name,path in sources.items()],
            'camera_sensitivity':camera_rows,'managed_gpu_jobs':jobs,'dense_completion_stages':completion['stages'],
            'reference_access':False,'independent_bridges':1,'seconds':time.monotonic()-started,
            'limits':['Source SfM initializer used checking observations; conditional later development',
                      'Native MVS uses full texture and1600 maximum dimension vs518x392VGGT; unequal fitting access/resolution',
                      'Shared SfM preparation not included in incremental GPU jobs, and nine VGGT chunks reused',
                      'Height-specific checking depths are retriangulated at different cameras, not one common3Dtruth',
                      'Navigation accuracy unknown; physical shared targets0; no metric accuracy or cross-bridge inference']}
    write(out/'report.json',report);write(out/'common_support_cdf.json',curves)
    fields=['group','method','stratum','full_pairs','support_fraction','success_below2px_full_inventory','common_pairs','median_pixels','p95_pixels']
    with (out/'comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fields);writer.writeheader()
        for row in rows:
            value={k:row[k] for k in fields if k in row};s=row['common_support_pixels']
            writer.writerow({**value,'common_pairs':s['n'],'median_pixels':s['median'],'p95_pixels':s['p95']})
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    for ax,(group,methods) in zip(axes,groups.items()):
        for label,name,column in methods:
            curve=curves[group+'/'+label];ax.plot(curve['pixels'],curve['q'],label=label.replace('_',' '))
        ax.set(xlim=(0,6),ylim=(0,1),xlabel='Checking pair discrepancy (VGGT pixels)',ylabel='Cumulative fraction, group common support')
        ax.legend(fontsize=7);ax.grid(alpha=.2)
    axes[0].set_title('Same cameras; MVS resolution/fitting access differ');axes[1].set_title('Height assumptions: descriptive sensitivity')
    fig.suptitle('Single-bridge conditional consistency; no measured accuracy')
    fig.savefig(out/'evening_comparison.png',dpi=180);fig.savefig(out/'evening_comparison.pdf');plt.close(fig)
    print('REPORT',out,flush=True)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--evening',action='store_true');parser.add_argument('--queue',type=Path);args=parser.parse_args()
    if args.evening:summarize_evening(args.queue)
    else:main()
