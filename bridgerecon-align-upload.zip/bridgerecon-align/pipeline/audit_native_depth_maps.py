"""Read all native geometric maps without loading a whole route into memory."""
from pathlib import Path
from datetime import datetime
import argparse,hashlib,json,time
import numpy as np


def map_view(path):
    with path.open('rb') as stream:
        tokens=[];token=b''
        while len(tokens)<3:
            char=stream.read(1)
            if not char or stream.tell()>80:raise ValueError('Invalid native map header')
            if char==b'&':tokens.append(int(token));token=b''
            else:token+=char
        offset=stream.tell()
    width,height,channels=tokens
    assert min(tokens)>0 and path.stat().st_size==offset+4*width*height*channels
    raw=np.memmap(path,mode='r',dtype='<f4',offset=offset,shape=(width*height*channels,))
    return raw.reshape((width,height,channels),order='F').transpose(1,0,2)


def audit(attempt,out=None,expected=576):
    start=time.monotonic();dense=attempt/'dense';metadata=json.loads((attempt/'report.json').read_text(encoding='utf-8'))
    names=[line.strip() for line in (dense/'stereo/fusion.cfg').read_text().splitlines() if line.strip() and not line.startswith('#')]
    assert len(names)==expected and len(set(names))==expected
    assert metadata['registered_images']==expected and metadata['input_unchanged']
    assert any(s['name']=='stereo' and s['status']=='completed' for s in metadata['stages'])
    rows=[];positive=0;total=0;negative=0
    for name in names:
        row={'name':name}
        for folder,channels in [('depth_maps',1),('normal_maps',3)]:
            path=dense/'stereo'/folder/(name+'.geometric.bin');values=map_view(path)
            assert values.shape[2]==channels and np.isfinite(values).all()
            if channels==1:
                # Native fusion.cc rejects depth<=0. Preserve anomalous values
                # and count them; never turn them into supported geometry.
                bad=values[values<0];negative+=len(bad)
                row['negative_depth_count']=len(bad)
                row['negative_depth_range']=[float(bad.min()),float(bad.max())] if len(bad) else None
                count=int((values>0).sum());positive+=count;total+=values.size
                row['positive_depth_fraction']=count/values.size;row['shape']=list(values.shape[:2])
            row[folder]={'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'finite':True}
            del values
        rows.append(row)
    report={'status':'completed','created':datetime.now().astimezone().isoformat(),'attempt':str(attempt),
            'expected_and_actual_images':expected,'map_files':len(rows)*2,'maps':rows,'reference_access':False,
            'positive_depth_fraction':positive/total,'all_records_finite':True,'all_depth_nonnegative':negative==0,
            'negative_depth_count':negative,'depth_records':total,
            'invalid_depth_policy':'Preserve source maps; native fusion filters depth<=0; checking requires four positive finite samples. Negative values are anomalies, not geometry.',
            'protocol_amendment':'Original all-nonnegative assertion failed and its queue/log remain preserved. Integrity readback now reports invalid values explicitly without accepting them as support.',
            'native_filter_source':'https://github.com/colmap/colmap/blob/3.13.0/src/colmap/mvs/fusion.cc#L378-L381',
            'scope':'Native depth/normal integrity and support only; not physical accuracy',
            'source_metadata_note':'This launch used deregister_image: the original selected_image_indices metadata lists retained unregistered entries; fusion.cfg and registered_images are the actual output domain',
            'seconds':time.monotonic()-start}
    target=out or attempt/'depth_maps_readback.json';target.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='maps'}));return report


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('attempt',type=Path);p.add_argument('--expected',type=int,default=576)
    a=p.parse_args();audit(a.attempt.resolve(),expected=a.expected)
