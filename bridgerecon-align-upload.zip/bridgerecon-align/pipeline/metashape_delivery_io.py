"""Access verified incoming ZIP members; keep a single disposable EXR file."""
from pathlib import Path
import hashlib,io,json,sys,zipfile
import numpy as np
import xml.etree.ElementTree as ET

BASE=Path(__file__).resolve().parent;ROOT=BASE.parent
RECEIPT=BASE/'runs/metashape_receipt_20261021_192243'
sys.path.insert(0,str(BASE/'vendor/openexr-python'))
import OpenEXR


class Delivery:
    def __init__(self):
        rows=json.loads((RECEIPT/'archive_members.json').read_text(encoding='utf-8'))
        self.index={r['relative_path']:r for r in rows}
        self.handles={name:zipfile.ZipFile(ROOT/name) for name in sorted({r['archive'] for r in rows})}
        self.metadata=RECEIPT/'metadata'
        tree=ET.parse(self.metadata/'chunk_000/cameras.xml').getroot()
        self.calibrations={}
        for sensor in tree.findall('chunk/sensors/sensor'):
            cal=sensor.find('calibration');resolution=cal.find('resolution')
            c={k:float(v) for k,v in resolution.attrib.items()}
            c.update({item.tag:float(item.text) for item in cal if item.tag!='resolution'})
            self.calibrations[int(sensor.attrib['id'])]=c
        self.cameras={}
        for camera in tree.find('chunk/cameras').iter('camera'):
            text=camera.findtext('transform')
            if text:self.cameras[int(camera.attrib['id'])]={'C':np.fromstring(text,sep=' ').reshape(4,4),'calibration':self.calibrations[int(camera.attrib['sensor_id'])]}
        self.depth_calibrations={}
        for row in json.loads((self.metadata/'chunk_000/depth/pyramid_calibrations.json').read_text(encoding='utf-8')):
            self.depth_calibrations[row['camera_id']]={level['level']:level['calibration'] for level in row['levels']}

    def raw(self,relative):
        row=self.index[relative]
        data=self.handles[row['archive']].read('metashape_delivery/'+relative)
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
        return data

    def npz(self,relative):
        with np.load(io.BytesIO(self.raw(relative))) as f:return {k:f[k] for k in f.files}

    def depth(self,camera,level,temporary):
        relative=f'chunk_000/depth/native_level{level}/camera_{camera:06d}.exr'
        data=self.raw(relative);temporary.write_bytes(data)
        try:
            with OpenEXR.File(temporary.relative_to(ROOT).as_posix(),separate_channels=True) as f:
                assert len(f.parts)==1 and set(f.channels())=={'Z'}
                assert np.array_equal(f.header()['dataWindow'][0],[0,0])
                a=f.channels()['Z'].pixels
                c=self.depth_calibrations[camera][level]
                assert a.shape==(c['height'],c['width']) and a.dtype==np.float32
                return a
        finally:
            # One exact self-created file; no recursive deletion.
            assert temporary.resolve().is_relative_to(BASE/'runs')
            temporary.unlink()

    def mask(self,camera,level):
        import cv2
        folder='valid_masks' if level==0 else f'valid_masks_level{level}'
        data=self.raw(f'chunk_000/depth/{folder}/camera_{camera:06d}.png')
        return cv2.imdecode(np.frombuffer(data,dtype=np.uint8),cv2.IMREAD_GRAYSCALE)

    def close(self):
        for z in self.handles.values():z.close()
