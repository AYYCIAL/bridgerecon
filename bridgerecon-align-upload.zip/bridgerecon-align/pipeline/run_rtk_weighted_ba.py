"""Shared-camera pose-prior BA with the RTK positions weighted near their recorded precision.

Same inputs, split, loss and outputs as run_navigation_prior_ba.py (left unchanged), except:
* horizontal and vertical prior standard deviations are free parameters (RTK scale);
* the RANSAC threshold of the prior alignment is fixed (default 30 m, as in the C5 run)
  instead of 3*sigma, so that a centimetre sigma does not reject the initial alignment;
* the report records the RTK basis of the priors.
"""
from pathlib import Path
from datetime import datetime
import argparse, json, os, subprocess, sys, time, uuid
import numpy as np
from run_navigation_prior_ba import BASE, SOURCE, PREP, read, sha, write, nav_check, stats
from geometry_core import camera_centers
from similarity import fit_similarity
from global_hybrid_geometry import project_native
from probe_cached_side_pnp import nominal_positions
from budget_run import OwnedJob
from work_schedule import require_start_window


def worker(out, sigma_h, sigma_v, ransac_max_error, iterations, solver_seconds, dry_run=False, resume=None, fixed_focal=None):
    import pycolmap
    started = time.monotonic(); os.chdir(SOURCE)
    preparation = read(PREP / 'report.json'); assert preparation['status'] == 'completed'
    if resume:
        previous = read(resume / 'report.json'); assert previous['status'] == 'completed' and previous.get('rtk_weighted')
        assert previous['navigation_standard_deviation_assumption_metres'] == sigma_h and previous['height_standard_deviation_assumption_metres'] == sigma_v
        assert previous.get('fixed_focal_px') == fixed_focal
    initial_model = resume / 'sparse' if resume else PREP / 'fitted_sparse'
    model = pycolmap.Reconstruction(initial_model.relative_to(SOURCE).as_posix())
    metadata = read(SOURCE / 'report.json'); names = {v['name']: v['index'] for v in metadata['images']}; inventory = read(BASE / 'data_audit/images.json')
    images = sorted(model.images.values(), key=lambda im: names[im.name]); indices = np.array([names[im.name] for im in images]); image_ids = np.array([im.image_id for im in images])
    lens = read(BASE / 'data_audit/image_lens_metadata_20261019.json')
    assert lens['shared_header_lens_hypothesis_supported'] and lens['classes'][0]['digital_zoom'] == 1. and lens['classes'][0]['focal35_mm'] == 24.
    for image in images:
        if image.camera_id != 1:
            image.reset_camera_ptr(); image.camera_id = 1; image.camera = model.cameras[1]
    assert all(image.has_camera_ptr() and image.camera_id == 1 for image in images)
    if fixed_focal and not resume:
        camera = model.cameras[1]; assert camera.model.name == 'SIMPLE_RADIAL'
        camera.params = np.array([fixed_focal, camera.width / 2., camera.height / 2., 0.])  # nominal focal; radial re-estimated
    positions = nominal_positions(inventory)[indices]; held = np.array([nav_check(int(i)) for i in indices]); centers = np.array([im.projection_center() for im in images])
    initial = fit_similarity(centers[~held], positions[~held])
    model.transform(pycolmap.Sim3d(initial[0], pycolmap.Rotation3d(initial[1]), initial[2]))
    initial_centers = np.array([model.images[int(i)].projection_center() for i in image_ids])
    np.savez_compressed(out / 'navigation_split.npz', image_ids=image_ids, image_indices=indices, checking=held, nominal_positions=positions)
    report = {'status': 'prepared', 'created': datetime.now().astimezone().isoformat(), 'reference_access': False, 'gpu_used': False,
              'source_preparation': str(PREP), 'source_preparation_sha256': sha(PREP / 'report.json'),
              'source_model_sha256': {n: sha(initial_model / n) for n in ['cameras.bin', 'images.bin', 'points3D.bin']},
              'initial_model': str(initial_model), 'continuation_source': str(resume) if resume else None,
              'maximum_additional_iterations': iterations, 'maximum_solver_seconds': solver_seconds,
              'navigation_standard_deviation_assumption_metres': sigma_h, 'height_standard_deviation_assumption_metres': sigma_v,
              'navigation_precision_known': True, 'rtk_weighted': True,
              'prior_basis': 'RTK-fixed positions (receiver-reported sigma about 0.8 cm horizontal, 2.1 cm vertical); lever arm and timing not modelled',
              'ransac_max_error_metres': ransac_max_error, 'shared_physical_camera_hypothesis': True, 'prior_position_loss': 'quadratic',
              'used_camera_ids': sorted({im.camera_id for im in images}), 'fixed_focal_px': fixed_focal,
              'calibration': (f'Fixed nominal focal {fixed_focal} px (24-mm equivalent, diagonal convention); free radial; fixed principal point'
                              if fixed_focal else 'Free shared focal/radial, fixed principal point'),
              'training_navigation_cameras': int((~held).sum()), 'withheld_navigation_cameras': int(held.sum()),
              'scope': 'RTK-weighted camera control; withheld positions are not in the prior; image observations of all cameras are fitted',
              'initial_train_navigation_error': stats(np.linalg.norm(initial_centers[~held] - positions[~held], axis=1)),
              'initial_withheld_navigation_error': stats(np.linalg.norm(initial_centers[held] - positions[held], axis=1))}
    write(out / 'report.json', report)
    config = pycolmap.BundleAdjustmentConfig()
    for image_id in image_ids: config.add_image(int(image_id))
    covariance = np.diag([sigma_h * sigma_h, sigma_h * sigma_h, sigma_v * sigma_v])
    priors = {int(i): pycolmap.PosePrior(p, covariance, pycolmap.PosePriorCoordinateSystem.CARTESIAN) for i, p, c in zip(image_ids, positions, held) if not c}
    options = pycolmap.BundleAdjustmentOptions(); options.use_gpu = False; options.refine_focal_length = not fixed_focal; options.refine_extra_params = True; options.refine_principal_point = False
    options.solver_options.max_num_iterations = iterations; options.solver_options.max_solver_time_in_seconds = solver_seconds; options.solver_options.num_threads = 4
    options.solver_options.function_tolerance = 1e-6; options.solver_options.gradient_tolerance = 1e-4; options.solver_options.parameter_tolerance = 1e-7
    prior_options = pycolmap.PosePriorBundleAdjustmentOptions(); prior_options.use_robust_loss_on_prior_position = False; prior_options.ransac_max_error = ransac_max_error
    report.update(status='dry_run_ready' if dry_run else 'optimizing', ba_options=str(options), prior_options=str(prior_options), priors=len(priors))
    write(out / 'report.json', report)
    if dry_run:
        print('DRY RUN OK', json.dumps({'images': len(images), 'priors': len(priors), 'points': len(model.points3D), 'initial_withheld': report['initial_withheld_navigation_error']}), flush=True)
        return
    adjuster = pycolmap.create_pose_prior_bundle_adjuster(options, prior_options, config, priors, model)
    summary = adjuster.solve()
    report['solver'] = {'brief': summary.BriefReport(), 'message': summary.message, 'termination': str(summary.termination_type),
                        'solution_usable': summary.IsSolutionUsable(), 'initial_cost': summary.initial_cost, 'final_cost': summary.final_cost,
                        'successful_steps': summary.num_successful_steps, 'unsuccessful_steps': summary.num_unsuccessful_steps, 'solver_seconds': summary.total_time_in_seconds}
    assert summary.IsSolutionUsable(), 'Unusable native pose-prior result'
    images = [model.images[int(i)] for i in image_ids]; E = np.array([im.cam_from_world.matrix() for im in images]); centers = camera_centers(E)
    report['native_frame_navigation_error'] = stats(np.linalg.norm(centers - positions, axis=1))
    final = fit_similarity(centers[~held], positions[~held]); model.transform(pycolmap.Sim3d(final[0], pycolmap.Rotation3d(final[1]), final[2]))
    images = [model.images[int(i)] for i in image_ids]; E = np.array([im.cam_from_world.matrix() for im in images]); centers = camera_centers(E)
    report['train_navigation_error'] = stats(np.linalg.norm(centers[~held] - positions[~held], axis=1)); report['withheld_navigation_error'] = stats(np.linalg.norm(centers[held] - positions[held], axis=1))
    cameras = {str(cid): {'model': c.model.name, 'width': c.width, 'height': c.height, 'params': c.params.tolist()} for cid, c in model.cameras.items()}
    errors = []; positive = 0; total = 0
    for image, e in zip(images, E):
        obs = [p for p in image.points2D if p.has_point3D()]
        xyz = np.array([model.points3D[p.point3D_id].xyz for p in obs]); uv = np.array([p.xy for p in obs])
        projected, z = project_native(xyz, e, cameras[str(image.camera_id)], np.eye(3))
        errors.extend(np.linalg.norm(projected - uv, axis=1)); positive += int((z > 0).sum()); total += len(z)
    report.update(training_reprojection_pixels=stats(np.array(errors)), training_positive_depth_fraction=positive / total, native_cameras=cameras,
                  stored_coordinate_units='RTK-referenced local metres (equirectangular east, north, height)')
    destination = out / 'sparse'; destination.mkdir(); model.write(destination.relative_to(SOURCE).as_posix())
    np.savez_compressed(out / 'cameras.npz', extrinsics=E, image_indices=indices, image_ids=image_ids, nominal_positions=positions, centers=centers, navigation_checking=held)
    with np.load(PREP / 'split.npz') as split:
        assert set(model.points3D) == set(map(int, split['selected_training_ids'])) and not set(model.points3D).intersection(map(int, split['checking_ids']))
    report.update(status='completed', source_unchanged=all(sha(initial_model / n) == h for n, h in report['source_model_sha256'].items()),
                  output_sha256={n: sha(destination / n) for n in report['source_model_sha256']}, seconds=time.monotonic() - started)
    assert report['source_unchanged']; write(out / 'report.json', report); print('REPORT', out, flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--sigma-h', type=float, required=True); p.add_argument('--sigma-v', type=float, required=True)
    p.add_argument('--ransac-max-error', type=float, default=30.); p.add_argument('--iterations', type=int, default=400); p.add_argument('--solver-seconds', type=float, default=1500.)
    p.add_argument('--worker', action='store_true'); p.add_argument('--dry-run', action='store_true'); p.add_argument('--out', type=Path); p.add_argument('--resume', type=Path)
    p.add_argument('--fixed-focal', type=float, help='Fix the shared focal length (pixels at 1600x1200), e.g. the nominal 24-mm-equivalent value'); args = p.parse_args()
    assert 0.005 <= args.sigma_h <= 1 and 0.005 <= args.sigma_v <= 1 and 1 <= args.iterations <= 1000 and 1 <= args.solver_seconds <= 1800
    assert args.fixed_focal is None or 900 <= args.fixed_focal <= 1500
    if args.worker or args.dry_run:
        out = args.out.resolve(); out.mkdir(parents=True, exist_ok=True)
        try: worker(out, args.sigma_h, args.sigma_v, args.ransac_max_error, args.iterations, args.solver_seconds, args.dry_run, args.resume.resolve() if args.resume else None, args.fixed_focal)
        except Exception as exc:
            path = out / 'report.json'; r = read(path) if path.exists() else {}; r.update(status='failed', error=repr(exc)); write(path, r); raise
        return
    require_start_window(args.solver_seconds + 360)
    prefix = 'rtkf_' if args.fixed_focal else 'rtk_'
    out = SOURCE / 'navigation_prior_controls' / (prefix + datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:8]); out.mkdir(parents=True)
    (out / 'driver_source.py').write_bytes(Path(__file__).read_bytes())
    env = os.environ.copy(); env.update(CUDA_VISIBLE_DEVICES='-1', OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4', PYTHONIOENCODING='utf-8')
    command = [sys.executable, '-u', str(Path(__file__).resolve()), '--worker', '--out', str(out), '--sigma-h', str(args.sigma_h), '--sigma-v', str(args.sigma_v),
               '--ransac-max-error', str(args.ransac_max_error), '--iterations', str(args.iterations), '--solver-seconds', str(args.solver_seconds)]
    if args.resume: command += ['--resume', str(args.resume.resolve())]
    if args.fixed_focal: command += ['--fixed-focal', str(args.fixed_focal)]
    with (out / 'worker.log').open('w', encoding='utf-8') as log:
        child = subprocess.Popen(command, cwd=BASE.parent, env=env, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW); owned = OwnedJob(child)
        try: code = child.wait(timeout=args.solver_seconds + 300)
        except subprocess.TimeoutExpired: owned.terminate(); child.wait(timeout=15); raise
        finally: owned.close()
    print('REPORT', out)
    if code: print((out / 'worker.log').read_text(encoding='utf-8', errors='replace')[-3500:]); raise SystemExit(code)


if __name__ == '__main__':
    main()
