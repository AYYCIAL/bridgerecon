"""Bounded, checkpointed SfM-anchored VGGT controls with global track IDs."""
from pathlib import Path
from datetime import datetime
import argparse,hashlib,json,os,shutil,subprocess,sys,time,uuid
import numpy as np
from global_hybrid_geometry import VARIANTS,camera_alignment,fit_depth_scales,unproject_native,project_native
from route_chunk_geometry import transform_extrinsics,serialize
from similarity import apply_similarity
from local_validation import sample,inside,unproject,project_world,statistics
from budget_run import OwnedJob
from work_schedule import require_start_window

BASE=Path(__file__).resolve().parent
DTYPE=np.dtype([('x','<f4'),('y','<f4'),('z','<f4'),('red','u1'),('green','u1'),('blue','u1')])


def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,r):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(p)


def worker(preparation,sources,starts,out):
    tic=time.monotonic();prep=read(preparation/'report.json');assert prep['status']=='completed' and prep['source_unchanged']
    cameras=read(preparation/'native_cameras.json');available={}
    settings=None
    for source in sources:
        r=read(source/'report.json');assert r['status']=='completed'
        if settings is None:settings=r['settings']
        else:assert settings==r['settings']
        for c in r['chunks']:
            if c['status']=='completed':available[c['start']]={'path':source/c['prediction'],'sha256':c['sha256'],'indices':c['image_indices']}
    selected=sorted(starts or available)
    assert all(s in available for s in selected)
    unit_label='nominal navigation m' if 'Navigation metres' in prep.get('stored_coordinate_units','') else 'arbitrary SfM units'
    report={'status':'fitting','created':datetime.now().astimezone().isoformat(),'preparation':str(preparation),
            'preparation_sha256':sha(preparation/'report.json'),'sources':[str(s) for s in sources],'starts':selected,
            'variants':VARIANTS,'chunks':[],'reference_access':False,'gpu_used':False,
            'scope':'SfM-anchored hybrid; source SfM initialization reused checking tracks; not independent physical accuracy',
            'checking_fit_exclusion':'Global IDs absent from new camera refit and depth fitting; original all-track initialization retained',
            'photo_ownership':'Earliest selected chunk start; not selected by errors','maximum_pairs_per_track':24,
            'exports':'Image-grid stride4 multi-view samples; surface duplicates possible; no unique-surface fusion',
            'coordinate_display_units':unit_label}
    write(out/'report.json',report);anchor_records={v['index']:v for v in prep['views']}
    ownership={}
    # Fit every declared output before reading any checking depths or residuals.
    for start in selected:
        require_start_window(90);item=available[start];assert sha(item['path'])==item['sha256']
        data=dict(np.load(item['path']));anchors=[]
        for index in item['indices']:
            record=anchor_records[index];path=preparation/record['file'];assert sha(path)==record['sha256']
            with np.load(path) as a:
                anchors.append({k:a[k] for k in ['train_uv','train_z','train_eligible','extrinsics']})
        E=np.array([a['extrinsics'] for a in anchors]);model,alignment=camera_alignment(data['extrinsics'],E)
        fit=fit_depth_scales(data,anchors,model[0])
        row={'start':start,'input':str(item['path']),'input_sha256':item['sha256'],'image_indices':item['indices'],
             'similarity':serialize(model),'alignment':alignment,'depth_fit':fit}
        report['chunks'].append(row)
        for slot,index in enumerate(item['indices']):ownership.setdefault(index,{'start':start,'slot':slot})
        write(out/'report.json',report)
        print('FIT',start,'anchors',fit['pooled_training_observations'],'supported',fit['chunk_supported'],flush=True)
    fixed={'chunks':report['chunks'],'ownership':ownership,'preparation_sha256':report['preparation_sha256'],'variants':VARIANTS}
    write(out/'frozen_parameters.json',fixed)
    report.update(status='fixed_before_checking',frozen_parameters_sha256=sha(out/'frozen_parameters.json'),
                  all_chunks_supported=all(c['depth_fit']['chunk_supported'] for c in report['chunks']),
                  unique_photos=len(ownership),actual_view_scale_acceptances=sum(v['view_specific_accepted'] for c in report['chunks'] for v in c['depth_fit']['views']),
                  total_view_scale_candidates=sum(len(c['depth_fit']['views']) for c in report['chunks']))
    write(out/'report.json',report)
    if not report['all_chunks_supported']:
        report.update(status='unsupported_training_anchors',seconds=time.monotonic()-tic);write(out/'report.json',report);return
    streams=[];counts=np.zeros(4,dtype=np.int64);preview=[[] for _ in VARIANTS];observations=[];view_models={}
    for variant in VARIANTS:
        folder=out/variant;folder.mkdir();streams.append((folder/'points.bin').open('wb'))
    try:
        for row in report['chunks']:
            require_start_window(90)
            data=dict(np.load(row['input']));m=row['similarity'];model=(m['scale'],np.array(m['rotation']),np.array(m['translation']))
            raw_E=transform_extrinsics(data['extrinsics'],model);fit=row['depth_fit'];h,w=data['depth'].shape[1:3]
            yy,xx=np.mgrid[2:h-2:4,2:w-2:4];grid=np.c_[xx.ravel(),yy.ravel()]
            for slot,index in enumerate(row['image_indices']):
                if ownership[index]['start']!=row['start']:continue
                a=dict(np.load(preparation/anchor_records[index]['file']));E=a['extrinsics'];A=a['native_to_input'];camera=cameras[str(int(a['camera_id']))]
                q=np.array([1.,1.,fit['chunk_scale'],fit['views'][slot]['applied_scale']])
                view_models[index]={'global_E':E,'A':A,'camera':camera,'raw_E':raw_E[slot],'raw_K':data['intrinsics'][slot]}
                # Keep the complete input-inside inventory independent of model confidence.
                uv=a['checking_uv'];use=inside(uv);uv=uv[use];refz=a['checking_z'][use];ids=a['checking_ids'][use]
                d=sample(data['depth'][slot,...,0],uv);conf=sample(data['depth_conf'][slot],uv)
                xyz=np.empty((len(uv),4,3))
                xyz[:,0]=apply_similarity(unproject(uv,d,data['extrinsics'][slot],data['intrinsics'][slot]),model)
                for k in range(1,4):xyz[:,k]=unproject_native(uv,m['scale']*q[k]*d,E,camera,A)
                zglobal=np.stack([(xyz[:,k]@E[:,:3].T+E[:,3])[:,2] for k in range(4)],axis=1)
                valid=(conf[:,None]>=1.2)&np.isfinite(xyz).all(axis=2)&(zglobal>0)&np.isfinite(refz[:,None])&(refz[:,None]>0)
                observations.append({'ids':ids,'view':np.full(len(ids),index),'uv':uv,'reference_z':refz,'predicted_z':zglobal,'xyz':xyz,'valid':valid})
                # Export all confidence-qualified grid samples, without using checking reference depths.
                depths=data['depth'][slot,yy,xx,0].ravel();c=data['depth_conf'][slot,yy,xx].ravel();use=(c>=1.2)&(depths>0)&np.isfinite(depths)
                colors=data['rgb'][slot,yy,xx].reshape(-1,3)[use]
                for k in range(4):
                    if k==0:points=apply_similarity(unproject(grid[use],depths[use],data['extrinsics'][slot],data['intrinsics'][slot]),model)
                    else:points=unproject_native(grid[use],m['scale']*q[k]*depths[use],E,camera,A)
                    assert np.isfinite(points).all()
                    packed=np.empty(len(points),dtype=DTYPE)
                    for j,key in enumerate(('x','y','z')):packed[key]=points[:,j]
                    for j,key in enumerate(('red','green','blue')):packed[key]=colors[:,j]
                    streams[k].write(packed.tobytes());counts[k]+=len(points)
                    if len(points):preview[k].append((points[::max(1,len(points)//50)],colors[::max(1,len(points)//50)]))
                    if len(points)>3:
                        if k==0:pixel,z=project_world(points[:3],raw_E[slot],data['intrinsics'][slot])
                        else:pixel,z=project_native(points[:3],E,camera,A)
                        assert np.max(abs(pixel-grid[use][:3]))<1e-3
                        assert (z>0).all()
            print('SAMPLED',row['start'],flush=True)
    finally:
        for stream in streams:stream.close()
    all_obs={key:np.concatenate([o[key] for o in observations]) for key in observations[0]};del observations
    np.savez_compressed(out/'checking_samples.npz',**all_obs)
    # Stable per-track directed pair sampling; all input-inside observations stay in denominator.
    groups={}
    for n,pid in enumerate(all_obs['ids']):groups.setdefault(int(pid),[]).append(n)
    source_ids=[];target_ids=[];possible=0;pair_tracks=0
    for pid,obs in sorted(groups.items()):
        obs=sorted(obs,key=lambda i:int(all_obs['view'][i]));n=len(obs)
        if n<2:continue
        possible+=n*(n-1);pair_tracks+=1
        flat=np.linspace(0,n*(n-1)-1,min(24,n*(n-1)),dtype=int)
        for f in flat:
            i=int(f//(n-1));j=int(f%(n-1));j+=int(j>=i)
            source_ids.append(obs[i]);target_ids.append(obs[j])
    si=np.array(source_ids,dtype=int);ti=np.array(target_ids,dtype=int);errors=np.full((len(si),4),np.nan);supported=np.zeros_like(errors,dtype=bool)
    for view,vm in view_models.items():
        selected=np.where(all_obs['view'][ti]==view)[0]
        for k in range(4):
            xyz=all_obs['xyz'][si[selected],k]
            if k==0:pixel,z=project_world(xyz,vm['raw_E'],vm['raw_K'])
            else:pixel,z=project_native(xyz,vm['global_E'],vm['camera'],vm['A'])
            good=all_obs['valid'][si[selected],k]&all_obs['valid'][ti[selected],k]&(z>0)&np.isfinite(pixel).all(axis=1)&inside(pixel)
            error=np.linalg.norm(pixel-all_obs['uv'][ti[selected]],axis=1)
            errors[selected[good],k]=error[good];supported[selected[good],k]=True
    np.savez_compressed(out/'checking_pairs.npz',source=si,target=ti,errors=errors,supported=supported)
    metrics={};exports=[]
    for k,variant in enumerate(VARIANTS):
        relative=abs(all_obs['predicted_z'][:,k]-all_obs['reference_z'])/all_obs['reference_z']
        relative[~all_obs['valid'][:,k]]=np.nan
        metrics[variant]={'checking_observations':len(relative),'supported_observation_fraction':float(all_obs['valid'][:,k].mean()),
                          'depth_relative_abs_error':statistics(relative),'checking_pairs':len(si),'checking_tracks_with_pairs':pair_tracks,
                          'possible_directed_pairs_before_cap':possible,'supported_pair_fraction':float(supported[:,k].mean()) if len(si) else 0.,
                          'reprojection_pixels':statistics(errors[:,k]),'fixed_inventory_success_below2px':float(np.sum(errors[:,k]<2)/len(si)) if len(si) else 0.}
        folder=out/variant;buffer=folder/'points.bin';count=int(counts[k])
        header=('ply\nformat binary_little_endian 1.0\nelement vertex '+str(count)+
                '\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n').encode()
        ply=folder/'samples.ply'
        with ply.open('wb') as f,buffer.open('rb') as incoming:f.write(header);shutil.copyfileobj(incoming,f,1024*1024)
        assert ply.stat().st_size==len(header)+count*DTYPE.itemsize
        values=np.memmap(ply,mode='r',dtype=DTYPE,offset=len(header),shape=(count,))
        for begin in range(0,count,500000):assert all(np.isfinite(values[begin:begin+500000][key]).all() for key in ['x','y','z'])
        del values
        exports.append({'variant':variant,'ply':str(ply.relative_to(out)),'sample_records':count,'sha256':sha(ply),'finite_readback':True})
    report.update(status='plotting',metrics=metrics,exports=exports);write(out/'report.json',report)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(2,2,figsize=(13,9),layout='constrained')
    # Same projection basis/range across controls, computed from the fixed raw control.
    raw_points=np.concatenate([p[0] for p in preview[0]]);origin=np.median(raw_points,axis=0)
    _,_,vt=np.linalg.svd(raw_points-origin,full_matrices=False);bounds=np.percentile((raw_points-origin)@vt[:2].T,[1,99],axis=0);margin=(bounds[1]-bounds[0])*.1
    for k,ax in enumerate(axes.ravel()):
        points=np.concatenate([p[0] for p in preview[k]]);rgb=np.concatenate([p[1] for p in preview[k]])
        uv=(points-origin)@vt[:2].T;ax.scatter(uv[:,0],uv[:,1],s=1,c=rgb/255,rasterized=True)
        ax.set(xlim=(bounds[0,0]-margin[0],bounds[1,0]+margin[0]),ylim=(bounds[0,1]-margin[1],bounds[1,1]+margin[1]),
               title=VARIANTS[k].replace('_',' '),xlabel='Common PCA1, '+unit_label,ylabel='Common PCA2, '+unit_label);ax.set_aspect('equal')
    fig.suptitle('SfM-anchored VGGT controls: same sampling; no measured-cloud alignment',fontsize=12)
    fig.savefig(out/'hybrid_preview.png',dpi=170);fig.savefig(out/'hybrid_preview.pdf');plt.close(fig)
    assert sha(out/'frozen_parameters.json')==report['frozen_parameters_sha256']
    assert sha(preparation/'report.json')==report['preparation_sha256']
    report.update(status='completed',parameters_unchanged_after_checking=True,preparation_unchanged=True,
                  source_predictions_unchanged=all(sha(Path(c['input']))==c['input_sha256'] for c in report['chunks']),seconds=time.monotonic()-tic)
    assert report['source_predictions_unchanged'];write(out/'report.json',report);print('REPORT',out,flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--preparation',type=Path,required=True);p.add_argument('--source',type=Path,nargs='+',required=True)
    p.add_argument('--starts',type=int,nargs='+');p.add_argument('--worker',action='store_true');p.add_argument('--out',type=Path);args=p.parse_args()
    if args.worker:
        try:worker(args.preparation.resolve(),[s.resolve() for s in args.source],args.starts,args.out.resolve())
        except Exception as exc:
            path=args.out/'report.json';r=read(path) if path.exists() else {};r.update(status='failed',error=repr(exc));write(path,r);raise
        return
    require_start_window(1500)
    out=BASE/'runs'/('global_hybrid_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir()
    for name in ['run_global_hybrid.py','global_hybrid_geometry.py']:(out/name).write_bytes((BASE/name).read_bytes())
    env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='-1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',PYTHONIOENCODING='utf-8')
    command=[sys.executable,'-u',str(Path(__file__).resolve()),'--worker','--out',str(out),'--preparation',str(args.preparation),'--source']+[str(s) for s in args.source]
    if args.starts:command+=['--starts']+list(map(str,args.starts))
    with (out/'worker.log').open('w',encoding='utf-8') as log:
        child=subprocess.Popen(command,cwd=BASE.parent,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW);owned=OwnedJob(child)
        try:code=child.wait(timeout=1440)
        except subprocess.TimeoutExpired:owned.terminate();child.wait(timeout=15);raise
        finally:owned.close()
    print('REPORT',out)
    if code:print((out/'worker.log').read_text(encoding='utf-8',errors='replace')[-3500:]);raise SystemExit(code)


if __name__=='__main__':main()
