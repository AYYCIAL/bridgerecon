"""Run the frozen native-MVS held-out evaluation on another dense attempt (e.g. 518-px full route).

evaluate_native_mvs_checking.py fixes its attempt path at module level; this wrapper only
substitutes that path and calls its unchanged main(). The frozen report hard-codes a 1600-px
resolution note, so the wrapper afterwards records the attempt's actual settings beside it.
"""
from pathlib import Path
import json, sys
import evaluate_native_mvs_checking as frozen

if __name__ == '__main__':
    attempt = Path(sys.argv[1]).resolve(); assert (attempt / 'report.json').exists() and (attempt / 'depth_maps_readback.json').exists()
    frozen.ATTEMPT = attempt
    frozen.main()
    runs = sorted(frozen.BASE.glob('runs/native_mvs_checking_*/report.json'))
    path = next(p for p in reversed(runs) if json.loads(p.read_text(encoding='utf-8')).get('attempt') == str(attempt))
    report = json.loads(path.read_text(encoding='utf-8')); settings = json.loads((attempt / 'report.json').read_text(encoding='utf-8'))['settings']
    report['frozen_resolution_note'] = report.pop('resolution')
    report['resolution'] = f"Native MVS maximum {settings['width']} px; VGGT 518x392 (note above is the frozen evaluator's fixed text)"
    report['attempt_settings'] = settings
    path.write_text(json.dumps(report, indent=2), encoding='utf-8'); print('REPORT', path.parent, flush=True)
