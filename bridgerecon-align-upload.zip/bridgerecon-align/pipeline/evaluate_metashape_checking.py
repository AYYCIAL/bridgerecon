"""Frozen-endpoint commercial comparison with declared pyramid fallback."""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import argparse,csv,hashlib,json,os,subprocess,sys,time
import numpy as np
from budget_run import OwnedJob
from work_schedule import require_start_window
from metashape_delivery_io import Delivery,BASE,ROOT,RECEIPT
from metashape_geometry import rays,project_camera,world_from_camera,camera_from_world,eval_to_original,original_to_eval
from evaluate_native_mvs_checking import sample_positive
from local_validation import inside,statistics

HYBRID=BASE/'runs/global_hybrid_20261019_205203_28fc26c6'
NATIVE=BASE/'runs/native_mvs_checking_20261020_001654_cd47ff08'
ENVELOPE=BASE/'runs/full_hybrid_summary_20261019_210510_6aff3186/frozen_envelopes.npz'
ADAPTER=BASE/'runs/metashape_adapter_20261021_195610'
VARIANTS=['metashape_pyramid','metashape_level0','metashape_array_offset0_sensitivity']


def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,r):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(p)


def worker(out):
    start=time.monotonic();assert read(ADAPTER/'report.json')['status']=='passed'
    protocol={'created':datetime.now(timezone(timedelta(hours=9))).isoformat(),
              'paper_protocol_sha256':(sha(ROOT/'paper/metashape_protocol.md') if (ROOT/'paper/metashape_protocol.md').exists() else None),
              'adapter_report_sha256':sha(ADAPTER/'report.json'),
              'primary':'metashape_pyramid','level_priority':[0,1,2],
              'level_selection':'First four-positive-finite bilinear result; no outcome-based selection, hole fill, or cross-view interpolation',
              'depth_array_origin_offset':-.5,'secondary_level0_only':True,'secondary_array_offset0':True,
              'full_observations':477683,'full_directed_pairs':691694,'full_main_route_images':576,
              'checking_pixel_domain':[518,392],'success_threshold_pixels':2.,
              'missing_photo_local_index':386,'reference_access':False,
              'input_resolution':'8064x6048; different from1600COLMAP and518x392VGGT',
              'comparison_scope':'Six methods common support and unchanged complete inventory; later single-bridge development, unequal native fitting access/camera models/resolution/hardware'}
    write(out/'protocol.json',protocol)
    protocol_hash=sha(out/'protocol.json')
    report={'status':'decoding_depth','protocol_sha256':protocol_hash,'processed_views':0,'variants':VARIANTS,
            'reference_access':False,'gpu_used':False,'views':[]}
    write(out/'report.json',report)
    d=Delivery()
    try:
        hybrid=read(HYBRID/'report.json');prep=Path(hybrid['preparation']);prep_report=read(prep/'report.json')
        records={r['index']:r for r in prep_report['views']};cameras=read(prep/'native_cameras.json')
        mapping={int(row['local_index']):row for row in csv.DictReader((RECEIPT/'photo_mapping.csv').open(encoding='utf-8',newline=''))}
        with np.load(HYBRID/'checking_samples.npz') as f:
            ids=f['ids'];view=f['view'];uv=f['uv'];reference=f['reference_z'];hybrid_valid=f['valid']
        with np.load(HYBRID/'checking_pairs.npz') as f:si=f['source'];ti=f['target'];hybrid_errors=f['errors'];hybrid_support=f['supported']
        assert len(ids)==477683 and len(si)==691694
        depth=np.full((len(ids),3),np.nan);xyz=np.full((len(ids),3,3),np.nan);valid=np.zeros((len(ids),3),bool);level_used=np.full((len(ids),3),-1,np.int8)
        models={};original_uv=np.full_like(uv,np.nan);roundtrip=0.;verified_maps=0
        for index in range(576):
            if index%12==0:require_start_window(120)
            row=mapping[index];where=np.where(view==index)[0]
            if row['registered']!='True' or row['has_depth_map']!='True':
                report['views'].append({'index':index,'state':'missing_input_or_depth','checking_observations':len(where),'supported':[0,0,0]});report['processed_views']=index+1;write(out/'report.json',report);continue
            key=int(row['camera_id']);camera=d.cameras[key];c=camera['calibration'];C=camera['C']
            with np.load(prep/records[index]['file']) as f:A=f['native_to_input'];camera_id=int(f['camera_id'])
            native=cameras[str(camera_id)];native_shape=[native['width'],native['height']];original_shape=[c['width'],c['height']]
            pixels=eval_to_original(uv[where],A,native_shape,original_shape);ray=rays(pixels,c);original_uv[where]=pixels
            back,_=project_camera(ray,c)
            roundtrip=max(roundtrip,float(np.max(np.linalg.norm(original_to_eval(back,A,native_shape,original_shape)-uv[where],axis=1),initial=0)))
            assert roundtrip<1e-7
            z=np.full((len(where),3),np.nan);chosen=np.full((len(where),3),-1,np.int8)
            map_counts=[]
            for level in [0,1,2]:
                values=d.depth(key,level,out/'temporary_depth.exr');mask=d.mask(key,level)
                good_pixels=np.isfinite(values)&(values>0)
                assert np.isfinite(values).all() and np.array_equal(mask>0,good_pixels)
                map_counts.append(int(good_pixels.sum()));verified_maps+=1
                query,_=project_camera(ray,d.depth_calibrations[key][level]);primary,good=sample_positive(values,query-.5)
                select=(chosen[:,0]<0)&good;z[select,0]=primary[select];chosen[select,0]=level
                if level==0:z[good,1]=primary[good];chosen[good,1]=0
                alternate,alt_good=sample_positive(values,query)
                select=(chosen[:,2]<0)&alt_good;z[select,2]=alternate[select];chosen[select,2]=level
                del values,mask,good_pixels
            depth[where]=z;level_used[where]=chosen
            for column in range(3):
                xyz[where,column]=world_from_camera(ray*z[:,column,None],C)
                valid[where,column]=(chosen[:,column]>=0)&np.isfinite(reference[where])&(reference[where]>0)
            models[index]=(C,c,A,native_shape,original_shape)
            report['views'].append({'index':index,'camera_id':key,'state':'decoded','checking_observations':len(where),
                                    'supported':valid[where].sum(axis=0).tolist(),'native_valid_pixels_by_level':map_counts})
            report['processed_views']=index+1;report['verified_native_maps']=verified_maps;write(out/'report.json',report)
            if index%24==0:print('VIEWS',index+1,'/576','maps',verified_maps,flush=True)
        report['status']='evaluating_pairs';write(out/'report.json',report)
        errors=np.full((len(si),3),np.nan);support=np.zeros((len(si),3),bool)
        for index,(C,c,A,native_shape,original_shape) in models.items():
            selected=np.where(view[ti]==index)[0]
            for column in range(3):
                pixel,z=project_camera(camera_from_world(xyz[si[selected],column],C),c)
                pixel=original_to_eval(pixel,A,native_shape,original_shape)
                good=valid[si[selected],column]&valid[ti[selected],column]&(z>0)&np.isfinite(pixel).all(axis=1)&inside(pixel)
                residual=np.linalg.norm(pixel-uv[ti[selected]],axis=1)
                errors[selected[good],column]=residual[good];support[selected[good],column]=True
        assert not valid[view==386].any()
        np.savez_compressed(out/'checking_samples.npz',ids=ids,view=view,uv=uv,original_uv=original_uv,reference_z=reference,predicted_z_internal=depth,xyz_internal=xyz,valid=valid,level_used=level_used)
        np.savez_compressed(out/'checking_pairs.npz',source=si,target=ti,errors=errors,supported=support)
        with np.load(NATIVE/'checking_pairs.npz') as f:
            assert np.array_equal(f['source'],si) and np.array_equal(f['target'],ti);native_errors=f['errors'];native_support=f['supported']
        methods={hybrid['variants'][k]:(hybrid_errors[:,k],hybrid_support[:,k]) for k in range(4)}
        methods['native_mvs']=(native_errors,native_support);methods['metashape_pyramid']=(errors[:,0],support[:,0])
        common=np.logical_and.reduce([s for _,s in methods.values()])
        with np.load(ENVELOPE) as f:masks=f['masks'];qualified=f['qualified']
        ix=np.rint(uv[:,0]).astype(int);iy=np.rint(uv[:,1]).astype(int)
        ins=masks[view,iy,ix]&qualified[view];outs=~masks[view,iy,ix]&qualified[view];del masks
        strata={'all':np.ones(len(si),bool),'both_inside_envelope':ins[si]&ins[ti],
                'at_least_one_outside_in_qualified_view':outs[si]|outs[ti]}
        strata['unresolved']=~(strata['both_inside_envelope']|strata['at_least_one_outside_in_qualified_view'])
        rows=[];blocks=[]
        for method,(error,supported) in methods.items():
            for name,mask in strata.items():
                rows.append({'method':method,'stratum':name,'full_pairs':int(mask.sum()),'supported_pairs':int(supported[mask].sum()),
                             'support_fraction':float(supported[mask].mean()),'success_below2px_full_inventory':float((error[mask]<2).mean()),
                             'own_support_pixels':statistics(error[mask]),'common_support_pixels':statistics(error[mask&common])})
            values=[]
            for b in range(72):
                use=common&(view[si]//8==b);values.append(float(np.median(error[use])) if use.any() else None)
            blocks.append({'method':method,'median_pixels_by_correlated_source_block':values})
        sensitivity=[]
        all_meta_common=support.all(axis=1)
        for k,name in enumerate(VARIANTS):
            sensitivity.append({'method':name,'supported_pairs':int(support[:,k].sum()),
                                'support_fraction':float(support[:,k].mean()),'success_below2px_full_inventory':float((errors[:,k]<2).mean()),
                                'own_support_pixels':statistics(errors[:,k]),'common_all_three_metashape_pixels':statistics(errors[all_meta_common,k])})
        level_counts={name:{str(k):int((level_used[:,col]==k).sum()) for k in [-1,0,1,2]} for col,name in enumerate(VARIANTS)}
        report.update(status='completed',seconds=time.monotonic()-start,primary='metashape_pyramid',
                      same_fixed_inventory=True,full_observations=len(ids),full_pairs=len(si),common_pairs_six_methods=int(common.sum()),
                      rows=rows,blocks=blocks,sensitivity=sensitivity,metashape_sensitivity_common_pairs=int(all_meta_common.sum()),
                      selected_level_counts=level_counts,endpoint_roundtrip_max_eval_pixels=roundtrip,
                      envelope_sha256=sha(ENVELOPE),native_report_sha256=sha(NATIVE/'report.json'),
                      hybrid_report_sha256=sha(HYBRID/'report.json'),physical_reference_qualified_targets=0,
                      limitations=['Source SfM initialization reused checking tracks; later descriptive development',
                                   'Metashape fits original8064 images with own cameras and recorded GPS priors; unequal fitting access/resolution/hardware',
                                   'Finest-available pyramid query is declared adapter representation, not exact native dense fusion',
                                   'Missing input386 and all invalid supports retained; image envelope is not semantic structure truth',
                                   'No independent physical accuracy or cross-bridge inference'])
        assert sha(out/'protocol.json')==protocol_hash;write(out/'report.json',report)
        np.savez_compressed(out/'common_inventory.npz',source=si,target=ti,common_pairs=common)
        with (out/'comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
            fields=['method','stratum','full_pairs','supported_pairs','support_fraction','success_below2px_full_inventory','common_pairs','median_pixels','p95_pixels']
            w=csv.DictWriter(f,fields);w.writeheader()
            for row in rows:
                stat=row['common_support_pixels'];w.writerow({**{k:row[k] for k in fields if k in row},'common_pairs':stat['n'],'median_pixels':stat['median'],'p95_pixels':stat['p95']})
        print('COMPLETED',out,report['seconds'],report['common_pairs_six_methods'],flush=True)
        for row in rows:
            if row['stratum']=='all':print(row['method'],row['common_support_pixels'],row['support_fraction'],row['success_below2px_full_inventory'],flush=True)
    except Exception as exc:
        report.update(status='failed',error=repr(exc),seconds=time.monotonic()-start);write(out/'report.json',report);raise
    finally:d.close()


def main():
    p=argparse.ArgumentParser();p.add_argument('--worker',action='store_true');p.add_argument('--out',type=Path);a=p.parse_args()
    if a.worker:worker(a.out.resolve());return
    require_start_window(3900)
    out=BASE/'runs'/('metashape_checking_'+datetime.now(timezone(timedelta(hours=9))).strftime('%Y%m%d_%H%M%S'));out.mkdir()
    for name in ['evaluate_metashape_checking.py','metashape_delivery_io.py','metashape_geometry.py']:(out/name).write_bytes((BASE/name).read_bytes())
    env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='-1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',PYTHONIOENCODING='utf-8')
    with (out/'worker.log').open('w',encoding='utf-8') as log:
        child=subprocess.Popen([sys.executable,'-X','utf8','-u',str(Path(__file__).resolve()),'--worker','--out',str(out)],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW);owned=OwnedJob(child)
        try:code=child.wait(timeout=3600)
        except subprocess.TimeoutExpired:owned.terminate();child.wait(timeout=20);raise
        finally:owned.close()
    print('END',code,out,flush=True)
    if code:print((out/'worker.log').read_text(encoding='utf-8')[-3000:]);raise SystemExit(code)


if __name__=='__main__':main()
