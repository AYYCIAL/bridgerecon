"""Single-GPU job executor. Durable accounting and owned-tree timeout.

All child wall time (including imports/CPU work/failure) is charged. Pure CPU
offline work/downloads run outside this executor. Interrupted reservations
remain recorded until audited. The user removed cumulative/category compute
caps on 2026-10-18; categories now label jobs and do not restrict execution.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, json, os, subprocess, sys, time, uuid
import ctypes
from ctypes import wintypes
from work_schedule import require_start_window

class OwnedJob:
    """Windows job object: terminate only this job's processes and descendants."""
    def __init__(self, child):
        self.api=ctypes.WinDLL('kernel32',use_last_error=True)
        self.api.CreateJobObjectW.argtypes=[ctypes.c_void_p,wintypes.LPCWSTR]
        self.api.CreateJobObjectW.restype=wintypes.HANDLE
        self.api.AssignProcessToJobObject.argtypes=[wintypes.HANDLE,wintypes.HANDLE]
        self.api.AssignProcessToJobObject.restype=wintypes.BOOL
        self.api.TerminateJobObject.argtypes=[wintypes.HANDLE,wintypes.UINT]
        self.api.TerminateJobObject.restype=wintypes.BOOL
        self.api.CloseHandle.argtypes=[wintypes.HANDLE]
        self.api.SetInformationJobObject.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,wintypes.DWORD]
        self.api.SetInformationJobObject.restype=wintypes.BOOL
        self.handle=self.api.CreateJobObjectW(None,None)
        if not self.handle:
            child.kill();child.wait()
            raise ctypes.WinError(ctypes.get_last_error())
        class Basic(ctypes.Structure):
            _fields_=[('per_process',ctypes.c_int64),('per_job',ctypes.c_int64),('flags',wintypes.DWORD),
                      ('min_working',ctypes.c_size_t),('max_working',ctypes.c_size_t),('active',wintypes.DWORD),
                      ('affinity',ctypes.c_size_t),('priority',wintypes.DWORD),('scheduling',wintypes.DWORD)]
        class Extended(ctypes.Structure):
            _fields_=[('basic',Basic),('io',ctypes.c_uint64*6),('process_memory',ctypes.c_size_t),
                      ('job_memory',ctypes.c_size_t),('peak_process',ctypes.c_size_t),('peak_job',ctypes.c_size_t)]
        info=Extended();info.basic.flags=0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        if not self.api.SetInformationJobObject(self.handle,9,ctypes.byref(info),ctypes.sizeof(info)):
            error=ctypes.get_last_error()
            child.kill();child.wait();self.api.CloseHandle(self.handle)
            raise ctypes.WinError(error)
        if not self.api.AssignProcessToJobObject(self.handle,int(child._handle)):
            error=ctypes.get_last_error()
            child.kill();child.wait();self.api.CloseHandle(self.handle)
            raise ctypes.WinError(error)
    def terminate(self):
        if not self.api.TerminateJobObject(self.handle,124):
            raise ctypes.WinError(ctypes.get_last_error())
    def close(self):
        self.api.CloseHandle(self.handle)

BASE = Path(__file__).resolve().parent
LEDGER = BASE / 'gpu_ledger.json'
LOCK = BASE / 'gpu_runner.lock'
CATEGORY = ('development', 'upstream', 'colmap', 'refinement', 'contingency')
def now():
    return datetime.now(timezone.utc).isoformat()
def save(data):
    if data.get('limit_seconds') is not None:
        data.setdefault('historical_limit_seconds', data['limit_seconds'])
    data['limit_seconds'] = None
    data['cumulative_limit_enforced'] = False
    data['category_limits_enforced'] = False
    data['compute_policy'] = 'User removed cumulative/category caps on 2026-10-18; retain elapsed accounting, exclusive local GPU execution and individual job timeouts'
    tmp = LEDGER.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, LEDGER)
def charges(jobs, category=None):
    return sum(x['charged_seconds'] for x in jobs if category is None or x['category']==category)
def main():
    p = argparse.ArgumentParser()
    p.add_argument('--name', required=True)
    p.add_argument('--category', choices=CATEGORY, default='development')
    p.add_argument('--timeout', type=float, required=True)
    p.add_argument('command', nargs=argparse.REMAINDER)
    a = p.parse_args()
    command = a.command[1:] if a.command[:1] == ['--'] else a.command
    if not command or a.timeout <= 0:
        p.error('Positive timeout and command required')
    # The original runner refused jobs that would run past a local daily stop time
    # (see work_schedule.py); the public stand-in never refuses.
    window = require_start_window(a.timeout)
    # O_EXCL prevents concurrent GPU jobs. A stale lock requires explicit audit.
    fd = os.open(LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    os.write(fd, json.dumps({'pid':os.getpid(), 'started':now()}).encode())
    os.close(fd)
    child = None
    owned = None
    try:
        if LEDGER.exists():
            data = json.loads(LEDGER.read_text(encoding='utf-8'))
        else:
            data = {'limit_seconds':None, 'accounting':'whole reserved child wall time; interrupted reservations conservatively recorded',
                    'jobs':[{'id':'prior-pilots', 'category':'development', 'status':'historical_credit',
                             'charged_seconds':360, 'note':'Conservative 0.1h for prior CUDA/COLMAP probes'}]}
        identifier = datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:6]
        logdir = BASE/'logs'; logdir.mkdir(exist_ok=True)
        logfile = logdir/(identifier+'.log')
        job = {'id':identifier, 'name':a.name, 'category':a.category, 'started_utc':now(),
               'command':command, 'status':'reserved', 'timeout_seconds':a.timeout,
               'charged_seconds':a.timeout, 'log':str(logfile.relative_to(BASE)),
               'daily_schedule':window}
        data['jobs'].append(job); save(data)
        started = time.monotonic()
        print(json.dumps({'job':identifier, 'log':str(logfile), 'reserved_seconds':a.timeout}), flush=True)
        with logfile.open('w', encoding='utf-8') as log:
            try:
                child = subprocess.Popen(command, cwd=BASE.parent, stdout=log, stderr=subprocess.STDOUT,
                                         creationflags=subprocess.CREATE_NO_WINDOW)
                owned = OwnedJob(child)
                job['pid'] = child.pid; job['status']='running'; save(data)
                before_quiet = (datetime.fromisoformat(window['deadline_utc'])-datetime.now(timezone.utc)).total_seconds()-30
                effective_timeout = max(.01, min(a.timeout, before_quiet))
                job['effective_timeout_seconds'] = effective_timeout
                code = child.wait(timeout=effective_timeout)
                job['status'] = 'completed' if code == 0 else 'failed'
                job['exit_code'] = code
            except subprocess.TimeoutExpired:
                job['status']='schedule_stop' if effective_timeout < a.timeout else 'timeout'
                owned.terminate()
                child.wait(timeout=20)
            except BaseException as e:
                job['status']='runner_error'; job['error']=repr(e)
                if child is not None and child.poll() is None:
                    if owned is not None:
                        owned.terminate()
                    else:
                        child.kill()
                    child.wait(timeout=20)
                raise
            finally:
                # Preserve reservation if cleanup could not prove child exit.
                if child is None or child.poll() is not None:
                    job['charged_seconds']=time.monotonic()-started
                    job['ended_utc']=now()
                save(data)
        print(json.dumps({'status':job['status'], 'charged_seconds':job['charged_seconds'],
                          'total_hours':charges(data['jobs'])/3600}), flush=True)
        return 0 if job['status']=='completed' else 1
    finally:
        if owned is not None:
            owned.close()
        if child is None or child.poll() is not None:
            LOCK.unlink(missing_ok=True)
if __name__ == '__main__':
    sys.exit(main())
