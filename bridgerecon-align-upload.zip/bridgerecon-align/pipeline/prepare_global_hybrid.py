"""Global track split, private training-only BA, and distortion-aware anchors.

The source SfM initialization used every source track. The new split excludes
checking IDs from this refit and depth stage, not from that earlier initializer.
"""
from pathlib import Path
from datetime import datetime
import argparse,hashlib,json,os,subprocess,sys,time,uuid
import numpy as np
from scipy.spatial import cKDTree
from budget_run import OwnedJob
from work_schedule import require_start_window

BASE=Path(__file__).resolve().parent
SOURCE=BASE/'runs/full_route_survey_20261018_221243_8084fdb4'
MODEL=SOURCE/'mapping_attempts/20261019_083806_a47eff8e/sparse'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,r):
    tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(p)
def checking(pid):return int.from_bytes(hashlib.sha256(f'hybrid-v1|{pid}'.encode()).digest()[:8],'big')%5==0


def worker(out):
    import pycolmap
    started=time.monotonic();os.chdir(SOURCE)
    model=pycolmap.Reconstruction(MODEL.relative_to(SOURCE).as_posix())
    metadata=json.loads((SOURCE/'report.json').read_text(encoding='utf-8'));names={x['name']:x['index'] for x in metadata['images']}
    original_hash={n:sha(MODEL/n) for n in ('cameras.bin','images.bin','points3D.bin')}
    images=sorted(model.images.values(),key=lambda im:names[im.name]);image_ids=[im.image_id for im in images]
    slots={im.image_id:i for i,im in enumerate(images)};indices=[names[im.name] for im in images]
    ids=sorted(model.points3D);check_ids=[pid for pid in ids if checking(pid)];train_ids=[pid for pid in ids if not checking(pid)]
    rng=np.random.default_rng(20261019);keep=set(map(int,rng.choice(train_ids,min(20000,len(train_ids)),replace=False)))
    for image in images:
        visible=sorted({p.point3D_id for p in image.points2D if p.has_point3D() and not checking(p.point3D_id)})
        have=sum(pid in keep for pid in visible)
        for pid in visible:
            if have>=min(200,len(visible)):break
            if pid not in keep:keep.add(pid);have+=1
    assert not keep.intersection(check_ids)
    observations=[]
    for point_slot,pid in enumerate(check_ids):
        for element in model.points3D[pid].track.elements:
            observations.append((point_slot,slots[element.image_id],*model.images[element.image_id].points2D[element.point2D_idx].xy))
    obs=np.array(observations);point_slot=obs[:,0].astype(int);view_slot=obs[:,1].astype(int);uv=obs[:,2:]
    del observations
    np.savez_compressed(out/'split.npz',all_ids=np.array(ids),checking_ids=np.array(check_ids),training_available_ids=np.array(train_ids),selected_training_ids=np.array(sorted(keep)))
    report={'status':'preparing','created':datetime.now().astimezone().isoformat(),'source_model':str(MODEL),'source_sha256':original_hash,
            'reference_access':False,'initialization_used_checking_tracks':True,'new_stages_exclude_checking_ids':True,
            'scope':'New-stage track isolation; source SfM initializer was fitted to all tracks; not external or pipeline-independent accuracy',
            'settings':{'split':'SHA256 hybrid-v1|globalID prefix modulo5==0 checking','training_seed':20261019,
                        'requested_training_points':20000,'minimum_training_per_camera':200,'depth_exclusion_radius':6.,
                        'native_pixel_convention':'COLMAP upper-left edge origin; convert to array-center coordinates by scale*uv-0.5'},
            'registered_cameras':len(images),'source_points':len(ids),'checking_points':len(check_ids),'selected_training_points':len(keep),
            'checking_observations':len(obs),'split_sha256':sha(out/'split.npz')}
    save(out/'report.json',report)
    for pid in ids:
        if pid not in keep:model.delete_point3D(pid)
    private=out/'input_sparse';private.mkdir();model.write(private.relative_to(SOURCE).as_posix())
    fitted=out/'fitted_sparse';fitted.mkdir()
    cmd=[os.environ.get('COLMAP_EXE', 'colmap'),'bundle_adjuster','--input_path',private.relative_to(SOURCE).as_posix(),
         '--output_path',fitted.relative_to(SOURCE).as_posix(),'--BundleAdjustment.use_gpu','0',
         '--BundleAdjustment.max_num_iterations','100','--BundleAdjustment.function_tolerance','1e-5',
         '--BundleAdjustment.gradient_tolerance','1e-4','--BundleAdjustment.parameter_tolerance','1e-6',
         '--BundleAdjustment.refine_focal_length','1','--BundleAdjustment.refine_principal_point','0',
         '--BundleAdjustment.refine_extra_params','1','--BundleAdjustment.min_num_residuals_for_cpu_multi_threading','1000000000']
    report.update(status='training_camera_ba',command=cmd);save(out/'report.json',report)
    tick=time.monotonic()
    with (out/'ba.log').open('w') as log:
        result=subprocess.run(cmd,cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT,timeout=300,creationflags=subprocess.CREATE_NO_WINDOW)
    report['camera_ba_seconds']=time.monotonic()-tick;report['camera_ba_exit']=result.returncode
    if result.returncode:raise RuntimeError('Private training BA failed')
    model=pycolmap.Reconstruction(fitted.relative_to(SOURCE).as_posix())
    assert set(model.points3D)==keep and not set(model.points3D).intersection(check_ids)
    images=[model.images[i] for i in image_ids];E=np.array([im.cam_from_world.matrix() for im in images])
    normalized=np.empty_like(uv)
    for slot,image in enumerate(images):
        selected=view_slot==slot;normalized[selected]=model.cameras[image.camera_id].cam_from_img(uv[selected])
    # Linear homogeneous triangulation of checking tracks at fixed refitted cameras.
    ata=np.zeros((len(check_ids),4,4))
    for slot in range(len(images)):
        selected=np.where(view_slot==slot)[0];n=normalized[selected]
        a=n[:,0,None]*E[slot,2]-E[slot,0];b=n[:,1,None]*E[slot,2]-E[slot,1]
        np.add.at(ata,point_slot[selected],np.einsum('ni,nj->nij',a,a)+np.einsum('ni,nj->nij',b,b))
    eigen,vectors=np.linalg.eigh(ata);homogeneous=vectors[:,:,0]
    with np.errstate(divide='ignore',invalid='ignore'):check_xyz=homogeneous[:,:3]/homogeneous[:,3,None]
    report['finite_checking_triangulated_points']=int(np.isfinite(check_xyz).all(axis=1).sum())
    np.savez_compressed(out/'global_checking_tracks.npz',point_ids=np.array(check_ids),xyz=check_xyz,point_slot=point_slot,view_slot=view_slot,native_uv=uv)
    finish_export(out,report,model,images,indices,point_slot,view_slot,uv,check_xyz,check_ids,original_hash,started)


def finish_export(out,report,model,images,indices,point_slot,view_slot,uv,check_xyz,check_ids,original_hash,started):
    fitted=out/'fitted_sparse'
    E=np.array([im.cam_from_world.matrix() for im in images])
    image_ids=[im.image_id for im in images]
    camera_info={str(cid):{'model':cam.model.name,'width':cam.width,'height':cam.height,'params':cam.params.tolist()} for cid,cam in model.cameras.items()}
    save(out/'native_cameras.json',camera_info)
    anchors=out/'anchors';anchors.mkdir(exist_ok=True);view_records=[]
    for slot,image in enumerate(images):
        cam=model.cameras[image.camera_id];assert cam.width==1600 and cam.height==1200
        # 8064x6048 -> official 518x392; COLMAP feature coordinates have edge origin.
        A=np.array([[518/cam.width,0,-.5],[0,392/cam.height,-.5],[0,0,1.]])
        train=[]
        for point in image.points2D:
            if point.has_point3D():train.append((point.point3D_id,*point.xy))
        train=np.array(train);tids=train[:,0].astype(np.int64);tuv=train[:,1:]@A[:2,:2].T+A[:2,2]
        txyz=np.array([model.points3D[int(pid)].xyz for pid in tids]);tz=(txyz@E[slot,:,:3].T+E[slot,:,3])[:,2]
        selected=np.where(view_slot==slot)[0];cuv=uv[selected]@A[:2,:2].T+A[:2,2];cids=np.array(check_ids)[point_slot[selected]]
        cxyz=check_xyz[point_slot[selected]];cz=(cxyz@E[slot,:,:3].T+E[slot,:,3])[:,2]
        # Membership/positions only; checking residuals are not read by training selection.
        distance=cKDTree(cuv).query(tuv)[0] if len(cuv) else np.full(len(tuv),np.inf)
        eligible=(distance>6.)&(tz>0)&np.isfinite(tz)&(tuv[:,0]>=1)&(tuv[:,0]<517)&(tuv[:,1]>=1)&(tuv[:,1]<391)
        record={'index':indices[slot],'name':image.name,'slot':slot,'camera_id':image.camera_id,'train_anchors':len(tids),
                'train_depth_eligible':int(eligible.sum()),'check_anchors':len(cids),'file':f'anchors/v{indices[slot]:04d}.npz'}
        np.savez_compressed(out/record['file'],train_ids=tids,train_uv=tuv,train_xyz=txyz,train_z=tz,train_eligible=eligible,
                            checking_ids=cids,checking_uv=cuv,checking_xyz=cxyz,checking_z=cz,
                            extrinsics=E[slot],native_to_input=A,camera_id=np.array(image.camera_id))
        assert not set(tids).intersection(cids)
        record['sha256']=sha(out/record['file']);view_records.append(record)
    np.savez_compressed(out/'global_cameras.npz',extrinsics=E,image_indices=np.array(indices),image_ids=np.array(image_ids),camera_ids=np.array([im.camera_id for im in images]))
    report.update(status='completed',views=view_records,native_cameras=camera_info,
                  fitted_model_sha256={n:sha(fitted/n) for n in original_hash},
                  source_unchanged=all(sha(MODEL/n)==h for n,h in original_hash.items()),
                  training_depth_support_percentiles=np.percentile([r['train_depth_eligible'] for r in view_records],[0,5,50,95,100]).tolist(),
                  seconds=time.monotonic()-started)
    assert report['source_unchanged'];save(out/'report.json',report);print('REPORT',out,flush=True)


def resume_export(out):
    import pycolmap
    started=time.monotonic();os.chdir(SOURCE)
    report=json.loads((out/'report.json').read_text(encoding='utf-8'))
    assert all(sha(MODEL/n)==h for n,h in report['source_sha256'].items())
    with np.load(out/'split.npz') as split:
        keep=set(map(int,split['selected_training_ids']));assert sha(out/'split.npz')==report['split_sha256']
    model=pycolmap.Reconstruction((out/'fitted_sparse').relative_to(SOURCE).as_posix())
    assert set(model.points3D)==keep
    metadata=json.loads((SOURCE/'report.json').read_text(encoding='utf-8'));names={x['name']:x['index'] for x in metadata['images']}
    images=sorted(model.images.values(),key=lambda im:names[im.name]);indices=[names[im.name] for im in images]
    data=dict(np.load(out/'global_checking_tracks.npz'))
    assert not keep.intersection(map(int,data['point_ids']))
    report.update(status='resuming_export',prior_export_error=report.pop('error',None),
                  timing_scope='seconds records resumed export only; original BA stage duration remains camera_ba_seconds',
                  camera_refit_repeated=False,resume_driver_sha256=sha(Path(__file__)))
    finish_export(out,report,model,images,indices,data['point_slot'],data['view_slot'],data['native_uv'],data['xyz'],
                  data['point_ids'].tolist(),report['source_sha256'],started)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--worker',action='store_true');parser.add_argument('--out',type=Path)
    parser.add_argument('--resume-export',action='store_true');args=parser.parse_args()
    if args.worker:
        try:
            if args.resume_export:resume_export(args.out.resolve())
            else:worker(args.out.resolve())
        except Exception as exc:
            path=args.out/'report.json';r=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
            r.update(status='failed',error=repr(exc));save(path,r);raise
        return
    require_start_window(900)
    if args.resume_export:
        out=args.out.resolve();out.relative_to(SOURCE/'hybrid_preparations')
        suffix=datetime.now().strftime('%Y%m%d_%H%M%S')
        (out/f'failed_export_report_{suffix}.json').write_bytes((out/'report.json').read_bytes())
        (out/f'resume_driver_source_{suffix}.py').write_bytes(Path(__file__).read_bytes())
    else:
        out=SOURCE/'hybrid_preparations'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir(parents=True)
        (out/'driver_source.py').write_bytes(Path(__file__).read_bytes())
    env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='-1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',PYTHONIOENCODING='utf-8')
    with (out/('resume_export.log' if args.resume_export else 'worker.log')).open('w',encoding='utf-8') as log:
        command=[sys.executable,'-u',str(Path(__file__).resolve()),'--worker','--out',str(out)]
        if args.resume_export:command.append('--resume-export')
        child=subprocess.Popen(command,cwd=BASE.parent,
                               env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        owned=OwnedJob(child)
        try:code=child.wait(timeout=840)
        except subprocess.TimeoutExpired:owned.terminate();child.wait(timeout=15);raise
        finally:owned.close()
    print('REPORT',out)
    if code:print((out/('resume_export.log' if args.resume_export else 'worker.log')).read_text(encoding='utf-8',errors='replace')[-3500:]);raise SystemExit(code)


if __name__=='__main__':main()
