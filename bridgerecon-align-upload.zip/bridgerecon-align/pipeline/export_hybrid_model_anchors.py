"""Export a saved training-point camera control with re-triangulated checks."""
from pathlib import Path
from datetime import datetime
import argparse,json,os,shutil,subprocess,sys,time,uuid
import numpy as np
from prepare_global_hybrid import BASE,SOURCE,MODEL,finish_export,sha,save
from budget_run import OwnedJob
from work_schedule import require_start_window

ORIGINAL=SOURCE/'hybrid_preparations/20261019_194608_05d2032e'


def worker(control,out):
    import pycolmap
    started=time.monotonic();os.chdir(SOURCE)
    src=json.loads((control/'report.json').read_text(encoding='utf-8'));assert src['status']=='completed' and src['solver']['solution_usable']
    split=dict(np.load(ORIGINAL/'split.npz'));tracks=dict(np.load(ORIGINAL/'global_checking_tracks.npz'))
    original=json.loads((ORIGINAL/'report.json').read_text(encoding='utf-8'))
    shutil.copy2(ORIGINAL/'split.npz',out/'split.npz');fitted=out/'fitted_sparse';fitted.mkdir()
    for n,h in src['output_sha256'].items():
        assert sha(control/'sparse'/n)==h;shutil.copy2(control/'sparse'/n,fitted/n)
    model=pycolmap.Reconstruction(fitted.relative_to(SOURCE).as_posix());assert set(model.points3D)==set(map(int,split['selected_training_ids']))
    assert not set(model.points3D).intersection(map(int,split['checking_ids']))
    names={r['name']:r['index'] for r in json.loads((SOURCE/'report.json').read_text(encoding='utf-8'))['images']}
    images=sorted(model.images.values(),key=lambda im:names[im.name]);indices=[names[im.name] for im in images]
    assert indices==np.load(ORIGINAL/'global_cameras.npz')['image_indices'].tolist()
    E=np.array([im.cam_from_world.matrix() for im in images]);point_slot=tracks['point_slot'];view_slot=tracks['view_slot'];uv=tracks['native_uv'];ids=tracks['point_ids']
    ata=np.zeros((len(ids),4,4))
    for slot,image in enumerate(images):
        selected=np.where(view_slot==slot)[0];n=model.cameras[image.camera_id].cam_from_img(uv[selected])
        a=n[:,0,None]*E[slot,2]-E[slot,0];b=n[:,1,None]*E[slot,2]-E[slot,1]
        np.add.at(ata,point_slot[selected],np.einsum('ni,nj->nij',a,a)+np.einsum('ni,nj->nij',b,b))
    values,vectors=np.linalg.eigh(ata);homogeneous=vectors[:,:,0]
    with np.errstate(divide='ignore',invalid='ignore'):xyz=homogeneous[:,:3]/homogeneous[:,3,None]
    np.savez_compressed(out/'global_checking_tracks.npz',point_ids=ids,xyz=xyz,point_slot=point_slot,view_slot=view_slot,native_uv=uv)
    report={k:original[k] for k in ['source_model','source_sha256','reference_access','initialization_used_checking_tracks','new_stages_exclude_checking_ids',
                                  'scope','settings','registered_cameras','source_points','checking_points','selected_training_points','checking_observations']}
    report.update(created=datetime.now().astimezone().isoformat(),status='exporting',
                  split_sha256=sha(out/'split.npz'),camera_control_source=str(control),camera_control_report_sha256=sha(control/'report.json'),
                  camera_control_solver=src['solver'],camera_control_calibration=src.get('calibration','Free shared focal/radial, fixed principal point; legacy report schema'),
                  navigation_sigma_assumption=src['navigation_standard_deviation_assumption_metres'],
                  stored_coordinate_units=src['stored_coordinate_units'],finite_checking_triangulated_points=int(np.isfinite(xyz).all(axis=1).sum()),
                  timing_scope='Anchor export/retriangulation only; camera refit recorded in source control')
    save(out/'report.json',report)
    finish_export(out,report,model,images,indices,point_slot,view_slot,uv,xyz,ids.tolist(),report['source_sha256'],started)


def main():
    p=argparse.ArgumentParser();p.add_argument('control',type=Path);p.add_argument('--worker',action='store_true');p.add_argument('--out',type=Path);args=p.parse_args()
    if args.worker:
        try:worker(args.control.resolve(),args.out.resolve())
        except Exception as exc:
            path=args.out/'report.json';r=json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
            r.update(status='failed',error=repr(exc));save(path,r);raise
        return
    require_start_window(600)
    out=SOURCE/'hybrid_preparations'/('control_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir()
    for name in ['export_hybrid_model_anchors.py','prepare_global_hybrid.py']:(out/name).write_bytes((BASE/name).read_bytes())
    env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='-1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',PYTHONIOENCODING='utf-8')
    with (out/'worker.log').open('w',encoding='utf-8') as log:
        child=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve()),str(args.control),'--worker','--out',str(out)],cwd=BASE.parent,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW);owned=OwnedJob(child)
        try:code=child.wait(timeout=540)
        except subprocess.TimeoutExpired:owned.terminate();child.wait(timeout=15);raise
        finally:owned.close()
    print('REPORT',out)
    if code:print((out/'worker.log').read_text(encoding='utf-8',errors='replace')[-3500:]);raise SystemExit(code)


if __name__=='__main__':main()
