# E6: staged timing of the complete workflow

Hardware: one NVIDIA L4 GPU (24 GB) with 12 vCPUs. The depth-stage times measured on the RTX 4060 laptop (Table 5 of the article) use different hardware and input images, so absolute times are not directly comparable between the two computers; ratios between methods are. Cloud checkpoint packaging, transfer checks and environment installation are excluded from all times. The values are summarized in Supplementary Table S5.

## Stage times (s)

| Stage | VGGT (this workflow) | MVS518 | MVS1600 | Source |
|---|---:|---:|---:|---|
| Feature extraction | 20.1 (shared) | shared | shared | measured |
| GPU guided matching | 35.2 (shared) | shared | shared | measured |
| Incremental mapping (578 images) | 1,795.3 (shared) | shared | shared | measured |
| Camera adjustment to C5, including anchor export | 150.6 (shared) | shared | shared | measured (23.5 + 114.3 + 12.8) |
| Undistortion | — | 29.5 | 33.4 | measured |
| Model loading | 2.3 | — | — | measured, median of three runs |
| Depth | 284.1 (inference only 129.5) | 2,569.6 | 8,718.5 | measured |
| Calibration (production mode, V3 only) | 18.4 | — | — | measured |
| Point-cloud generation | 14.9 | 218.5 | 847.6 | measured; MVS fused in 72 chunks |
| 5-cm voxel downsampling | 4.6 | 4.6 | 35.5 | measured |
| **Method-specific total** | **324.3** | **2,822.2** | **9,635.0** | |
| **Complete workflow, including the shared 2,001.2 s** | **38.8 min** | **80.4 min** | **3.23 h** | |
| Points before → after downsampling | 5.40 M → 5.36 M | 5.36 M → 5.19 M | 38.13 M → 33.91 M | measured |

Research-mode calibration (four variants with evaluation) took 65.6 s; it is listed separately and is not part of the production workflow.

## Ratios

- Depth stage only: MVS518 takes 9.0 times as long as VGGT and MVS1600 30.7 times; on inference time alone, 19.8 and 67.3 times.
- Complete workflow: MVS518 takes 2.1 times as long as VGGT and MVS1600 5.0 times.

The two measures differ because the shared SfM and camera adjustment take 33.4 min, 86% of the complete VGGT workflow. On the RTX 4060 laptop, the depth stage alone gives a factor of 15 (MVS1600 9254 s against 617 s for VGGT depth and calibration).

## Notes

- VGGT depth: median of three independent full-route runs, including image reading, pre-processing and writing, after subtracting 5.2 s of checkpoint input/output; the three runs took 287.8–289.5 s.
- Complete costs are the sums of the stage times.
