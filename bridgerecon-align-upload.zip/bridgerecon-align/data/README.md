# Intermediate data

These are the intermediate data of the article: aggregate result tables, the deterministic camera-fold and point-split identifiers, the frozen settings, the per-chunk and per-image depth scales of the primary configuration C5, and the per-image range comparison of C5 and C8. Photographs and points are identified by index only.

## Contents

| Path | Content | Article |
|---|---|---|
| `camera_fold_ids.csv` | Navigation split of the 578 registered photographs: 454 training and 124 test positions | Section 2.3 |
| `point_split_ids.csv` | Training/checking split of the 208,426 SfM points and the 20,143 selected anchors | Section 2.3 |
| `parameters.json` | Frozen reconstruction and evaluation settings | Table S1 |
| `calibration/chunk_calibration.csv` | Per chunk: start photograph, pooled training observations, motion scale s_k, pooled scale q_k, s_k·q_k / median, alignment residuals | Figure 4e |
| `calibration/view_scales.csv` | Per photograph and chunk: training anchors, raw and applied scale, acceptance, ratio to q_k | Section 3.1 |
| `aggregate/E0` | Instrument specification and image-metadata audit | Section 2.6 |
| `aggregate/E1` | Held-out RTK residuals with similarities fitted to 454 or 576 positions | Table 6, Table S2 |
| `aggregate/E4` | Camera, timing and vertical-reference controls; six sources of uncertainty | Tables S9 and S17 |
| `aggregate/E5b` | Reconstruction without the checking features (C5′) | Table S6 |
| `aggregate/E6` | Staged timing ledger and cross-view reproduction on the L4 | Tables S5 and S16 |
| `aggregate/E7` | Confidence and scale-bound controls | Table S10 |
| `aggregate/E8` | Anchor thinning; route-block bootstrap differences | Table S11 |
| `aggregate/E9` | Flight-geometry subsets; registration of the oblique photographs | Table S12 |
| `aggregate/prior_focal_tables` | Position-prior and fixed-focal sensitivity | Tables S7 and S8, Figure 11 |
| `aggregate/reviewer3` | C5 and C8 seam and range comparison, spatial bootstrap, beam-offset scenarios, per-image uncorrected ranges | Table 7, Tables S13–S15 and S18 |
| `aggregate/range_correction` | Range-based scale correction tested on held-out photographs (written by `demos/range_scale_correction.py`) | Section 3.8, Table S18 |
| `aggregate/figures` | Data drawn in Figures 7 and 11 | Figures 7 and 11 |
| `aggregate/geometry_metrics.json` | Baseline, intersection-angle and cross-pass statistics of the evaluation pairs | Section 2.5 |

## Not included

The UAV photographs, the exact trajectory, the SfM database, the model weights and the full prediction arrays are not public. The imagery is available from the corresponding author upon reasonable request and with the permission of the infrastructure management authority.

## Notes

- C5 is the primary configuration, C5′ the reconstruction without the checking features, and C6–C8 the post hoc diagnostics. They are reported separately.
- Range agreement is agreement with the onboard laser rangefinder.
- Beam-offset values are scenario ranges, not statistical confidence intervals.
- Provenance fields in the JSON files name files in the authors' workspace.

## License

CC BY 4.0 (see `LICENSE` in this folder).
