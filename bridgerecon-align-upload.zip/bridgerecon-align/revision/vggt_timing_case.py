"""One fresh full-route VGGT run on the approved 1600px input photographs."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib
import json
import os
import shutil
import sys
import time

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--repetition', type=int, required=True)
args = parser.parse_args()
assert args.repetition in [1, 2, 3]
root, out = args.root.resolve(), args.out.resolve()
runtime = json.loads((root / 'runtime_manifest.json').read_text())
survey = root / runtime['survey']
assert out.is_relative_to(survey)
out.mkdir(exist_ok=True)
sys.path.insert(0, str(root / 'experiments'))
import work_schedule
work_schedule.require_start_window = lambda seconds: None
module = importlib.import_module('run_vggt_route_chunks')
source_bytes = Path(module.__file__).read_bytes()
source = source_bytes.decode('utf-8-sig')
old = "out=BASE/'runs'/('vggt_route_chunks_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);out.mkdir()"
assert source.count(old) == 1
source = source.replace(old, 'out=E6_RUN_OUTPUT;out.mkdir(exist_ok=True)')
old_inventory = "inventory=json.loads((BASE/'data_audit/images.json').read_text(encoding='utf-8'))"
assert source.count(old_inventory) == 1
source = source.replace(old_inventory, 'inventory=E6_RESIZED_INVENTORY')
exec(compile(source, module.__file__, 'exec'), module.__dict__)
module.require_start_window = lambda seconds: None
module.E6_RUN_OUTPUT = out / 'predictions'
inventory = json.loads((root / 'experiments/data_audit/images.json').read_text())
survey_report = json.loads((survey / 'report.json').read_text())
names = {row['index']: row['name'] for row in survey_report['images']}
module.E6_RESIZED_INVENTORY = [dict(row, file=(survey / 'images' / names[row['index']]).relative_to(root).as_posix()) for row in inventory]
assert all((root / row['file']).is_file() for row in module.E6_RESIZED_INVENTORY)
drive_root = Path(os.environ.get('BRIDGERECON_CHECKPOINTS', '/content/cpu_supplement_checkpoints'))  # checkpoint copies
direct_drive = False
drive_root.mkdir(parents=True, exist_ok=True)
drive = drive_root / out.name
drive.mkdir(exist_ok=True)
original_save = module.save
published = set()
chunk_checkpoints = []
checkpoint_seconds = 0.


def checked_save(path, value):
    global checkpoint_seconds
    original_save(path, value)
    if path.name != 'report.json' or 'chunks' not in value:
        return
    for row in value['chunks']:
        if row.get('status') != 'completed' or row['start'] in published:
            continue
        tick = time.monotonic()
        source_path = module.E6_RUN_OUTPUT / row['prediction']
        name = f'Supplement_{out.name}_chunk_{row["start"]:04d}.npz'
        target = drive / name if direct_drive else drive_root / name
        temporary = target.with_suffix('.partial')
        shutil.copyfile(source_path, temporary)
        hasher = hashlib.sha256()
        with temporary.open('rb') as stream:
            for block in iter(lambda: stream.read(4 * 1024**2), b''):
                hasher.update(block)
        digest = hasher.hexdigest()
        assert digest == row['sha256']
        temporary.replace(target)
        marker = dict(name=name, start=row['start'], sha256=digest, bytes=target.stat().st_size,
                      image_indices=row['image_indices'])
        target.with_suffix('.ok.json').write_text(json.dumps(marker))
        published.add(row['start'])
        chunk_checkpoints.append(marker)
        checkpoint_seconds += time.monotonic() - tick
    progress = dict(completed_chunks=len(published), checkpoint_seconds=checkpoint_seconds, chunk_checkpoints=chunk_checkpoints,
                    updated_utc=datetime.now(timezone.utc).isoformat())
    original_save(out / 'progress.json', progress)
    shutil.copyfile(path, drive / 'report.json')


module.save = checked_save
case = dict(status='running', repetition=args.repetition, fresh_inference=True,
            source_sha256=hashlib.sha256(source_bytes).hexdigest(),
            overlay_sha256=hashlib.sha256(source.encode()).hexdigest(),
            input_policy='Approved 1600x1200 JPEG photographs, then official 518x392 preprocessing. Compare new results with original 8064x6048-derived predictions.',
            checkpoint_policy='Every completed chunk copied and SHA256 verified. Host-spooled chunks require verified host recovery before the next run.')
started = time.monotonic()
try:
    sys.argv = ['run_vggt_route_chunks.py', '--all-main']
    module.main()
    report = json.loads((module.E6_RUN_OUTPUT / 'report.json').read_text())
    assert report['status'] == 'completed' and len(report['chunks']) == 72
    assert len(published) == 72 and report['unique_images'] == 576
    assert not report['reuse_sources'] and all('reused_from' not in row for row in report['chunks'])
    case.update(status='completed', completed_chunks=72, model_load_seconds=report['model_load_seconds'],
                pure_inference_seconds=sum(row['inference_seconds'] for row in report['chunks']),
                worker_seconds_with_checkpoint_io=report['seconds'], checkpoint_seconds=checkpoint_seconds,
                prediction_directory=str(module.E6_RUN_OUTPUT))
except BaseException as error:
    case.update(status='failed', error_type=type(error).__name__, error=str(error)[:2000])
    raise
finally:
    case['seconds'] = time.monotonic() - started
    original_save(out / 'case.json', case)
    shutil.copyfile(out / 'case.json', drive / 'case.json')
print('VGGT_FRESH_TIMING_COMPLETED', args.repetition, flush=True)
