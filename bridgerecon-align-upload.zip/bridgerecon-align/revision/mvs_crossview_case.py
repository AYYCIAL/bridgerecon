"""E6 reproduction check: cross-view errors of the new (L4-recomputed) MVS depth maps.

Same evaluator as experiments/evaluate_native_mvs_checking.py: frozen C5 cameras, the
same checking samples and 691,694 fixed pairs, four-positive-neighbour bilinear support.
Only the inputs differ. The depth maps are the restored new maps, and the undistorted
MVS cameras come from the restore manifest, whose parity was verified during fusion.
Those cameras are the ones the PatchMatch runs used.
"""
from pathlib import Path, PureWindowsPath
import argparse
import json
import resource
import sys
import time
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--width', type=int, choices=[518, 1600], required=True)
parser.add_argument('--manifest', type=Path, default=Path('/content/mvs_restore_manifest.json'))
args = parser.parse_args()
root = args.root.resolve()
args.out.mkdir(exist_ok=True)
runtime = json.loads((root / 'runtime_manifest.json').read_text(encoding='utf-8'))
survey = root / runtime['survey']
sys.path.insert(0, str(root / 'experiments'))
import work_schedule  # noqa: E402
work_schedule.require_start_window = lambda seconds: None
from audit_native_depth_maps import map_view  # noqa: E402
from global_hybrid_geometry import native_rays, camera_parameters, project_native  # noqa: E402
from local_validation import statistics, inside  # noqa: E402
old_root = PureWindowsPath(runtime['old_absolute_root'])
started = time.monotonic()
case = dict(status='running', width=args.width, completed_views=0,
            scope='Reproduction check of the new MVS depth maps with the frozen manuscript evaluator; '
                  'descriptive image consistency, not physical accuracy')


def relocate(value):
    if isinstance(value, dict):
        return {key: relocate(item) for key, item in value.items()}
    if isinstance(value, list):
        return [relocate(item) for item in value]
    if isinstance(value, str):
        if value.startswith('/content/bridgerecon/'):
            return str(root / value[len('/content/bridgerecon/'):])
        path = PureWindowsPath(value)
        if path.is_absolute():
            try:
                return str(root.joinpath(*path.relative_to(old_root).parts))
            except ValueError:
                return value
        if '\\' in value and path.suffix:
            return path.as_posix()
    return value


def read(path):
    return relocate(json.loads(Path(path).read_text(encoding='utf-8')))


def save():
    case.update(seconds=time.monotonic() - started, peak_rss_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024)
    temporary = args.out / 'case.json.partial'
    temporary.write_text(json.dumps(case, indent=2))
    temporary.replace(args.out / 'case.json')
    temporary = args.out / 'progress.json.partial'
    temporary.write_text(json.dumps(dict(completed_chunks=case['completed_views'] // 24, phase=case.get('phase'))))
    temporary.replace(args.out / 'progress.json')


def sample_positive(values, uv):
    """Exact bilinear weights; require four positive finite neighbouring depths (copied from the evaluator)."""
    h, w = values.shape
    uv = np.asarray(uv)
    x = np.floor(uv[:, 0]).astype(int)
    y = np.floor(uv[:, 1]).astype(int)
    valid = np.isfinite(uv).all(axis=1) & (x >= 0) & (y >= 0) & (x + 1 < w) & (y + 1 < h)
    result = np.full(len(uv), np.nan)
    ids = np.where(valid)[0]
    xx = x[ids]
    yy = y[ids]
    four = np.c_[values[yy, xx], values[yy, xx + 1], values[yy + 1, xx], values[yy + 1, xx + 1]]
    good = np.isfinite(four).all(axis=1) & (four > 0).all(axis=1)
    valid[ids[~good]] = False
    dx = uv[ids, 0] - xx
    dy = uv[ids, 1] - yy
    weight = np.c_[(1 - dx) * (1 - dy), dx * (1 - dy), (1 - dx) * dy, dx * dy]
    result[ids[good]] = np.sum(weight[good] * four[good], axis=1)
    return result, valid


try:
    hybrid_dir = root / runtime['case_paths']['C5']['run']
    hybrid = read(hybrid_dir / 'report.json')
    prep = Path(hybrid['preparation'])
    if not prep.is_absolute() or not prep.exists():
        prep = root / runtime['case_paths']['C5']['preparation']
    anchors = read(prep / 'report.json')
    records = {view['index']: view for view in anchors['views']}
    original = read(prep / 'native_cameras.json')
    expected = json.loads(args.manifest.read_text())['expected_cameras'][str(args.width)]
    assert all(row['model'] == 1 for row in expected)
    native = {int(row['id']): dict(model='PINHOLE', width=int(row['width']), height=int(row['height']),
                                   params=[float(value) for value in row['params']]) for row in expected}
    maps_root = root / 'e6_restored_mvs' / f'C5_MVS{args.width}' / 'dense/stereo/depth_maps'
    metadata = read(survey / 'report.json')
    names = {row['index']: row['name'] for row in metadata['images']}
    with np.load(hybrid_dir / 'checking_samples.npz') as data:
        ids, views, uv = data['ids'], data['view'], data['uv']
        reference, hybrid_valid, hybrid_z = data['reference_z'], data['valid'], data['predicted_z']
    with np.load(hybrid_dir / 'checking_pairs.npz') as data:
        si, ti, hybrid_errors, hybrid_support = data['source'], data['target'], data['errors'], data['supported']
    assert len(si) == 691694
    case['phase'] = 'sampling_depth_maps'
    save()
    depth = np.full(len(ids), np.nan)
    xyz = np.full((len(ids), 3), np.nan)
    valid = np.zeros(len(ids), bool)
    view_models = {}
    for index in range(576):
        where = np.where(views == index)[0]
        with np.load(prep / Path(records[index]['file'])) as archive:
            a = {key: archive[key] for key in archive.files}
        E, A = a['extrinsics'], a['native_to_input']
        camera = original[str(int(a['camera_id']))]
        undistorted = native[int(a['camera_id'])]
        fx, fy, cx, cy, k = camera_parameters(undistorted)
        assert k == 0
        rays = native_rays(uv[where], camera, A)
        pixels = rays[:, :2] * [fx, fy] + [cx, cy]
        mapped = map_view(maps_root / (names[index] + '.geometric.bin'))
        assert mapped.shape == (undistorted['height'], undistorted['width'], 1)
        d, good = sample_positive(mapped[..., 0], pixels)
        depth[where] = d
        xyz[where] = (rays * d[:, None] - E[:, 3]) @ E[:, :3]
        valid[where] = good & np.isfinite(reference[where]) & (reference[where] > 0)
        view_models[index] = (E, camera, A)
        del mapped
        case['completed_views'] = index + 1
        if index % 24 == 23:
            save()
    case['phase'] = 'pair_errors'
    save()
    errors = np.full(len(si), np.nan)
    support = np.zeros(len(si), bool)
    for index, (E, camera, A) in view_models.items():
        selected = np.where(views[ti] == index)[0]
        pixel, z = project_native(xyz[si[selected]], E, camera, A)
        good = valid[si[selected]] & valid[ti[selected]] & (z > 0) & np.isfinite(pixel).all(axis=1) & inside(pixel)
        residual = np.linalg.norm(pixel - uv[ti[selected]], axis=1)
        errors[selected[good]] = residual[good]
        support[selected[good]] = True
    np.savez_compressed(args.out / 'checking_pairs.npz', source=si, target=ti, errors=errors, supported=support)
    relative = abs(depth - reference) / reference
    paired_pairs = support & hybrid_support.all(axis=1)
    paired_obs = valid & hybrid_valid.all(axis=1)
    paired = {variant: {'pairs': statistics(hybrid_errors[paired_pairs, column]),
                        'depth_relative': statistics((abs(hybrid_z[:, column] - reference) / reference)[paired_obs])}
              for column, variant in enumerate(hybrid['variants'])}
    metrics = dict(full_observations=len(ids), full_pairs=len(si), supported_observation_fraction=float(valid.mean()),
                   supported_pair_fraction=float(support.mean()), reprojection_pixels=statistics(errors),
                   fixed_inventory_success_below2px=float((errors < 2).mean()),
                   depth_relative_abs_error=statistics(relative[valid]))
    manuscript = {518: dict(median=0.336, p95=2.673, support=0.9693), 1600: dict(median=0.295, p95=2.378, support=0.9275)}
    case.update(status='completed', phase='done', metrics=metrics, paired_common_pairs=int(paired_pairs.sum()),
                paired_hybrid=paired, paired_native=dict(pairs=statistics(errors[paired_pairs]),
                                                         depth_relative=statistics(relative[paired_obs])),
                manuscript_route_reference=manuscript[args.width],
                camera_source='Undistorted PINHOLE cameras from the restore manifest (identical to the PatchMatch workspace)')
except BaseException as error:
    case.update(status='failed', error_type=type(error).__name__, error=str(error)[:1500])
    raise
finally:
    save()
print('MVS_CROSSVIEW_CASE_COMPLETED', args.width, flush=True)
