"""R3 CPU checks on frozen outputs: spatial bootstrap and C5/C8 seam/range.

Writes only results/reviewer3. Does not run BA, inference or MVS, and does
not update original results or reinterpret post-hoc C8 as a calibration.
"""
import os
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '2'
from pathlib import Path
import argparse
import csv
import hashlib
import io
import json
import sys
import time
import zipfile
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
RT = ROOT/'revision_20261116/local_runtime'
OUT = ROOT/'revision_20261116/results/reviewer3'
sys.path.insert(0, str(RT/'experiments'))
sys.path.insert(0, str(ROOT/'colab/jobs'))
from global_hybrid_geometry import native_rays
from historical_sampling import sample


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4*1024**2), b''):
            h.update(block)
    return h.hexdigest()


def stats(a):
    a = np.asarray(a)
    a = a[np.isfinite(a)]
    return dict(n=int(len(a)), median=float(np.median(a)), p95=float(np.percentile(a, 95)))


def save_csv(path, rows):
    with path.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


MANIFEST = read(RT/'runtime_manifest.json')
CASES = {c: {k: RT/v for k, v in MANIFEST['case_paths'][c].items()} for c in ('C5', 'C8')}


def bootstrap():
    started = time.monotonic()
    with np.load(CASES['C5']['run']/'checking_pairs.npz') as p:
        source, target = p['source'], p['target']
        errors = {name: p['errors'][:, k] for k, name in enumerate(('V0', 'V1', 'V2', 'V3'))}
        support = {name: p['supported'][:, k] for k, name in enumerate(('V0', 'V1', 'V2', 'V3'))}
    with np.load(CASES['C5']['run']/'checking_samples.npz') as data:
        view = data['view']
    scans = ROOT/'revision_20261116/results/night_20261117_recovered/scans'
    receipt = read(scans/'baseline_verification.json')
    archive = scans/receipt['archive']
    assert sha(archive) == receipt['sha256']
    with zipfile.ZipFile(archive) as z:
        with np.load(io.BytesIO(z.read('hybrid/checking_pairs.npz'))) as data:
            assert np.array_equal(data['source'], source) and np.array_equal(data['target'], target)
        with np.load(io.BytesIO(z.read('A3_checking_pairs.npz'))) as data:
            errors['A3'], support['A3'] = data['errors'], data['supported']
    archive_root = Path(MANIFEST['source_archive'])
    mvs_path = archive_root/'experiments/runs/native_mvs_checking_20261020_001654_cd47ff08/checking_pairs.npz'
    with np.load(mvs_path) as data:
        assert np.array_equal(data['source'], source) and np.array_equal(data['target'], target)
        errors['MVS1600'], support['MVS1600'] = data['errors'], data['supported']
    # Same fixed common support in every block scheme. Group each directed
    # pair by its source-camera station, as in the original source-image CI.
    common = np.logical_and.reduce(list(support.values()))
    positions = read(RT/'experiments/data_audit/images.json')
    lat0 = np.radians(positions[0]['GpsLatitude'])
    xy = np.array([[(r['GpsLongitude']-positions[0]['GpsLongitude'])*np.cos(lat0),
                    r['GpsLatitude']-positions[0]['GpsLatitude']] for r in positions])*np.pi/180*6378137
    _, _, vt = np.linalg.svd(xy[:576]-xy[:576].mean(axis=0), full_matrices=False)
    axis = vt[0]
    if axis@(xy[281]-xy[0]) < 0:
        axis = -axis
    station = xy@axis
    source_view = view[source]
    schemes = [('original_8_source_images', source_view//8, None, None)]
    for width in (16, 32, 64):
        for phase in (0, 0.5):
            group = np.floor((station[source_view]-station[:576].min())/width+phase).astype(int)
            schemes.append((f'spatial_{width}m_phase{phase:g}', group, width, phase))
    edges = np.geomspace(1e-3, 1e3, 6001)
    rows, contrasts = [], []
    for name, raw_group, width, phase in schemes:
        _, group = np.unique(raw_group[common], return_inverse=True)
        groups = int(group.max())+1
        # Nonempty clusters only, with identical paired resampling weights.
        rng = np.random.default_rng(20261023)
        weights = rng.multinomial(groups, np.full(groups, 1/groups), size=2000).astype(float)
        quantiles = {}
        for method, error in errors.items():
            values = error[common]
            hist = np.zeros((groups, 6000))
            for b in range(groups):
                hist[b] = np.histogram(np.clip(values[group == b], edges[0], np.nextafter(edges[-1], 0)), edges)[0]
            medians, p95s = [], []
            for offset in range(0, 2000, 100):
                cumulative = np.cumsum(weights[offset:offset+100]@hist, axis=1)
                for q, dest in ((0.5, medians), (0.95, p95s)):
                    index = np.argmax(cumulative >= q*cumulative[:, -1, None], axis=1)
                    dest.extend(np.sqrt(edges[index]*edges[index+1]))
            quantiles[method] = (np.array(medians), np.array(p95s))
            for statistic, point, samples in [('median', np.median(values), medians), ('p95', np.percentile(values, 95), p95s)]:
                lo, hi = np.percentile(samples, [2.5, 97.5])
                rows.append(dict(scheme=name, spatial_width_m=width, phase=phase, groups=groups,
                                 common_pairs=int(common.sum()), method=method, statistic=statistic,
                                 point_px=float(point), ci95_low_px=float(lo), ci95_high_px=float(hi)))
        for comparator in ('V2', 'A3', 'MVS1600'):
            for k, statistic in enumerate(('median', 'p95')):
                delta = quantiles['V3'][k]-quantiles[comparator][k]
                point = (np.quantile(errors['V3'][common], (0.5, 0.95)[k])-
                         np.quantile(errors[comparator][common], (0.5, 0.95)[k]))
                lo, hi = np.percentile(delta, [2.5, 97.5])
                contrasts.append(dict(scheme=name, groups=groups, common_pairs=int(common.sum()),
                                      contrast=f'V3_minus_{comparator}', statistic=statistic,
                                      point_px=float(point), ci95_low_px=float(lo), ci95_high_px=float(hi)))
        print('BOOTSTRAP', name, groups, flush=True)
    save_csv(OUT/'spatial_bootstrap_intervals.csv', rows)
    save_csv(OUT/'spatial_bootstrap_contrasts.csv', contrasts)
    result = dict(status='completed', seconds=time.monotonic()-started, gpu_hours=0,
                  fixed_inventory=len(source), common_pairs=int(common.sum()), resamples=2000, seed=20261023,
                  methods=list(errors), spatial_axis_east_north=axis.tolist(),
                  membership='Source-camera station on one common bridge axis; both passes in the same physical longitudinal bin',
                  source_sha256={str(mvs_path): sha(mvs_path), str(archive): receipt['sha256']},
                  limitations=['One bridge only. Spatial block intervals are conditional sensitivity estimates.',
                               'Long tracks and camera/anchor estimates can still correlate blocks; this does not establish independent external accuracy.',
                               'This common-six-method mask differs from individual main-paper table masks; all schemes here use the identical mask.',
                               'Original eight-image block geometry retained, with multinomial weights equivalent in distribution but not identical RNG draws to the historical integer-draw implementation.'])
    (OUT/'spatial_bootstrap_verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('BOOTSTRAP_COMPLETED', round(result['seconds'], 1), flush=True)


def seams_and_ranges():
    started = time.monotonic()
    frozen = {c: read(paths['run']/'frozen_parameters.json') for c, paths in CASES.items()}
    records = {c: {v['index']: v for v in read(paths['preparation']/'report.json')['views']} for c, paths in CASES.items()}
    cameras = {c: read(paths['preparation']/'native_cameras.json') for c, paths in CASES.items()}
    scales = read(ROOT/'revision_20261116/results/E1/E1_camera_alignment.json')['cases']
    headers = read(RT/'metadata/original_xmp_headers.json')
    laser = np.array([float(r['drone_dji']['LRFTargetDistance']) for r in headers[:576]])
    with np.load(RT/'metadata/c5_mvs_centre_windows.npz') as z:
        patch = z['depth'][:, 54:75, 54:75].astype(float)
    patch[~np.isfinite(patch) | (patch <= 0)] = np.nan
    flat = np.nanmax(patch, axis=(1, 2))-np.nanmin(patch, axis=(1, 2)) < 1
    assert flat.sum() == 271
    combined = {c: [] for c in CASES}
    metric = {c: [] for c in CASES}
    centre_depth = {c: np.full(576, np.nan) for c in CASES}
    per_seam = []
    previous = None
    for chunk_index, chunk in enumerate(frozen['C5']['chunks']):
        start = chunk['start']
        rows = {c: frozen[c]['chunks'][chunk_index] for c in CASES}
        assert all(r['start'] == start and r['image_indices'] == chunk['image_indices'] for r in rows.values())
        path = RT/MANIFEST['predictions']/f'chunk_{start:04d}'/'predictions.npz'
        with np.load(path) as z:
            data = dict(depth=z['depth'], confidence=z['depth_conf'])
        # Frozen ownership is the first chunk containing each photo.
        for case, row in rows.items():
            for j, index in enumerate(row['image_indices']):
                if index >= 576 or np.isfinite(centre_depth[case][index]):
                    continue
                dep = float(sample(data['depth'][j, ..., 0], [[258.5, 195.5]])[0])
                if dep > 0:
                    centre_depth[case][index] = dep*row['similarity']['scale']*row['depth_fit']['views'][j]['applied_scale']*scales[case]['fit_454_scale']
        if previous is not None:
            prior_data, prior_rows = previous
            h, w = data['depth'].shape[1:3]
            yy, xx = np.mgrid[2:h-2:8, 2:w-2:8]
            uv = np.c_[xx.ravel(), yy.ravel()]
            indices = sorted(set(chunk['image_indices']) & set(prior_rows['C5']['image_indices']))
            seam_values = {c: [] for c in CASES}
            seam_metres = {c: [] for c in CASES}
            inventory = 0
            for index in indices:
                pair = []
                valid = np.ones(len(uv), bool)
                for item, row in ((prior_data, prior_rows['C5']), (data, rows['C5'])):
                    j = row['image_indices'].index(index)
                    depth = item['depth'][j, yy, xx, 0].ravel()
                    confidence = item['confidence'][j, yy, xx].ravel()
                    valid &= np.isfinite(depth) & (depth > 0) & (confidence >= 1.2)
                    pair.append(depth)
                for case in CASES:
                    prep = CASES[case]['preparation']
                    with np.load(prep/records[case][index]['file']) as anchor:
                        median_z = float(np.median(anchor['train_z'][np.isfinite(anchor['train_z']) & (anchor['train_z'] > 0)]))
                        rays = native_rays(uv, cameras[case][str(int(anchor['camera_id']))], anchor['native_to_input'])
                    depth_pair = []
                    for depth, row in zip(pair, (prior_rows[case], rows[case])):
                        j = row['image_indices'].index(index)
                        depth_pair.append(depth*row['similarity']['scale']*row['depth_fit']['views'][j]['applied_scale'])
                    # Same camera ray and pose for both contexts: rotation and
                    # translation cancel in the Euclidean 3D discrepancy.
                    delta = abs(depth_pair[0]-depth_pair[1])*np.linalg.norm(rays, axis=1)
                    assert median_z > 0
                    seam_values[case].append(delta[valid]/median_z)
                    seam_metres[case].append(delta[valid]*scales[case]['fit_454_scale'])
                inventory += len(uv)
            for case in CASES:
                values, metres = np.concatenate(seam_values[case]), np.concatenate(seam_metres[case])
                combined[case].append(values)
                metric[case].append(metres)
                per_seam.append(dict(case=case, first_start=prior_rows[case]['start'], second_start=start,
                                     shared_images=len(indices), fixed_grid_samples=inventory,
                                     supported_samples=len(values), normalized_median=float(np.median(values)),
                                     normalized_p95=float(np.percentile(values, 95)),
                                     discrepancy_median_m=float(np.median(metres)), discrepancy_p95_m=float(np.percentile(metres, 95))))
        previous = (data, rows)
        if chunk_index % 12 == 0:
            print('SEAMS_CHUNK', chunk_index+1, flush=True)
    save_csv(OUT/'C5_C8_per_seam.csv', per_seam)
    range_rows = []
    result = dict(status='completed', gpu_hours=0, cases={},
                  semantics='Frozen C5/C8 V3, identical overlap grid/confidence support. C8 is post-hoc metadata-focal diagnostic; no laser-based scale correction.',
                  normalization='Each case uses its own positive training-anchor median per image, fixed across contexts. Metres use the 454-training-only RTK gauge.',
                  source_sha256={c: sha(paths['run']/'frozen_parameters.json') for c, paths in CASES.items()})
    for case in CASES:
        values, metres = np.concatenate(combined[case]), np.concatenate(metric[case])
        case_result = dict(seams=len(combined[case]), normalized=stats(values), metres=stats(metres), range={})
        for scope, mask in [('all', np.ones(576, bool)), ('flat', flat)]:
            good = mask & np.isfinite(centre_depth[case]) & (centre_depth[case] > 0)
            depth, lrf = centre_depth[case][good], laser[good]
            ratio = float(np.median(depth/lrf))
            case_result['range'][scope] = dict(n=int(good.sum()), bias_pct=100*(ratio-1),
                                             raw_signed_difference_m=stats(depth-lrf),
                                             raw_absolute_difference_m=stats(abs(depth-lrf)),
                                             after_ratio_removal_absolute_scatter_m=stats(abs(depth/ratio-lrf)))
        for index in range(576):
            range_rows.append(dict(case=case, image_index=index, frozen_flat=bool(flat[index]),
                                   depth_454_gauge_m=float(centre_depth[case][index]), lrf_m=float(laser[index]),
                                   uncorrected_difference_m=float(centre_depth[case][index]-laser[index])))
        result['cases'][case] = case_result
    result['seconds'] = time.monotonic()-started
    result['limitations'] = ['Seam agreement is conditional image-derived consistency, not external accuracy.',
                             'C8 focal length is nominal and the configuration was selected after inspecting the C5 discrepancy.',
                             'Common seam support covers V3 in the two configurations, not all four historical depth variants.',
                             'Range residuals include camera, scene, timing, beam and rangefinder errors; ratio removal is a separate in-sample diagnostic.']
    save_csv(OUT/'C5_C8_uncorrected_ranges.csv', range_rows)
    (OUT/'C5_C8_seam_range_verification.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('SEAMS_RANGES_COMPLETED', json.dumps(result['cases']), round(result['seconds'], 1), flush=True)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('task', choices=['bootstrap', 'seams'])
    args = ap.parse_args()
    OUT.mkdir(exist_ok=True)
    (bootstrap if args.task == 'bootstrap' else seams_and_ranges)()
