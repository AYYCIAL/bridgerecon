"""Continue the new SfM with the original accelerated incremental-BA settings."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import subprocess
import time
import zipfile
import numpy as np
import pycolmap

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--source', type=Path, required=True)
args = parser.parse_args()
args.out.mkdir(exist_ok=True)
runtime = json.loads((args.root / 'runtime_manifest.json').read_text())
survey = args.root / runtime['survey']
assert args.source.resolve().is_relative_to((survey / 'e6_followup_20261117').resolve())
assert args.source.name.startswith('E6_fresh_SfM_')
database = args.source / 'database.db'
assert database.is_file()
metadata = json.loads((survey / 'report.json').read_text())
names = {row['index']: row['name'] for row in metadata['images']}
with np.load(args.root / runtime['case_paths']['C0']['preparation'] / 'global_cameras.npz') as data:
    required = {names[int(index)] for index in data['image_indices']}
prefix = Path('/content/colmap313')
executable = prefix / 'bin/colmap'
environment = dict(os.environ, QT_QPA_PLATFORM='offscreen',
                   LD_LIBRARY_PATH=str(prefix / 'lib') + ':' + os.environ.get('LD_LIBRARY_PATH', ''))
started = time.monotonic()
case = dict(status='running', source=str(args.source), original_camera_poses_used=False,
            scope='Continuation of this new SfM, using the archived incremental optimizer overrides. Final training-only camera refinement is a separate stage.',
            passes=[], chunk_checkpoints=[])
seen = set()


def write(path, value):
    temporary = path.with_suffix('.partial')
    temporary.write_text(json.dumps(value, indent=2))
    temporary.replace(path)


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            digest.update(block)
    return digest.hexdigest()


def read_stable_model(folder):
    files = [folder / name for name in ['cameras.bin', 'images.bin', 'points3D.bin']]
    if not all(path.is_file() for path in files):
        return None
    before = [(path.stat().st_size, path.stat().st_mtime_ns) for path in files]
    try:
        model = pycolmap.Reconstruction(str(folder))
    except Exception:
        return None
    after = [(path.stat().st_size, path.stat().st_mtime_ns) for path in files]
    return model if before == after else None


def coverage(folder):
    model = read_stable_model(folder)
    if model is None:
        return (0, 0)
    registered = {model.images[index].name for index in model.reg_image_ids()}
    return len(required & registered), len(registered)


def checkpoint():
    for path in sorted((args.out / 'snapshots').rglob('images.bin')):
        if str(path) in seen:
            continue
        model = read_stable_model(path.parent)
        if model is None:
            continue
        files = list(path.parent.glob('*.bin'))
        before = [(file.stat().st_size, file.stat().st_mtime_ns) for file in files]
        target = Path('/content/cpu_supplement_checkpoints') / f'Supplement_{args.out.name}_sfm_{model.num_reg_images():04d}_{sha(path)[:8]}.zip'
        temporary = target.with_suffix('.partial')
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=1) as archive:
            for file in files:
                archive.write(file, 'sparse/' + file.name)
        after = [(file.stat().st_size, file.stat().st_mtime_ns) for file in files]
        if before != after:
            temporary.unlink()
            continue
        temporary.replace(target)
        case['chunk_checkpoints'].append(dict(name=target.name, bytes=target.stat().st_size,
            sha256=sha(target), registered_images=model.num_reg_images()))
        seen.add(str(path))
    write(args.out / 'progress.json', dict(completed_chunks=len(case['chunk_checkpoints']),
        chunk_checkpoints=case['chunk_checkpoints']))


try:
    candidates = [path.parent for path in args.source.rglob('images.bin')]
    assert candidates
    best = max(candidates, key=coverage)
    assert coverage(best)[0] > 2
    case['initial_model'] = str(best)
    case['initial_coverage'] = coverage(best)[0]
    help_result = subprocess.run([str(executable), 'mapper', '-h'], capture_output=True, text=True, env=environment)
    help_text = help_result.stdout + help_result.stderr
    for option in ['ba_use_gpu', 'ba_global_function_tolerance', 'ba_global_max_num_iterations',
                   'ba_global_max_refinements', 'ba_global_frames_ratio', 'ba_global_points_ratio']:
        assert 'Mapper.' + option in help_text, option
    (args.out / 'snapshots').mkdir(exist_ok=True)
    for attempt in range(8):
        if coverage(best)[0] == len(required):
            break
        output = args.out / f'mapping_{attempt}'
        output.mkdir()
        command = [str(executable), 'mapper', '--database_path', str(database),
            '--image_path', str(survey / 'images'), '--output_path', str(output),
            '--input_path', str(best), '--Mapper.num_threads', '8',
            '--Mapper.max_runtime_seconds', '1800', '--Mapper.snapshot_path', str(args.out / 'snapshots'),
            '--Mapper.snapshot_frames_freq', '15', '--Mapper.ba_use_gpu', '1',
            '--Mapper.ba_global_function_tolerance', '1e-5', '--Mapper.ba_global_max_num_iterations', '25',
            '--Mapper.ba_global_max_refinements', '2', '--Mapper.ba_global_frames_ratio', '1.25',
            '--Mapper.ba_global_points_ratio', '1.25']
        tick = time.monotonic()
        before = coverage(best)[0]
        row = dict(command=command, initial_coverage=before, status='running')
        case['passes'].append(row)
        write(args.out / 'case.json', case)
        with (args.out / f'mapping_{attempt}.log').open('w') as log:
            process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=environment)
            try:
                while process.poll() is None:
                    checkpoint()
                    if time.monotonic() - tick > 2100:
                        raise TimeoutError('Mapper exceeded its 30-minute segment plus five-minute optimizer completion allowance')
                    time.sleep(5)
            finally:
                if process.poll() is None:
                    process.send_signal(signal.SIGINT)
                    try:
                        process.wait(30)
                    except subprocess.TimeoutExpired:
                        process.terminate()
                        process.wait(20)
        row.update(seconds=time.monotonic() - tick, exit_code=process.returncode)
        checkpoint()
        candidates = [best] + [path.parent for path in output.rglob('images.bin')]
        candidates += [path.parent for path in (args.out / 'snapshots').rglob('images.bin')]
        best = max(candidates, key=coverage)
        row.update(status='completed', registered_required=coverage(best)[0])
        write(args.out / 'case.json', case)
        assert process.returncode == 0, 'Mapper failed, saved snapshots retained'
        if coverage(best)[0] <= before:
            raise RuntimeError('No additional required cameras registered during a full mapper segment')
    model = pycolmap.Reconstruction(str(best))
    destination = args.out / 'sparse'
    destination.mkdir()
    model.write(str(destination))
    registered = {model.images[index].name for index in model.reg_image_ids()}
    missing = sorted(required - registered)
    case.update(status='completed' if not missing else 'completed_unsupported', model=str(destination),
        registered_images=model.num_reg_images(), missing_required_images=missing,
        continuation_seconds=sum(row['seconds'] for row in case['passes']), source_database_sha256=sha(database))
except BaseException as error:
    case.update(status='failed', error_type=type(error).__name__, error=str(error)[:2000])
    raise
finally:
    case['seconds'] = time.monotonic() - started
    write(args.out / 'case.json', case)
print('FRESH_SFM_CONTINUATION_COMPLETED', flush=True)
