"""Linux worker reusing frozen scientific functions with explicit portable paths."""
from pathlib import Path, PureWindowsPath
import argparse
import importlib
import json
import os
import sys
import time
import numpy as np

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--mode', choices=['hybrid', 'ba', 'export'], required=True)
p.add_argument('--preparation', type=Path)
p.add_argument('--control', type=Path)
p.add_argument('--sigma', type=float, default=.1)
p.add_argument('--focal', type=float)
p.add_argument('--resume', type=Path)
p.add_argument('--iterations', type=int, default=400)
p.add_argument('--solver-seconds', type=float, default=1500.)
p.add_argument('--threads', type=int, default=min(os.cpu_count() or 2,8))
args = p.parse_args()
assert 1 <= args.iterations <= 1000 and 0 < args.solver_seconds <= 1500 and 1 <= args.threads <= 8
ROOT = args.root.resolve()
EXP = ROOT/'experiments'
sys.path.insert(0, str(EXP))
deadline = time.monotonic() + 1750


def check_window(seconds):
    # Finite deadline of the cloud batch, independent of the local daily schedule.
    if time.monotonic() + seconds > deadline:
        raise TimeoutError('Colab worker deadline reached')
    return {'authorization': None,
            'platform': 'Linux', 'worker_max_seconds': 1750}


def relocated(value):
    if isinstance(value, str):
        old = PureWindowsPath(os.environ.get('BRIDGERECON_ARCHIVED_ROOT', 'C:/bridgerecon'))  # root recorded in archived reports
        if value.startswith('/content/bridgerecon/'):
            return str(ROOT / value.removeprefix('/content/bridgerecon/'))
        path = PureWindowsPath(value)
        if path.is_absolute():
            try:
                path.relative_to(PureWindowsPath(ROOT))
                return value
            except ValueError:
                pass
            try:
                return str(ROOT.joinpath(*path.relative_to(old).parts))
            except ValueError:
                return value
        if '\\' in value and not PureWindowsPath(value).drive and PureWindowsPath(value).suffix.lower() in {
                '.npz', '.json', '.bin', '.jpg', '.png', '.ply', '.py', '.txt', '.csv'}:
            return PureWindowsPath(value).as_posix()
    elif isinstance(value, list):
        return [relocated(v) for v in value]
    elif isinstance(value, dict):
        return {k: relocated(v) for k, v in value.items()}
    return value


def read(path):
    return relocated(json.loads(Path(path).read_text(encoding='utf-8')))


import work_schedule
work_schedule.require_start_window = check_window
import local_validation
from historical_sampling import sample as historical_sample
local_validation.sample = historical_sample
args.out.mkdir(parents=True, exist_ok=True)
if args.mode == 'hybrid':
    module = importlib.import_module('run_global_hybrid')
    module.read = read
    module.require_start_window = check_window
    runtime = read(ROOT/'runtime_manifest.json')
    module.worker(args.preparation.resolve(), [ROOT/runtime['predictions']], None, args.out.resolve())
    import hashlib
    source = Path(__file__).with_name('historical_sampling.py')
    report = read(args.out/'report.json')
    report['sampling_compatibility'] = {
        'method': 'Exact bilinear at float32 query coordinates, zero extension',
        'basis': 'Saved manuscript arrays and calibration-coefficient audit; cv2 INTER_LINEAR quantizes queries',
        'compatibility_source_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
    (args.out/'report.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
elif args.mode == 'ba':
    base = importlib.import_module('run_navigation_prior_ba')
    base.read = read
    module = importlib.import_module('run_rtk_weighted_ba')
    original_source_bytes = Path(module.__file__).read_bytes()
    original_source = original_source_bytes.decode('utf-8-sig')
    updated_source = original_source.replace('options.solver_options.num_threads = 4',
        f'options.solver_options.num_threads = {args.threads}')
    assert updated_source != original_source or args.threads == 4
    exec(compile(updated_source, module.__file__, 'exec'), module.__dict__)
    module.read = read
    module.require_start_window = check_window
    module.worker(args.out.resolve(), args.sigma, args.sigma, 30., args.iterations, args.solver_seconds,
                  dry_run=False, resume=args.resume.resolve() if args.resume else None, fixed_focal=args.focal)
    import hashlib
    report = read(args.out/'report.json')
    report['colab_runtime'] = {'cpu_count':os.cpu_count(),'solver_threads':args.threads,
        'source_sha256':hashlib.sha256(original_source_bytes).hexdigest(),
        'thread_configuration_overlay_sha256':hashlib.sha256(updated_source.encode()).hexdigest()}
    (args.out/'report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
else:
    module = importlib.import_module('export_hybrid_model_anchors')
    module.require_start_window = check_window
    module.worker(args.control.resolve(), args.out.resolve())
