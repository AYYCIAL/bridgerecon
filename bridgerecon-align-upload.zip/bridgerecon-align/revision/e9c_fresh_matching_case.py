"""E9c: freshly match the ten oblique photographs, then retry their registration.

Features are reused from the original survey database, which was built with the same
SIFT extraction as the survey. Every existing match touching an oblique view is
deleted. The views are then re-matched with the COLMAP 3.13 CUDA matcher (guided
matching) against every image of the C5 model and against each other. Registration is
retried, with existing camera poses fixed, against two targets:
  (a) the C5 training-only model, the same target as the cached-feature attempt;
  (b) the same C5 model after triangulating every registered image from all database
      correspondences (poses unchanged), which gives the most 2D-3D support.
Working databases stay outside the job folder, so the archived result remains small.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import resource
import shutil
import sqlite3
import subprocess
import tarfile
import time
import urllib.request
import numpy as np
import pycolmap

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
runtime = json.loads((args.root / 'runtime_manifest.json').read_text())
survey = args.root / runtime['survey']
assert args.out.resolve().is_relative_to(survey.resolve())
args.out.mkdir(exist_ok=True)
work = Path('/content/e9c_work') / args.out.name
work.mkdir(parents=True, exist_ok=True)
os.chdir(survey)
started = time.monotonic()
prefix = Path('/content/colmap313')
exe = prefix / 'bin/colmap'
env = dict(os.environ, QT_QPA_PLATFORM='offscreen',
           LD_LIBRARY_PATH=str(prefix / 'lib') + ':' + os.environ.get('LD_LIBRARY_PATH', ''))
MAX_IMAGE_ID = 2147483647
VALID_CONFIGS = {2, 3, 4, 5, 6}  # calibrated, uncalibrated, planar, panoramic, planar-or-panoramic
case = dict(status='running', stages=[],
            scope='E9c fresh oblique matching (original features, all oblique matches recomputed with the '
                  'COLMAP 3.13 CUDA guided matcher) and pose registration with existing poses fixed',
            fresh_feature_or_descriptor_matching=True, features_reused_from_original_database=True)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b''):
            digest.update(block)
    return digest.hexdigest()


def save(phase=None):
    case.update(seconds=time.monotonic() - started, peak_rss_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024)
    temporary = args.out / 'case.json.partial'
    temporary.write_text(json.dumps(case, indent=2, default=str))
    temporary.replace(args.out / 'case.json')
    if phase:
        case['phase'] = phase
    temporary = args.out / 'progress.json.partial'
    temporary.write_text(json.dumps(dict(completed_chunks=len(case['stages']), phase=case.get('phase'))))
    temporary.replace(args.out / 'progress.json')


def command(name, arguments, limit):
    tick = time.monotonic()
    with (args.out / (name + '.log')).open('w') as log:
        result = subprocess.run(arguments, stdout=log, stderr=subprocess.STDOUT, env=env, timeout=limit)
    case['stages'].append(dict(name=name, seconds=time.monotonic() - tick, exit_code=result.returncode))
    save()
    assert result.returncode == 0, name + ' failed'


def split_pair(pair_id):
    second = pair_id % MAX_IMAGE_ID
    return int((pair_id - second) // MAX_IMAGE_ID), int(second)


def registered_points(model, image_id):
    return sum(1 for point in model.images[image_id].points2D if point.has_point3D())


try:
    metadata = json.loads((survey / 'report.json').read_text())
    oblique_names = sorted(row['name'] for row in metadata['images'] if 576 <= row['index'] <= 585)
    assert len(oblique_names) == 10
    c5_path = args.root / runtime['case_paths']['C5']['preparation'] / 'fitted_sparse'
    models = {'C5_training_only': (c5_path, False), 'C5_retriangulated_all_tracks': (c5_path, True)}
    original = survey / 'database.db'
    original_hash = sha(original)
    database = work / 'e9c_database.db'
    shutil.copy2(original, database)
    with sqlite3.connect(database) as connection:
        images = connection.execute('SELECT image_id,name,camera_id FROM images').fetchall()
    id_by_name = {name: image_id for image_id, name, _ in images}
    name_by_id = {image_id: name for image_id, name, _ in images}
    camera_by_id = {image_id: camera_id for image_id, _, camera_id in images}
    oblique_ids = {id_by_name[name] for name in oblique_names}
    c5_model = pycolmap.Reconstruction(c5_path.relative_to(survey).as_posix())
    partners = sorted(c5_model.images[image_id].name for image_id in c5_model.reg_image_ids())
    del c5_model
    assert not set(partners) & set(oblique_names)
    case.update(oblique_images=oblique_names, partner_images=len(partners), source_database_sha256=original_hash)

    def verified_stats(connection):
        stats = {name: dict(verified_pairs_15=0, max_inliers=0, top_partners=[]) for name in oblique_names}
        for pair_id, count, config in connection.execute('SELECT pair_id,rows,config FROM two_view_geometries'):
            first, second = split_pair(pair_id)
            for this, other in [(first, second), (second, first)]:
                if this in oblique_ids and config in VALID_CONFIGS:
                    row = stats[name_by_id[this]]
                    row['max_inliers'] = max(row['max_inliers'], int(count))
                    row['verified_pairs_15'] += int(count >= 15)
                    row['top_partners'].append((int(count), name_by_id[other]))
        for row in stats.values():
            row['top_partners'] = sorted(row['top_partners'], reverse=True)[:5]
        return stats

    with sqlite3.connect(database) as connection:
        case['before_cached_matches'] = verified_stats(connection)
        removed = {}
        for table in ['matches', 'two_view_geometries']:
            drop = [(pair_id,) for (pair_id,) in connection.execute(f'SELECT pair_id FROM {table}')
                    if set(split_pair(pair_id)) & oblique_ids]
            connection.executemany(f'DELETE FROM {table} WHERE pair_id=?', drop)
            removed[table] = len(drop)
        connection.commit()
    case['removed_cached_rows'] = removed
    pairs = [f'{oblique} {partner}' for oblique in oblique_names for partner in partners]
    pairs += [f'{oblique_names[i]} {oblique_names[j]}' for i in range(10) for j in range(i + 1, 10)]
    pairs_path = args.out / 'pairs_e9c.txt'
    pairs_path.write_text('\n'.join(pairs) + '\n')
    case['candidate_pairs'] = len(pairs)
    save('environment')

    if not exe.exists():
        archive = Path('/content/micromamba.tar.bz2')
        if not Path('/content/micromamba_cli/bin/micromamba').exists():
            with urllib.request.urlopen('https://micro.mamba.pm/api/micromamba/linux-64/latest', timeout=120) as response:
                with archive.open('wb') as stream:
                    shutil.copyfileobj(response, stream, length=1024**2)
            with tarfile.open(archive) as compressed:
                compressed.extract(compressed.getmember('bin/micromamba'), '/content/micromamba_cli')
        command('environment', ['/content/micromamba_cli/bin/micromamba', 'create', '-y', '-p', str(prefix),
                                '-c', 'conda-forge', 'colmap=3.13.0=cuda_126h79fc88e_0'], 1500)
    version = subprocess.run([str(exe), '-h'], capture_output=True, text=True, env=env).stdout
    assert '3.13.0' in version and 'CUDA' in version
    case['colmap_version_header'] = version.splitlines()[:4]
    save('fresh_matching')
    command('fresh_matching', [str(exe), 'matches_importer', '--database_path', str(database),
                               '--match_list_path', str(pairs_path), '--match_type', 'pairs',
                               '--FeatureMatching.use_gpu', '1', '--FeatureMatching.num_threads', '8',
                               '--FeatureMatching.guided_matching', '1'], 2400)
    with sqlite3.connect(database) as connection:
        case['after_fresh_matching'] = verified_stats(connection)
    case['images_with_any_verified_pair_15'] = sum(row['verified_pairs_15'] > 0 for row in case['after_fresh_matching'].values())
    save('registration')

    registration = {}
    for label, (model_path, retriangulate) in models.items():
        tick = time.monotonic()
        model = pycolmap.Reconstruction(model_path.relative_to(survey).as_posix())
        initial = {image_id: model.images[image_id].cam_from_world.matrix().copy() for image_id in model.reg_image_ids()}
        parameters = model.cameras[1].params.copy()
        trial_database = work / f'registration_{label}.db'
        shutil.copy2(database, trial_database)
        with sqlite3.connect(trial_database) as connection:
            for camera_id in sorted({camera_by_id[image_id] for image_id in oblique_ids}):
                if camera_id not in model.cameras:
                    model_id, width, height = connection.execute(
                        'SELECT model,width,height FROM cameras WHERE camera_id=?', (camera_id,)).fetchone()
                    assert model_id == 2 and width == 1600 and height == 1200
                    model.add_camera(pycolmap.Camera(model='SIMPLE_RADIAL', width=width, height=height,
                                                     params=parameters.copy(), camera_id=camera_id))
                camera = model.cameras[camera_id]
                assert camera.model.name == 'SIMPLE_RADIAL' and camera.width == 1600 and camera.height == 1200
                camera.params = parameters.copy()
                connection.execute('UPDATE cameras SET params=?,prior_focal_length=1 WHERE camera_id=?',
                                   (parameters.astype(np.float64).tobytes(), camera_id))
            connection.commit()
        with pycolmap.Database(trial_database.as_posix()) as connection:
            cache = pycolmap.DatabaseCache.create(connection, 15, False, set())
        mapper = pycolmap.IncrementalMapper(cache)
        mapper.begin_reconstruction(model)
        options = pycolmap.IncrementalMapperOptions()
        options.num_threads = 8
        triangulation = pycolmap.IncrementalTriangulatorOptions()
        points_before = len(model.points3D)
        if retriangulate:
            for image_id in sorted(initial):
                mapper.triangulate_image(triangulation, image_id)
        points_after_retriangulation = len(model.points3D)
        print('E9C_TARGET_POINTS', label, points_before, points_after_retriangulation, flush=True)
        trials, added = [], []
        pending = sorted(oblique_ids)
        for round_index in range(3):
            progress = False
            for image_id in list(pending):
                ok = bool(mapper.register_next_image(options, image_id))
                trials.append(dict(round=round_index, name=name_by_id[image_id], registered=ok))
                print('E9C_REGISTRATION_TRIAL', label, round_index, name_by_id[image_id], ok, flush=True)
                if ok:
                    mapper.triangulate_image(triangulation, image_id)
                    added.append(name_by_id[image_id])
                    pending.remove(image_id)
                    progress = True
            if not progress or not pending:
                break
        mapper.end_reconstruction(False)
        unchanged = all(np.array_equal(model.images[image_id].cam_from_world.matrix(), matrix)
                        for image_id, matrix in initial.items())
        row = dict(model=str(model_path), retriangulated_all_tracks=retriangulate,
                   target_points3D_before=points_before, target_points3D_after_retriangulation=points_after_retriangulation,
                   initial_registered_images=len(initial), trials=trials,
                   added_oblique_images=added, added_oblique_count=len(added),
                   existing_camera_poses_unchanged=unchanged, seconds=time.monotonic() - tick)
        if added:
            destination = args.out / f'sparse_{label}'
            destination.mkdir()
            model.write(destination.relative_to(survey).as_posix())
            row['expanded_model'] = str(destination)
            row['oblique_registered_points3D'] = {name: registered_points(model, id_by_name[name]) for name in added}
        registration[label] = row
        case['registration'] = registration
        case['stages'].append(dict(name=f'registration_{label}', seconds=row['seconds']))
        save()
        del mapper, cache, model
    any_added = any(row['added_oblique_count'] for row in registration.values())
    case.update(status='completed', original_database_unchanged=sha(original) == original_hash,
                pending=['C5 refit with the added oblique views, then the fixed-core evaluation'] if any_added else [],
                interpretation=('Some oblique views registered after fresh matching; a C5 refit can now test whether '
                                'oblique views constrain the focal length') if any_added else
                               ('No oblique view registered even after fresh guided matching against every C5 image; '
                                'report as a failed registration, consistent with the earlier cached-feature attempt'))
    assert case['original_database_unchanged']
except BaseException as error:
    case.update(status='failed', error_type=type(error).__name__, error=str(error)[:1500])
    raise
finally:
    save('finished')
    shutil.rmtree(work, ignore_errors=True)
print('E9C_FRESH_MATCHING_CASE_COMPLETED', flush=True)
