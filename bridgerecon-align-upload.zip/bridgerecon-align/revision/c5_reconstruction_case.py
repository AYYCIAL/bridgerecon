"""Apply the archived training-only C5 pipeline to a new model or image subset."""
from pathlib import Path, PureWindowsPath
import argparse
import hashlib
import importlib
import json
import os
import runpy
import shutil
import sys
import time
import numpy as np
import pycolmap
from scipy.spatial import cKDTree

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--model', type=Path)
parser.add_argument('--subset', choices=['full', 'remove_low', 'outbound', 'inbound', 'every2', 'every4'], default='full')
parser.add_argument('--predictions', type=Path)
parser.add_argument('--threads', type=int, default=2)
parser.add_argument('--independent-initializer', action='store_true')
args = parser.parse_args()
root, out = args.root.resolve(), args.out.resolve()
runtime = json.loads((root / 'runtime_manifest.json').read_text(encoding='utf-8'))
survey = root / runtime['survey']
assert out.is_relative_to(survey)
out.mkdir(exist_ok=True)
os.chdir(survey)
experiments = root / 'experiments'
sys.path.insert(0, str(experiments))
old_root = PureWindowsPath(runtime['old_absolute_root'])


def relocate(value):
    if isinstance(value, dict):
        return {key: relocate(item) for key, item in value.items()}
    if isinstance(value, list):
        return [relocate(item) for item in value]
    if isinstance(value, str):
        if value.startswith('/content/bridgerecon/'):
            return str(root / value.removeprefix('/content/bridgerecon/'))
        path = PureWindowsPath(value)
        if path.is_absolute():
            try:
                path.relative_to(PureWindowsPath(root))
                return value
            except ValueError:
                pass
            try:
                return str(root.joinpath(*path.relative_to(old_root).parts))
            except ValueError:
                return value
        if '\\' in value and path.suffix:
            return path.as_posix()
    return value


def read(path):
    return relocate(json.loads(Path(path).read_text(encoding='utf-8')))


def write(path, value):
    temporary = path.with_suffix('.partial')
    temporary.write_text(json.dumps(value, indent=2), encoding='utf-8')
    temporary.replace(path)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            digest.update(block)
    return digest.hexdigest()


started = time.monotonic()
case = dict(status='running', subset=args.subset, stages=[], initializer_used_checking_observations=not args.independent_initializer)


def stage(name, function):
    tick = time.monotonic()
    print('C5_STAGE_STARTED', name, flush=True)
    function()
    case['stages'].append(dict(name=name, seconds=time.monotonic() - tick))
    write(out / 'case.json', case)
    print('C5_STAGE_COMPLETED', name, flush=True)


try:
    original = root / runtime['case_paths']['C0']['preparation']
    preparation_report = read(original / 'report.json')
    with np.load(original / 'global_cameras.npz') as archive:
        old_indices = archive['image_indices'].astype(int)
    metadata = read(survey / 'report.json')
    index_by_name = {row['name']: row['index'] for row in metadata['images']}
    selected_indices = set(map(int, old_indices))
    if args.subset == 'remove_low':
        selected_indices -= {586, 587}
    if args.subset == 'outbound':
        selected_indices &= set(range(282))
    if args.subset == 'inbound':
        selected_indices &= set(range(282, 574))
    if args.subset in ['every2', 'every4']:
        stride = int(args.subset[-1])
        selected_indices = {index for index in selected_indices if index >= 576 or index % stride == 0}
    initial = args.model.resolve() if args.model else original / 'fitted_sparse'
    initial_hash = {name: sha(initial / name) for name in ['cameras.bin', 'images.bin', 'points3D.bin']}
    model = pycolmap.Reconstruction(initial.relative_to(survey).as_posix())
    registered = {index_by_name[model.images[index].name] for index in model.reg_image_ids()}
    assert selected_indices <= registered, sorted(selected_indices - registered)
    for image_id in list(model.reg_image_ids()):
        if index_by_name[model.images[image_id].name] not in selected_indices:
            model.deregister_image(image_id)
    filtered_model = out / 'registered_subset'
    filtered_model.mkdir()
    model.write(filtered_model.relative_to(survey).as_posix())
    del model
    model = pycolmap.Reconstruction(filtered_model.relative_to(survey).as_posix())
    images = sorted(model.images.values(), key=lambda image: index_by_name[image.name])
    indices = np.array([index_by_name[image.name] for image in images])
    assert set(map(int, indices)) == selected_indices
    with np.load(original / 'global_checking_tracks.npz') as archive:
        tracks = {key: archive[key].copy() for key in archive.files}
    old_to_new = {slot: int(np.flatnonzero(indices == index)[0]) for slot, index in enumerate(old_indices) if index in selected_indices}
    selected_obs = np.isin(tracks['view_slot'], list(old_to_new))
    tracks['view_slot'] = np.array([old_to_new[int(slot)] for slot in tracks['view_slot'][selected_obs]])
    for key in ['point_slot', 'native_uv']:
        tracks[key] = tracks[key][selected_obs]
    # Frozen evaluation IDs retain their ordering. New training IDs use a disjoint namespace.
    if args.model:
        tracks['point_ids'] = tracks['point_ids'] + 1_000_000_000
        assert tracks['point_ids'].max() < np.iinfo(np.int32).max
    checking_ids = set(map(int, tracks['point_ids']))
    training_ids = set(model.points3D) - checking_ids
    excluded = set()
    if args.model:
        for slot, image in enumerate(images):
            checking_uv = tracks['native_uv'][tracks['view_slot'] == slot]
            observations = [(point.point3D_id, point.xy) for point in image.points2D if point.has_point3D()]
            if not len(checking_uv) or not observations:
                continue
            ids = np.array([row[0] for row in observations], dtype=np.int64)
            uv = np.array([row[1] for row in observations])
            distance = cKDTree(checking_uv).query(uv)[0]
            excluded.update(map(int, ids[distance <= 1e-4]))
        training_ids -= excluded
    assert not training_ids.intersection(checking_ids)
    rng = np.random.default_rng(20261019)
    keep = set(training_ids)
    if args.model:
        keep = set(map(int, rng.choice(sorted(training_ids), min(20000, len(training_ids)), replace=False)))
    for image in images:
        visible = sorted({point.point3D_id for point in image.points2D if point.has_point3D() and point.point3D_id in training_ids})
        have = sum(point_id in keep for point_id in visible)
        for point_id in visible:
            if have >= min(200, len(visible)):
                break
            if point_id not in keep:
                keep.add(point_id)
                have += 1
    for point_id in list(model.points3D):
        if point_id not in keep:
            model.delete_point3D(point_id)
    assert keep and set(model.points3D) == keep
    private = out / 'private_preparation'
    private.mkdir()
    (private / 'fitted_sparse').mkdir()
    model.write((private / 'fitted_sparse').relative_to(survey).as_posix())
    np.savez_compressed(private / 'split.npz', all_ids=np.array(sorted(training_ids | checking_ids)),
        checking_ids=tracks['point_ids'], training_available_ids=np.array(sorted(training_ids)),
        selected_training_ids=np.array(sorted(keep)))
    np.savez_compressed(private / 'global_checking_tracks.npz', **tracks)
    np.savez_compressed(private / 'global_cameras.npz', image_indices=indices)
    preparation_report.update(status='completed', source_model=str(initial), source_sha256=initial_hash,
        registered_cameras=len(images), source_points=len(training_ids), checking_points=len(checking_ids),
        selected_training_points=len(keep), checking_observations=len(tracks['native_uv']),
        initialization_used_checking_tracks=not args.independent_initializer,
        scope='Frozen evaluation observations, isolated training refit and depth calibration',
        source_unchanged=True)
    write(private / 'report.json', preparation_report)
    case.update(selected_image_indices=indices.tolist(), excluded_training_tracks_touching_evaluation=len(excluded),
        training_points=len(keep), source_model=str(initial), source_model_sha256=initial_hash)
    del model, images
    import work_schedule
    work_schedule.require_start_window = lambda seconds: None
    import local_validation
    from historical_sampling import sample
    local_validation.sample = sample
    base = importlib.import_module('run_navigation_prior_ba')
    source = Path(base.__file__).read_text(encoding='utf-8-sig')
    previous = "initial_model=resume/'sparse' if resume else PREP/'fitted_sparse'"
    assert source.count(previous) == 1
    overlay = source.replace(previous, "initial_model=resume/'sparse' if resume else C5_INITIAL_MODEL")
    overlay = overlay.replace('options.solver_options.num_threads=4', f'options.solver_options.num_threads={args.threads}')
    exec(compile(overlay, base.__file__, 'exec'), base.__dict__)
    base.read, base.SOURCE, base.PREP = read, survey, private
    base.C5_INITIAL_MODEL = private / 'fitted_sparse'
    gauge = out / 'training_gauge_ba'
    gauge.mkdir()
    stage('training_only_gauge_ba', lambda: base.worker(gauge, 0., iterations=100, solver_seconds=300.))
    base.C5_INITIAL_MODEL = gauge / 'sparse'
    control = out / 'control'
    control.mkdir()
    stage('C5_navigation_ba', lambda: base.worker(control, 10., iterations=400, solver_seconds=300.,
        share_camera=True, height_sigma=1., quadratic_position=True))
    control_report = read(control / 'report.json')
    if 'NO_CONVERGENCE' in control_report['solver']['termination']:
        continued = out / 'control_continued'
        continued.mkdir()
        stage('C5_navigation_ba_continuation', lambda: base.worker(continued, 10., resume=control,
            iterations=400, solver_seconds=300., share_camera=True, height_sigma=1., quadratic_position=True))
        control = continued
        control_report = read(control / 'report.json')
    assert control_report['solver']['solution_usable'] and 'NO_CONVERGENCE' not in control_report['solver']['termination']
    export = importlib.import_module('export_hybrid_model_anchors')
    export.ORIGINAL, export.SOURCE = private, survey
    # finish_export checks these exact input hashes after all output has been written.
    import prepare_global_hybrid
    prepare_global_hybrid.MODEL = initial
    preparation = out / 'preparation'
    preparation.mkdir()
    stage('anchor_export', lambda: export.worker(control, preparation))
    predictions = args.predictions.resolve() if args.predictions else root / runtime['predictions']
    prediction_report = read(predictions / 'report.json')
    starts = None
    if args.subset != 'full':
        subset_predictions = out / 'subset_predictions'
        subset_predictions.mkdir()
        chunks = []
        for chunk in prediction_report['chunks']:
            if args.subset in ['outbound', 'inbound'] and chunk['start'] in [272, 280]:
                continue
            slots = [slot for slot, index in enumerate(chunk['image_indices']) if index in selected_indices]
            if len(slots) < 2:
                continue
            source_path = predictions / chunk['prediction']
            assert sha(source_path) == chunk['sha256']
            destination = subset_predictions / f'chunk_{chunk["start"]:04d}'
            destination.mkdir()
            with np.load(source_path) as archive:
                arrays = {key: archive[key][slots] if archive[key].ndim and len(archive[key]) == len(chunk['image_indices']) else archive[key] for key in archive.files}
            np.savez_compressed(destination / 'predictions.npz', **arrays)
            row = dict(chunk, image_indices=[chunk['image_indices'][slot] for slot in slots],
                prediction=f'chunk_{chunk["start"]:04d}/predictions.npz',
                sha256=sha(destination / 'predictions.npz'), original_slots=slots,
                original_sha256=chunk['sha256'])
            chunks.append(row)
        assert chunks
        prediction_report.update(chunks=chunks, status='completed', subset=args.subset,
            source_predictions=str(predictions), no_new_inference=True)
        write(subset_predictions / 'report.json', prediction_report)
        predictions = subset_predictions
    hybrid = importlib.import_module('run_global_hybrid')
    hybrid.read = read
    hybrid.require_start_window = lambda seconds: None
    hybrid_out = out / 'hybrid'
    hybrid_out.mkdir()
    stage('research_calibration_and_evaluation', lambda: hybrid.worker(preparation, [predictions], starts, hybrid_out))
    hybrid_report = read(hybrid_out / 'report.json')
    assert hybrid_report['status'] == 'completed', hybrid_report['status']
    reference_hybrid = root / runtime['case_paths']['C5']['run']
    if args.subset != 'full':
        reference_hybrid = out / 'C5_same_image_contexts'
        reference_hybrid.mkdir()
        stage('C5_baseline_on_same_retained_contexts', lambda: hybrid.worker(
            root / runtime['case_paths']['C5']['preparation'], [predictions], starts, reference_hybrid))
    def summarize():
        sys.argv = ['cpu_case_summary.py', '--root', str(root), '--control', str(control),
            '--preparation', str(preparation), '--hybrid', str(hybrid_out), '--out', str(out / 'summary.json'),
            '--reference-hybrid', str(reference_hybrid)]
        if args.subset != 'full':
            sys.argv.append('--allow-subset')
        runpy.run_path(str(Path(__file__).with_name('cpu_case_summary.py')), run_name='__main__')
    stage('fixed_inventory_and_navigation_summary', summarize)
    case.update(status='completed', control=str(control), preparation=str(preparation), hybrid=str(hybrid_out),
        source_unchanged=all(sha(initial / name) == digest for name, digest in initial_hash.items()),
        ba_source_sha256=hashlib.sha256(source.encode()).hexdigest(),
        ba_overlay_sha256=hashlib.sha256(overlay.encode()).hexdigest(),
        hybrid_summary=hybrid_report['metrics']['view_depth_scale'],
        summary=read(out / 'summary.json'),
        depth_evaluation_images=hybrid_report['unique_photos'])
    assert case['source_unchanged']
except BaseException as error:
    case.update(status='failed', error_type=type(error).__name__, error=str(error)[:2000])
    raise
finally:
    case['seconds'] = time.monotonic() - started
    write(out / 'case.json', case)
print('C5_RECONSTRUCTION_CASE_COMPLETED', flush=True)
