"""Bounded-memory, deterministic centroid voxel reduction of binary PLY clouds."""
from pathlib import Path
import hashlib
import json
import shutil
import time
import numpy as np

POINT = np.dtype([(name, '<f4') for name in ['x', 'y', 'z']] + [(name, 'u1') for name in ['red', 'green', 'blue']])
TYPES = {'float': '<f4', 'float32': '<f4', 'double': '<f8', 'uchar': 'u1', 'uint8': 'u1'}


def ply_layout(path):
    with Path(path).open('rb') as stream:
        properties = []
        vertex = False
        binary = False
        count = None
        while True:
            line = stream.readline().decode('ascii').strip()
            assert line
            fields = line.split()
            if fields[:2] == ['format', 'binary_little_endian']:
                binary = True
            if fields[0] == 'element':
                vertex = fields[1] == 'vertex'
                if vertex:
                    count = int(fields[2])
            if fields[0] == 'property' and vertex:
                assert len(fields) == 3 and fields[1] in TYPES
                properties.append((fields[2], TYPES[fields[1]]))
            if line == 'end_header':
                assert binary and count is not None
                return count, np.dtype(properties), stream.tell()


def header(count):
    return ('ply\nformat binary_little_endian 1.0\nelement vertex ' + str(count) +
        '\nproperty float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nend_header\n').encode()


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            value.update(block)
    return value.hexdigest()


def reduce_cloud(paths, output, *, voxel_metres=.05, transform=None, partitions=64):
    output = Path(output)
    paths = list(map(Path, paths))
    coordinate_transform = None if transform is None else dict(scale=float(transform[0]), rotation=transform[1].tolist(), translation=transform[2].tolist())
    output.mkdir(exist_ok=True)
    completed = output / 'voxel_report.json'
    if completed.exists():
        previous = json.loads(completed.read_text())
        assert previous['voxel_metres'] == voxel_metres
        assert previous['coordinate_transform'] == coordinate_transform
        assert [str(path) for path in paths] == [row['path'] for row in previous['input_clouds']]
        assert all(digest(Path(row['path'])) == row['sha256'] for row in previous['input_clouds'])
        assert digest(output / 'voxel_005m.ply') == previous['output_sha256']
        return previous
    started = time.monotonic()
    temporary = output / 'voxel_partitions'
    temporary.mkdir(exist_ok=True)
    streams = [(temporary / f'{index:03d}.bin').open('wb') for index in range(partitions)]
    input_points = 0
    inputs = []
    try:
        for path in paths:
            count, dtype, offset = ply_layout(path)
            assert Path(path).stat().st_size == offset + count * dtype.itemsize
            inputs.append(dict(path=str(path), points=count, sha256=digest(path)))
            if not count:
                continue
            source = np.memmap(path, dtype=dtype, offset=offset, mode='r', shape=(count,))
            for begin in range(0, count, 200000):
                rows = source[begin:begin + 200000]
                xyz = np.c_[rows['x'], rows['y'], rows['z']].astype(float)
                assert np.isfinite(xyz).all()
                if transform:
                    scale, rotation, translation = transform
                    xyz = scale * xyz @ rotation.T + translation
                packed = np.empty(len(rows), dtype=POINT)
                for slot, name in enumerate(['x', 'y', 'z']):
                    packed[name] = xyz[:, slot]
                for name in ['red', 'green', 'blue']:
                    packed[name] = rows[name]
                # Quantize the stored coordinates consistently during both passes.
                # Transform rounding can move a point at a boundary, so the partition
                # hash must use the same float32 coordinates as the reducer.
                keys = np.floor(np.c_[packed['x'], packed['y'], packed['z']].astype(float) / voxel_metres).astype(np.int64)
                unsigned = keys.astype(np.uint64)
                hashed = (unsigned[:, 0] * np.uint64(73856093)) ^ (unsigned[:, 1] * np.uint64(19349663)) ^ (unsigned[:, 2] * np.uint64(83492791))
                buckets = hashed % partitions
                for index in np.unique(buckets):
                    streams[int(index)].write(packed[buckets == index].tobytes())
                input_points += len(rows)
            del source
    finally:
        for stream in streams:
            stream.close()
    partition_seconds = time.monotonic() - started
    (output / 'partition_complete.json').write_text(json.dumps(dict(input_points=input_points, inputs=inputs), indent=2))
    counts = []
    for index in range(partitions):
        values = np.fromfile(temporary / f'{index:03d}.bin', dtype=POINT)
        destination = temporary / f'{index:03d}.reduced'
        if not len(values):
            destination.write_bytes(b'')
            counts.append(0)
            continue
        xyz = np.c_[values['x'], values['y'], values['z']].astype(float)
        keys = np.floor(xyz / voxel_metres).astype(np.int64)
        order = np.lexsort((keys[:, 2], keys[:, 1], keys[:, 0]))
        keys = keys[order]
        starts = np.r_[0, np.flatnonzero(np.any(keys[1:] != keys[:-1], axis=1)) + 1]
        sizes = np.diff(np.r_[starts, len(values)])
        packed = np.empty(len(starts), dtype=POINT)
        for name in POINT.names:
            means = np.add.reduceat(values[name][order].astype(float), starts) / sizes
            packed[name] = np.rint(means) if name in ['red', 'green', 'blue'] else means
        packed.tofile(destination)
        counts.append(len(packed))
    result = output / 'voxel_005m.ply'
    with result.open('wb') as stream:
        stream.write(header(sum(counts)))
        for index in range(partitions):
            with (temporary / f'{index:03d}.reduced').open('rb') as incoming:
                shutil.copyfileobj(incoming, stream, length=1024**2)
    count, dtype, offset = ply_layout(result)
    assert count == sum(counts) and result.stat().st_size == offset + count * dtype.itemsize
    report = dict(status='completed', voxel_metres=voxel_metres, input_points=input_points,
        output_points=count, input_clouds=inputs, output_sha256=digest(result),
        partition_seconds=partition_seconds, total_seconds=time.monotonic() - started,
        rule='Fixed ENU origin voxel grid; centroid XYZ and rounded mean RGB; deterministic spatial hash partitions',
        transform_to_common_enu=transform is not None)
    report['coordinate_transform'] = coordinate_transform
    receipt = output / 'voxel_report.json.partial'
    receipt.write_text(json.dumps(report, indent=2))
    receipt.replace(output / 'voxel_report.json')
    # Only owned intermediate partition files are removed after output verification.
    assert temporary.resolve().is_relative_to(output.resolve())
    for path in temporary.iterdir():
        assert path.is_file() and path.parent.resolve() == temporary.resolve()
        path.unlink()
    temporary.rmdir()
    return report
