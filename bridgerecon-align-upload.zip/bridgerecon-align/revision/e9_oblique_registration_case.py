"""Retry the ten existing oblique photographs against the frozen C5 training model."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import resource
import shutil
import sqlite3
import time
import numpy as np
import pycolmap

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
runtime = json.loads((args.root / 'runtime_manifest.json').read_text())
survey = args.root / runtime['survey']
assert args.out.resolve().is_relative_to(survey.resolve())
args.out.mkdir(exist_ok=True)
os.chdir(survey)
started = time.monotonic()
case = dict(status='running', trials=[], scope='Cached-feature pose registration of ten oblique views against the original C5 training-only model')


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            digest.update(block)
    return digest.hexdigest()


def save():
    case.update(seconds=time.monotonic() - started, peak_rss_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024)
    temporary = args.out / 'case.json.partial'
    temporary.write_text(json.dumps(case, indent=2, default=str))
    temporary.replace(args.out / 'case.json')


try:
    original = survey / 'database.db'
    database_hash = sha(original)
    database = args.out / 'registration_database.db'
    shutil.copy2(original, database)
    preparation = args.root / runtime['case_paths']['C5']['preparation']
    model = pycolmap.Reconstruction((preparation / 'fitted_sparse').relative_to(survey).as_posix())
    initial = {image_id: model.images[image_id].cam_from_world.matrix().copy() for image_id in model.reg_image_ids()}
    assert len(initial) == 578
    metadata = json.loads((survey / 'report.json').read_text())
    oblique = {row['name'] for row in metadata['images'] if 576 <= row['index'] <= 585}
    assert len(oblique) == 10
    parameters = model.cameras[1].params.copy()
    with sqlite3.connect(database) as connection:
        images = connection.execute('SELECT image_id,name,camera_id FROM images').fetchall()
        candidates = [(image_id, name, camera_id) for image_id, name, camera_id in images if name in oblique]
        assert len(candidates) == 10
        camera_ids = {row[2] for row in candidates}
        for camera_id in camera_ids:
            if camera_id not in model.cameras:
                model_id, width, height = connection.execute(
                    'SELECT model,width,height FROM cameras WHERE camera_id=?', (camera_id,)).fetchone()
                assert model_id == 2 and width == 1600 and height == 1200
                model.add_camera(pycolmap.Camera(model='SIMPLE_RADIAL', width=width, height=height,
                    params=parameters.copy(), camera_id=camera_id))
            camera = model.cameras[camera_id]
            assert camera.model.name == 'SIMPLE_RADIAL' and camera.width == 1600 and camera.height == 1200
            camera.params = parameters.copy()
            connection.execute('UPDATE cameras SET params=?,prior_focal_length=1 WHERE camera_id=?',
                               (parameters.astype(np.float64).tobytes(), camera_id))
    # Preserve the original descriptor matches and geometric correspondences.
    with pycolmap.Database(database.relative_to(survey).as_posix()) as connection:
        cache = pycolmap.DatabaseCache.create(connection, 15, False, set())
    mapper = pycolmap.IncrementalMapper(cache)
    mapper.begin_reconstruction(model)
    options = pycolmap.IncrementalMapperOptions()
    options.num_threads = 8
    case.update(pose_options=options.todict(), initial_registered_images=578,
        camera_prior='Frozen C5 shared physical-lens parameters initialize the oblique camera group; default focal/radial refinement is enabled during PnP',
        fresh_feature_or_descriptor_matching=False, source_database_sha256=database_hash)
    for image_id, name, camera_id in candidates:
        registered = mapper.register_next_image(options, image_id)
        case['trials'].append(dict(image_id=image_id, name=name, camera_id=camera_id, registered=registered))
        save()
        print('OBLIQUE_REGISTRATION_TRIAL', name, registered, flush=True)
    mapper.end_reconstruction(False)
    assert all(np.array_equal(model.images[image_id].cam_from_world.matrix(), matrix) for image_id, matrix in initial.items())
    added = [row['name'] for row in case['trials'] if row['registered']]
    destination = args.out / 'sparse'
    destination.mkdir()
    model.write(destination.relative_to(survey).as_posix())
    case.update(status='completed', added_oblique_images=added, added_oblique_count=len(added),
        registered_images=model.num_reg_images(), existing_camera_poses_unchanged=True,
        original_database_unchanged=sha(original) == database_hash, model=str(destination),
        pending=['C5 refit and fixed-core evaluation with the added views'] if added else [],
        interpretation='No expanded-camera C5 comparison is available when zero additional views register')
    assert case['original_database_unchanged']
except BaseException as error:
    case.update(status='failed', error_type=type(error).__name__, error=str(error)[:1200])
    raise
finally:
    save()
print('OBLIQUE_REGISTRATION_CASE_COMPLETED', flush=True)
