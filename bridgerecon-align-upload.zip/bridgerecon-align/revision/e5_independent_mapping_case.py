"""Remove frozen evaluation-feature correspondences and map independently on CPU."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import shutil
import sqlite3
import sys
import time
import uuid
import zipfile
import numpy as np
from scipy.spatial import cKDTree
import pycolmap

PAIR_ID_BASE = 2147483647


def _decode_pair_id(pair_id):
    image_id2 = pair_id % PAIR_ID_BASE
    image_id1 = (pair_id - image_id2) // PAIR_ID_BASE
    return image_id1, image_id2


def _pair_rows(record):
    if record is None or not record[0]:
        return np.empty((0, 2), dtype=np.uint32)
    rows, cols, data = record
    assert cols == 2
    return np.frombuffer(data, np.uint32).reshape(rows, cols)


def _assert_no_frozen_observations(connection, table, frozen, stage):
    for pair_id, rows, cols, data in connection.execute(
            f'SELECT pair_id,rows,cols,data FROM {table}'):
        if not rows:
            continue
        assert cols == 2
        image_id1, image_id2 = _decode_pair_id(pair_id)
        values = np.frombuffer(data, np.uint32).reshape(rows, cols)
        bad = np.zeros(rows, bool)
        if image_id1 in frozen:
            bad |= frozen[image_id1][values[:, 0]]
        if image_id2 in frozen:
            bad |= frozen[image_id2][values[:, 1]]
        if bad.any():
            raise AssertionError(
                f'{stage}: {table} pair {pair_id} retains {int(bad.sum())} '
                'frozen evaluation observations')


def _union_filtered_geometry_matches(connection):
    """Add filtered verified/guided correspondences to the raw match candidates."""
    pair_ids = [row[0] for row in connection.execute(
        'SELECT pair_id FROM matches UNION SELECT pair_id FROM two_view_geometries')]
    raw_total = geometry_total = union_input_total = union_total = 0
    geometry_only_total = pairs_with_geometry_only = 0
    for pair_id in pair_ids:
        raw = _pair_rows(connection.execute(
            'SELECT rows,cols,data FROM matches WHERE pair_id=?', (pair_id,)).fetchone())
        geometry = _pair_rows(connection.execute(
            'SELECT rows,cols,data FROM two_view_geometries WHERE pair_id=?',
            (pair_id,)).fetchone())
        raw_unique = np.unique(raw, axis=0)
        geometry_unique = np.unique(geometry, axis=0)
        combined = np.concatenate((raw_unique, geometry_unique), axis=0)
        union = np.unique(combined, axis=0)
        raw_total += len(raw)
        geometry_total += len(geometry)
        union_input_total += len(raw_unique) + len(geometry_unique)
        union_total += len(union)
        added = len(union) - len(raw_unique)
        geometry_only_total += added
        pairs_with_geometry_only += int(added > 0)
        payload = union.tobytes()
        existing = connection.execute(
            'SELECT 1 FROM matches WHERE pair_id=?', (pair_id,)).fetchone()
        if existing:
            connection.execute(
                'UPDATE matches SET rows=?,cols=2,data=? WHERE pair_id=?',
                (len(union), payload, pair_id))
        else:
            connection.execute(
                'INSERT INTO matches(pair_id,rows,cols,data) VALUES(?,?,2,?)',
                (pair_id, len(union), payload))
    return {
        'rule': 'Per image pair, union deduplicated filtered raw matches and filtered '
                'two-view inlier/guided matches before recomputing geometry; no '
                'descriptor or feature matching is rerun.',
        'pairs': len(pair_ids),
        'filtered_raw_correspondences': raw_total,
        'filtered_two_view_correspondences': geometry_total,
        'union_candidates_before_deduplication': union_input_total,
        'union_correspondences': union_total,
        'added_two_view_only_correspondences': geometry_only_total,
        'pairs_with_added_two_view_correspondences': pairs_with_geometry_only,
        'duplicate_overlap_removed': union_input_total - union_total,
    }

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--filter-only', action='store_true')
parser.add_argument('--evaluation-features', type=Path, required=True)
args = parser.parse_args()
root, out = args.root.resolve(), args.out.resolve()
runtime = json.loads((root / 'runtime_manifest.json').read_text(encoding='utf-8'))
survey = root / runtime['survey']
assert out.is_relative_to(survey)
out.mkdir(exist_ok=True)
original = root / runtime['case_paths']['C0']['preparation']
started = time.monotonic()
run_id = uuid.uuid4().hex[:12]
case = dict(status='running', scope='E5b independent database filtering and mapping stage. Anchor selection, C5 BA and fixed-pair evaluation remain pending.',
            source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            mapper_uses_original_poses=False,
            filtering='Remove every correspondence involving frozen evaluation keypoint '
                      'observations from both tables; union the filtered raw and two-view '
                      'matches per pair, then recompute geometry and map independently.')
checkpoints = []
published_snapshots = set()
checkpoint_seconds = 0.


def save(path, value):
    temporary = path.with_suffix('.partial')
    temporary.write_text(json.dumps(value, indent=2, default=str))
    temporary.replace(path)


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b''):
            digest.update(block)
    return digest.hexdigest()


def checkpoint():
    global checkpoint_seconds
    snapshots = cache / 'snapshots'
    for image_file in sorted(snapshots.rglob('images.bin')):
        directory = image_file.parent
        if str(directory) in published_snapshots:
            continue
        files = [directory / name for name in ['cameras.bin', 'images.bin', 'points3D.bin']]
        if not all(path.is_file() for path in files):
            continue
        tick = time.monotonic()
        try:
            model = pycolmap.Reconstruction(str(directory))
        except Exception:
            continue
        folder = Path('/content/cpu_supplement_checkpoints')
        folder.mkdir(exist_ok=True)
        name = f'Supplement_{run_id}_E5b_mapping_{model.num_reg_images():04d}_{sha(image_file)[:8]}.zip'
        archive = folder / name
        with zipfile.ZipFile(archive.with_suffix('.partial'), 'w', zipfile.ZIP_DEFLATED, compresslevel=1) as compressed:
            for path in files:
                compressed.write(path, 'sparse/' + path.name)
            compressed.write(out / 'filtering.json', 'filtering.json')
            compressed.write(out / 'evaluation_keypoints.npz', 'evaluation_keypoints.npz')
        archive.with_suffix('.partial').replace(archive)
        record = dict(name=name, bytes=archive.stat().st_size, sha256=sha(archive), registered_images=model.num_reg_images())
        checkpoints.append(record)
        published_snapshots.add(str(directory))
        checkpoint_seconds += time.monotonic() - tick
    save(out / 'progress.json', dict(updated_utc=datetime.now(timezone.utc).isoformat(),
         mapping_checkpoints=checkpoints, checkpoint_seconds=checkpoint_seconds))


try:
    source_database = survey / 'database.db'
    source_sha = sha(source_database)
    cache = out.parent / 'e5_mapping_cache' / out.name
    cache.mkdir(parents=True)
    database = cache / 'filtered_database.db'
    shutil.copy2(source_database, database)
    with np.load(original / 'global_checking_tracks.npz') as archive:
        slots = archive['view_slot'].copy()
        native_uv = archive['native_uv'].copy()
    with np.load(original / 'global_cameras.npz') as archive:
        old_indices = archive['image_indices'].astype(int)
    metadata = json.loads((survey / 'report.json').read_text(encoding='utf-8'))
    names = {row['index']: row['name'] for row in metadata['images']}
    frozen = {}
    with np.load(args.evaluation_features) as archive:
        frozen_image_ids = archive['image_ids'].copy()
        frozen_feature_indices = archive['feature_indices'].copy()
    matches_removed = {}
    with sqlite3.connect(database) as connection:
        connection.execute('PRAGMA cache_size=-32768')
        image_ids = {name: image_id for image_id, name in connection.execute('SELECT image_id,name FROM images')}
        for slot, index in enumerate(old_indices):
            image_id = image_ids[names[int(index)]]
            rows, cols, data = connection.execute('SELECT rows,cols,data FROM keypoints WHERE image_id=?', (image_id,)).fetchone()
            keypoints = np.frombuffer(data, np.float32).reshape(rows, cols)[:, :2]
            query = native_uv[slots == slot]
            distances, _ = cKDTree(keypoints).query(query)
            assert np.all(distances < 1e-4), (int(index), float(distances.max()))
            flags = np.zeros(rows, bool)
            selected = frozen_feature_indices[frozen_image_ids == image_id]
            flags[selected] = True
            groups = cKDTree(keypoints).query_ball_point(query, r=1e-4)
            assert np.array_equal(np.flatnonzero(flags), np.unique(np.concatenate(groups)))
            frozen[image_id] = flags
        flat_ids = np.concatenate([np.full(int(flags.sum()), image_id) for image_id, flags in frozen.items()])
        flat_features = np.concatenate([np.flatnonzero(flags) for flags in frozen.values()])
        np.savez_compressed(out / 'evaluation_keypoints.npz', image_ids=flat_ids, feature_indices=flat_features)
        for table in ['matches', 'two_view_geometries']:
            removed, before, after = 0, 0, 0
            pairs = connection.execute(f'SELECT pair_id,rows,cols,data FROM {table}').fetchall()
            for pair_id, rows, cols, data in pairs:
                if not rows:
                    continue
                assert cols == 2
                image_id2 = pair_id % 2147483647
                image_id1 = (pair_id - image_id2) // 2147483647
                values = np.frombuffer(data, np.uint32).reshape(rows, cols)
                keep = np.ones(rows, bool)
                if image_id1 in frozen:
                    keep &= ~frozen[image_id1][values[:, 0]]
                if image_id2 in frozen:
                    keep &= ~frozen[image_id2][values[:, 1]]
                before += rows
                after += int(keep.sum())
                removed += int((~keep).sum())
                connection.execute(f'UPDATE {table} SET rows=?,data=? WHERE pair_id=?',
                                   (int(keep.sum()), values[keep].tobytes(), pair_id))
            matches_removed[table] = dict(before=before, after=after, removed=removed)
        _assert_no_frozen_observations(connection, 'matches', frozen, 'after filtering')
        _assert_no_frozen_observations(connection, 'two_view_geometries', frozen,
                                       'after filtering')
        union_stats = _union_filtered_geometry_matches(connection)
        _assert_no_frozen_observations(connection, 'matches', frozen, 'after union')
        _assert_no_frozen_observations(connection, 'two_view_geometries', frozen,
                                       'after union')
        # The old F/E/H matrices may have been estimated using held-out observations.
        connection.execute('DELETE FROM two_view_geometries')
    filtering = dict(source_database_sha256=source_sha, frozen_evaluation_observations=len(native_uv),
                     excluded_feature_count=len(flat_features), evaluation_feature_inventory_sha256=sha(args.evaluation_features),
                     duplicate_coordinate_rule='Exclude every database feature within 1e-4 native pixels of any frozen evaluation observation.',
                     exact_keypoint_matching_tolerance_pixels=1e-4, correspondence_counts=matches_removed,
                     filtered_geometry_union=union_stats,
                     prior_camera_poses_used=False, original_database_unchanged=sha(source_database) == source_sha)
    save(out / 'filtering.json', filtering)
    print('E5_FILTERING_COMPLETED', json.dumps(filtering), flush=True)
    if args.filter_only:
        case.update(status='completed', scope='E5b database-filtering preflight only. Mapping and evaluation remain pending.', filtering=filtering)
        raise SystemExit(0)
    pycolmap.verify_matches(str(database), str(survey / 'pairs.txt'))
    with sqlite3.connect(database) as connection:
        _assert_no_frozen_observations(connection, 'matches', frozen,
                                       'after geometry verification')
        _assert_no_frozen_observations(connection, 'two_view_geometries', frozen,
                                       'after geometry verification')
    filtering['filtered_verified_database_sha256'] = sha(database)
    save(out / 'filtering.json', filtering)
    sparse = out / 'models'
    sparse.mkdir()
    snapshots = cache / 'snapshots'
    snapshots.mkdir()
    options = pycolmap.IncrementalPipelineOptions()
    options.num_threads = 8
    options.mapper.num_threads = 8
    options.extract_colors = False
    options.multiple_models = True
    options.snapshot_path = str(snapshots)
    options.snapshot_images_freq = 20
    save(out / 'mapper_options.json', options.todict())
    models = pycolmap.incremental_mapping(str(database), str(survey / 'images'), str(sparse), options,
                                         initial_image_pair_callback=checkpoint, next_image_callback=checkpoint)
    checkpoint()
    assert models
    model = max(models.values(), key=lambda item: item.num_reg_images())
    violations = 0
    for image_id in model.reg_image_ids():
        image = model.images[image_id]
        if image_id in frozen:
            violations += sum(image.points2D[int(index)].has_point3D() for index in np.flatnonzero(frozen[image_id]))
    assert violations == 0
    registered = {image.name for image in model.images.values() if image.has_pose}
    missing = sorted({names[int(index)] for index in old_indices} - registered)
    destination = out / 'sparse'
    destination.mkdir()
    model.write(str(destination))
    case.update(status='completed_unsupported' if missing else 'completed',
                registered_images=model.num_reg_images(), missing_original_evaluation_cameras=missing,
                evaluation_feature_track_violations=violations, mapping_checkpoint_count=len(checkpoints),
                filtered_database_sha256=filtering['filtered_verified_database_sha256'],
                independent_model=str(destination), checkpoint_seconds=checkpoint_seconds)
except Exception as error:
    case.update(status='failed', error_type=type(error).__name__, error=str(error)[:2000])
    raise
finally:
    case['seconds'] = time.monotonic() - started
    save(out / 'case.json', case)
print('E5_INDEPENDENT_MAPPING_STAGE_COMPLETED', flush=True)
