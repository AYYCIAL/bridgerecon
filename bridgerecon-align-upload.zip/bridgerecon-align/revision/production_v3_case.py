"""Measure production V3 calibration, grid export and common 5 cm voxel reduction."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import resource
import shutil
import sys
import time
import numpy as np
from voxel_cloud import POINT, header, digest, reduce_cloud

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--calibration-folder', type=Path, required=True, help='output folder of the calibration case (with case.json)')
args = parser.parse_args()
args.out.mkdir(exist_ok=True)
case_folder = args.calibration_folder
calibration_case = json.loads((case_folder / 'case.json').read_text())
assert calibration_case['status'] == 'completed'
preparation = Path(calibration_case['preparation'])
research = json.loads((Path(calibration_case['hybrid']) / 'report.json').read_text())
prep = json.loads((preparation / 'report.json').read_text())
assert prep['status'] == 'completed' and prep['source_unchanged']
sys.path.insert(0, str(args.root / 'experiments'))
import local_validation
from historical_sampling import sample
local_validation.sample = sample
from global_hybrid_geometry import camera_alignment, fit_depth_scales, unproject_native
from route_chunk_geometry import serialize
spec = importlib.util.spec_from_file_location('e1_production', args.root / 'colab_runtime.py')
e1 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(e1)
started = time.monotonic()
report = dict(status='running', mode='V3 production calibration and point export',
    scope='Training anchors and prediction arrays; image-grid stride4; fixed 5 cm ENU voxel grid',
    preparation_sha256=digest(preparation / 'report.json'), chunks=[],
    input_io='Load each prediction chunk once during each of the calibration and export passes')


def save():
    report['elapsed_seconds'] = time.monotonic() - started
    report['peak_rss_MiB'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    temporary = args.out / 'case.json.partial'
    temporary.write_text(json.dumps(report, indent=2))
    temporary.replace(args.out / 'case.json')


try:
    records = {row['index']: row for row in prep['views']}
    cameras = json.loads((preparation / 'native_cameras.json').read_text())
    ownership = {}
    for chunk in research['chunks']:
        path = Path(chunk['input'])
        assert digest(path) == chunk['input_sha256']
        with np.load(path) as archive:
            data = {key: archive[key] for key in archive.files}
            anchors = []
            for index in chunk['image_indices']:
                record = records[index]
                anchor_path = preparation / record['file']
                assert digest(anchor_path) == record['sha256']
                with np.load(anchor_path) as archive:
                    anchors.append({key: archive[key] for key in ['train_uv', 'train_z', 'train_eligible', 'extrinsics']})
            extrinsics = np.array([anchor['extrinsics'] for anchor in anchors])
            model, alignment = camera_alignment(data['extrinsics'], extrinsics)
            fit = fit_depth_scales(data, anchors, model[0])
        assert fit['chunk_supported']
        assert np.isclose(model[0], chunk['similarity']['scale'], rtol=0, atol=1e-12)
        assert np.allclose([view['applied_scale'] for view in fit['views']],
                           [view['applied_scale'] for view in chunk['depth_fit']['views']], rtol=0, atol=1e-12)
        row = dict(start=chunk['start'], input=str(path), input_sha256=chunk['input_sha256'],
                   image_indices=chunk['image_indices'], similarity=serialize(model), depth_fit=fit)
        report['chunks'].append(row)
        for index in chunk['image_indices']:
            ownership.setdefault(index, chunk['start'])
        save()
    report['calibration_seconds'] = time.monotonic() - started
    frozen = args.out / 'frozen_parameters.json'
    frozen.write_text(json.dumps(report['chunks'], indent=2))
    report['frozen_parameters_sha256'] = digest(frozen)
    tick = time.monotonic()
    points = args.out / 'points.bin'
    count = 0
    with points.open('wb') as stream:
        for chunk in report['chunks']:
            with np.load(chunk['input']) as archive:
                data = {key: archive[key] for key in archive.files}
                height, width = data['depth'].shape[1:3]
                yy, xx = np.mgrid[2:height-2:4, 2:width-2:4]
                grid = np.c_[xx.ravel(), yy.ravel()]
                for slot, index in enumerate(chunk['image_indices']):
                    if ownership[index] != chunk['start']:
                        continue
                    with np.load(preparation / records[index]['file']) as archive:
                        extrinsic = archive['extrinsics']
                        transform = archive['native_to_input']
                        camera = cameras[str(int(archive['camera_id']))]
                    depth = data['depth'][slot, yy, xx, 0].ravel()
                    confidence = data['depth_conf'][slot, yy, xx].ravel()
                    use = (confidence >= 1.2) & (depth > 0) & np.isfinite(depth)
                    xyz = unproject_native(grid[use], chunk['similarity']['scale'] *
                        chunk['depth_fit']['views'][slot]['applied_scale'] * depth[use], extrinsic, camera, transform)
                    assert np.isfinite(xyz).all()
                    colors = data['rgb'][slot, yy, xx].reshape(-1, 3)[use]
                    packed = np.empty(len(xyz), dtype=POINT)
                    for axis, name in enumerate(['x', 'y', 'z']):
                        packed[name] = xyz[:, axis]
                    for axis, name in enumerate(['red', 'green', 'blue']):
                        packed[name] = colors[:, axis]
                    stream.write(packed.tobytes())
                    count += len(packed)
    report['point_generation_seconds'] = time.monotonic() - tick
    expected = next(row['sample_records'] for row in research['exports'] if row['variant'] == 'view_depth_scale')
    assert count == expected
    tick = time.monotonic()
    cloud = args.out / 'V3_stride4.ply'
    with cloud.open('wb') as stream, points.open('rb') as incoming:
        stream.write(header(count))
        shutil.copyfileobj(incoming, stream, length=1024**2)
    report.update(point_records=count, merge_seconds=time.monotonic() - tick, cloud_sha256=digest(cloud))
    with np.load(preparation / 'global_cameras.npz') as archive:
        extrinsics, indices = archive['extrinsics'], archive['image_indices'].astype(int)
    centers = -np.einsum('nji,nj->ni', extrinsics[:, :, :3], extrinsics[:, :, 3])
    positions = e1.enu(json.loads((args.root / 'experiments/data_audit/images.json').read_text()))
    training = np.array([not e1.held_out(index) for index in indices])
    transform = e1.fit_similarity(centers[training], positions[indices][training])
    report['voxel'] = reduce_cloud([cloud], args.out / 'voxel', transform=transform)
    assert digest(frozen) == report['frozen_parameters_sha256']
    assert digest(preparation / 'report.json') == report['preparation_sha256']
    report.update(status='completed', calibration_matches_research=True,
        production_seconds=report['calibration_seconds'] + report['point_generation_seconds'] +
            report['merge_seconds'] + report['voxel']['total_seconds'])
except BaseException as error:
    report.update(status='failed', error_type=type(error).__name__, error=str(error)[:1500])
    raise
finally:
    save()
print('PRODUCTION_V3_COMPLETED', flush=True)
