# Additional controls of the revised article

These scripts produced the additional controls of the revised article. They ran on a cloud server with an NVIDIA L4 GPU (24 GB) and 12 vCPUs.

**Project layout.** The project root was `/content/bridgerecon`, with the pipeline modules in `<root>/experiments` and run folders in `<root>/experiments/runs`. To run the scripts elsewhere:
- pass `--root`, or set `BRIDGERECON_ROOT`, to a folder whose `experiments/` holds the modules of `../pipeline/`; a link is enough;
- set `BRIDGERECON_CHECKPOINTS` for the checkpoint copies;
- set `BRIDGERECON_ARCHIVED_ROOT` to the root recorded in archived run reports, so that their absolute paths are mapped to the current root.

All scripts need the restricted image-level inputs.

| Script | Control | Article |
|---|---|---|
| `e5_independent_mapping_case.py` | Removes the checking-feature correspondences and maps independently (C5′) | Section 3.7, Table S6 |
| `c5_reconstruction_case.py` | Applies the training-only C5 pipeline to a new model or photograph subset (C5′ and flight-geometry subsets) | Tables S6 and S12 |
| `cpu_case_summary.py` | Training-only RTK alignment, range agreement and fixed-pair summaries of a fitted case | Table 6, Tables S6–S8 and S12 |
| `cpu_phase_worker.py` | Bundle adjustment with a given position prior or fixed focal length, then calibration and export: the 0.01-m prior and the fixed-focal sweep around C8 | Tables S7 and S8, Figure 11 |
| `summarize_prior_focal_scans.py` | Tables of the prior and focal controls from the case summaries (`../data/aggregate/prior_focal_tables`) | Tables S7 and S8 |
| `camera_perturbation_case.py` | Camera, timing and vertical-reference controls around C8 (uses `radial_k2_geometry.py` for the free-k2 case) | Table S17 |
| `night_scan_case.py` | Confidence thresholds, scale bounds and anchor thinning | Tables S10 and S11 |
| `e9_oblique_registration_case.py`, `e9c_fresh_matching_case.py` | Registration of the ten oblique photographs | Section 3.8 |
| `reviewer3_saved_output_checks.py` | Spatial bootstrap and C5/C8 seam and range checks on saved outputs | Table 7, Tables S13 and S15 |
| `reviewer3_beam_sensitivity.py` | Assumed beam offsets on the flat subset | Table S14 |
| `e6_sfm_case.py`, `e6_sfm_resume_case.py` | SfM with COLMAP 3.13 on the L4 (features, guided matching, mapping) | Table S5 |
| `vggt_timing_case.py` | Full-route VGGT runs on the L4 | Section 3.6, Table S5 |
| `production_v3_case.py` | Production V3 calibration, point export and 5-cm voxel reduction (`voxel_cloud.py`) | Table S5 |
| `gpu_mvs_worker.py`, `mvs_fusion_case.py` | COLMAP MVS depth and fusion on the L4 | Table S5 |
| `mvs_crossview_case.py` | Cross-view evaluation of the MVS maps computed on the L4 | Table S16 |
| `historical_sampling.py` | Bilinear sampling compatible with the saved prediction arrays (helper) | — |

The range-based scale correction (Table S18) runs on the released data: `../demos/range_scale_correction.py`.
