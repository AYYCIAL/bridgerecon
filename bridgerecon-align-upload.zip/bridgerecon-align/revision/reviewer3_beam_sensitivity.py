"""Conditional beam-offset sensitivity on the frozen 271 C5 flat centres.

No fit to laser measurements. Uses geometric MVS1600 camera-z crops and
converts offset rays to slant distances. Angular offsets are assumptions,
not measured boresight errors or calibrated confidence limits.
"""
from pathlib import Path
import csv
import hashlib
import json
import time
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = ROOT / 'revision_20261116/local_runtime'
OUT = ROOT / 'revision_20261116/results/reviewer3'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    started = time.monotonic()
    OUT.mkdir(exist_ok=True)
    source = RUNTIME / 'metadata/c5_mvs_centre_windows.npz'
    alignment_source = ROOT / 'revision_20261116/results/geometry_diagnostics.json'
    alignment = json.loads(alignment_source.read_text(encoding='utf-8'))
    scale = alignment['E4_boresight']['enu_454_scale']
    with np.load(source) as data:
        windows = data['depth'].astype(float)
        fx, fy = data['focal_px']
        cx, cy = data['centre_pixel']
    patch = windows[:, 54:75, 54:75].copy()
    patch[~np.isfinite(patch) | (patch <= 0)] = np.nan
    flat = (np.nanmax(patch, axis=(1, 2)) - np.nanmin(patch, axis=(1, 2))) < 1
    assert int(flat.sum()) == 271
    baseline = windows[:, 64, 64] * scale
    rows = []
    for angle in (0.25, 0.5, 1.0, 1.5):
        offsets = sorted(set((int(round(fx*np.tan(np.radians(angle))*np.cos(t))),
                              int(round(fy*np.tan(np.radians(angle))*np.sin(t))))
                             for t in np.arange(8)*np.pi/4))
        assert max(max(abs(x), abs(y)) for x, y in offsets) <= 40
        values = []
        for dx, dy in offsets:
            # The crop is centred on the rounded undistorted principal point.
            x = round(float(cx)) + dx
            y = round(float(cy)) + dy
            z = windows[:, 64+dy, 64+dx] * scale
            slant = z * np.sqrt(1 + ((x-cx)/fx)**2 + ((y-cy)/fy)**2)
            values.append(np.where(np.isfinite(z) & (z > 0), slant, np.nan))
        values = np.stack(values, axis=1)
        common = flat & np.isfinite(baseline) & (baseline > 0) & np.isfinite(values).all(axis=1)
        differences = np.abs(values[common] - baseline[common, None])
        worst = differences.max(axis=1)
        rows.append(dict(assumed_angle_degrees=angle,
                         sampled_offsets_xy=json.dumps(offsets),
                         frozen_flat_centres=271, common_valid_centres=int(common.sum()),
                         median_per_image_max_abs_range_change_m=float(np.median(worst)),
                         p95_per_image_max_abs_range_change_m=float(np.percentile(worst, 95)),
                         max_abs_range_change_m=float(worst.max())))
    with (OUT/'beam_offset_sensitivity.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    result = dict(status='completed', gpu_hours=0, seconds=time.monotonic()-started,
                  source=str(source.relative_to(ROOT)), source_sha256=digest(source),
                  scale=scale, flat_selection='Frozen C5 COLMAP geometric MVS1600, 21x21 principal-point window, camera-z span <1 m in the original SfM gauge',
                  statistic='For each common-valid flat centre, maximum absolute slant-range change over eight azimuths; median/P95 across centres',
                  rows=rows,
                  limitations=['Conditional on the C5 MVS surface and intrinsics, which share the imagery and its scale bias.',
                               'Angles are sensitivity scenarios, not independently measured bounds on beam misalignment.',
                               'Flatness within +/-10 px does not guarantee flatness at larger offsets; invalid rays are excluded with support reported.',
                               'No fitting to LRF observations, no inference of laser noise or absolute survey accuracy.'])
    (OUT/'beam_offset_sensitivity.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
