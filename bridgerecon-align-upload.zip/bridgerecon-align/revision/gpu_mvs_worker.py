"""C8 MVS518, original parameters, independent 454-position metric scale."""
from pathlib import Path
import argparse
import os
import hashlib
import json
import resource
import sys
import time
import numpy as np
import pycolmap
from scipy.ndimage import map_coordinates

p=argparse.ArgumentParser()
p.add_argument('--count',type=int,default=576)
p.add_argument('--case',choices=['C5','C8'],default='C8')
p.add_argument('--width',type=int,default=518)
p.add_argument('--out',type=Path,required=True)
p.add_argument('--resume',action='store_true')
args=p.parse_args()
assert args.count in [12,576] and args.width in [518,1600]
root=Path(os.environ.get('BRIDGERECON_ROOT', '/content/bridgerecon'))
runtime=json.loads((root/'runtime_manifest.json').read_text())
survey=root/runtime['survey']
prep=root/runtime['case_paths'][args.case]['preparation']
args.out.mkdir(parents=True,exist_ok=args.resume)
started=time.monotonic()

def digest(path):
    hasher=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):
            hasher.update(block)
    return hasher.hexdigest()

source_hash={name:digest(prep/'fitted_sparse'/name) for name in ['cameras.bin','images.bin','points3D.bin']}
report={'status':'preparing','scope':f'{args.case} MVS{args.width} on frozen manuscript cameras; depth-stage timing only, not complete E6',
    'case':args.case,'images':args.count,'pycolmap':pycolmap.__version__,'cuda_enabled':pycolmap.has_cuda,
    'settings':{'max_image_size':args.width,'num_iterations':3,'geom_consistency':True,'cache_size':2,'sources':10},
    'input_sha256':source_hash,'stages':[]}
if args.resume and (args.out/'report.json').exists():
    previous=json.loads((args.out/'report.json').read_text())
    assert previous['input_sha256']==source_hash and previous['case']==args.case and previous['settings']['max_image_size']==args.width
    report['previous_execution']=previous
    report['timing_integrity']='Resumed: current segment time must not be reported as uninterrupted full-stage time'

def save():
    report['elapsed_seconds']=time.monotonic()-started
    report['max_rss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    (args.out/'report.json').write_text(json.dumps(report,indent=2))

def stage(name,function):
    report['status']=name;save()
    tick=time.monotonic();function()
    report['stages'].append({'name':name,'seconds':time.monotonic()-tick});save()

try:
    assert pycolmap.__version__=='3.13.0' and pycolmap.has_cuda
    metadata=json.loads((survey/'report.json').read_text())
    name_by_index={r['index']:r['name'] for r in metadata['images']}
    selected={name_by_index[i] for i in range(args.count)}
    model=pycolmap.Reconstruction(str(prep/'fitted_sparse'))
    for image_id in list(model.reg_image_ids()):
        image=model.images[image_id]
        if image.name not in selected:
            model.deregister_frame(image.frame_id)
    assert model.num_reg_images()==args.count
    sparse=args.out/'input_sparse';sparse.mkdir(exist_ok=args.resume);model.write(str(sparse))
    dense=args.out/'dense'
    if not (args.resume and (dense/'stereo/patch-match.cfg').exists() and (dense/'sparse/cameras.bin').exists()
            and all((dense/'images'/name).exists() for name in selected)):
        stage('undistort',lambda:pycolmap.undistort_images(str(dense),str(sparse),str(survey/'images'),
            num_patch_match_src_images=10,undistort_options={'max_image_size':args.width}))
    configuration=[line.strip() for line in (dense/'stereo/patch-match.cfg').read_text().splitlines() if line.strip()]
    assert set(configuration[::2])==selected and len(configuration)==2*args.count
    options=pycolmap.PatchMatchOptions()
    options.max_image_size=args.width;options.num_iterations=3;options.geom_consistency=True;options.cache_size=2
    report['patch_match_options']=options.todict();save()
    stage('stereo',lambda:pycolmap.patch_match_stereo(str(dense),options=options))
    maps=list((dense/'stereo/depth_maps').rglob('*.geometric.bin'))
    assert len(maps)==args.count,len(maps)
    undistorted=pycolmap.Reconstruction(str(dense/'sparse'))
    values=[];indices=[];crops=[]
    for index in range(args.count):
        name=name_by_index[index]
        path=dense/'stereo/depth_maps'/(name+'.geometric.bin')
        with path.open('rb') as stream:
            fields=[]
            while len(fields)<3:
                field=bytearray()
                while True:
                    byte=stream.read(1)
                    if byte==b'&':break
                    if not byte:raise ValueError('Invalid depth header')
                    field.extend(byte)
                fields.append(int(field))
            width,height,channels=fields
            data=np.fromfile(stream,dtype=np.float32).reshape((width,height,channels),order='F').transpose(1,0,2)[...,0]
        image=undistorted.find_image_with_name(name)
        camera=undistorted.cameras[image.camera_id]
        centre=np.asarray(camera.calibration_matrix())[:2,2]
        depth=float(map_coordinates(data,np.array([[centre[1]],[centre[0]]]),order=1,mode='nearest')[0])
        values.append(depth);indices.append(index)
        x,y=np.rint(centre).astype(int)
        crops.append(data[y-64:y+65,x-64:x+65].copy())
    values=np.asarray(values)
    sys.path.insert(0,str(root))
    import colab_runtime as e1
    rows=json.loads((root/'experiments/data_audit/images.json').read_text())
    with np.load(prep/'global_cameras.npz') as camera_data:
        E=camera_data['extrinsics'];camera_indices=camera_data['image_indices'].astype(int)
    centres=-np.einsum('nji,nj->ni',E[:,:,:3],E[:,:,3])
    use=np.array([not e1.held_out(i) for i in camera_indices])
    scale,rotation,translation=e1.fit_similarity(centres[use],e1.enu(rows)[camera_indices][use])
    metre_depth=values*scale
    headers=json.loads((root/'metadata/original_xmp_headers.json').read_text())
    ranges=np.array([float(r['drone_dji']['LRFTargetDistance']) for r in headers[:args.count]])
    with np.load(root/'metadata/c5_mvs_centre_windows.npz') as baseline:
        window=baseline['depth'][:,54:75,54:75].copy()
    window[window<=0]=np.nan
    flat=(np.nanmax(window,axis=(1,2))-np.nanmin(window,axis=(1,2))<1)[:args.count]
    report['enu_454_scale']=scale
    report['rangefinder']={}
    for label,mask in [('all',np.ones(args.count,bool)),('flat',flat)]:
        good=mask&np.isfinite(metre_depth)&(metre_depth>0)
        ratio=float(np.median(metre_depth[good]/ranges[good]))
        residual=np.abs(metre_depth[good]/ratio-ranges[good])
        report['rangefinder'][label]={'n':int(good.sum()),'bias_pct':(ratio-1)*100,
            'scatter_median_m':float(np.median(residual)),'scatter_p95_m':float(np.percentile(residual,95))}
    np.savez_compressed(args.out/'centre_depths.npz',image_indices=indices,depth_native=values,
        depth_metres=metre_depth,range_metres=ranges,flat_subset=flat,centre_windows=np.stack(crops))
    report.update(status='completed',geometric_depth_maps=len(maps),
        source_unchanged=all(digest(prep/'fitted_sparse'/n)==h for n,h in source_hash.items()))
    assert report['source_unchanged']
    save();print('MVS_COMPLETED',json.dumps(report),flush=True)
except BaseException as exc:
    report.update(status='failed',error=repr(exc));save();raise
