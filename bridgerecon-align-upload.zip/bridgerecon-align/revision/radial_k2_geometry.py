"""Extend the frozen native-camera geometry with COLMAP's two-term RADIAL model."""
import numpy as np


def install(geometry):
    if getattr(geometry, '_radial_k2_installed', False):
        return
    original_parameters = geometry.camera_parameters
    original_rays = geometry.native_rays
    original_project = geometry.project_native

    def camera_parameters(camera):
        if camera['model'] == 'RADIAL':
            f, cx, cy, k1, _ = camera['params']
            return f, f, cx, cy, k1
        return original_parameters(camera)

    def native_rays(uv, camera, transform):
        if camera['model'] != 'RADIAL':
            return original_rays(uv, camera, transform)
        f, cx, cy, k1, k2 = np.asarray(camera['params'], dtype=float)
        native = (np.c_[uv, np.ones(len(uv))] @ np.linalg.inv(transform).T)[:, :2]
        distorted = (native - [cx, cy]) / f
        distorted_radius = np.linalg.norm(distorted, axis=1)
        radius = distorted_radius.copy()
        for _ in range(20):
            squared = radius * radius
            derivative = 1 + 3 * k1 * squared + 5 * k2 * squared * squared
            if np.any(derivative <= 0):
                raise ValueError('RADIAL projection is nonmonotonic on the queried rays')
            radius -= (radius * (1 + k1 * squared + k2 * squared * squared) - distorted_radius) / derivative
        residual = radius * (1 + k1 * radius**2 + k2 * radius**4) - distorted_radius
        assert np.max(np.abs(residual), initial=0) < 1e-9
        ratio = np.divide(radius, distorted_radius, out=np.ones_like(radius), where=distorted_radius > 1e-15)
        return np.c_[distorted * ratio[:, None], np.ones(len(uv))]

    def project_native(xyz, extrinsics, camera, transform):
        if camera['model'] != 'RADIAL':
            return original_project(xyz, extrinsics, camera, transform)
        f, cx, cy, k1, k2 = np.asarray(camera['params'], dtype=float)
        points = np.asarray(xyz) @ extrinsics[:, :3].T + extrinsics[:, 3]
        depth = points[:, 2]
        denominator = np.where(np.abs(depth) < 1e-12, np.nan, depth)
        xy = points[:, :2] / denominator[:, None]
        squared = np.sum(xy * xy, axis=1)
        uv = xy * (1 + k1 * squared + k2 * squared * squared)[:, None] * f + [cx, cy]
        return uv @ transform[:2, :2].T + transform[:2, 2], depth

    geometry.camera_parameters = camera_parameters
    geometry.native_rays = native_rays
    geometry.project_native = project_native
    geometry._radial_k2_installed = True
