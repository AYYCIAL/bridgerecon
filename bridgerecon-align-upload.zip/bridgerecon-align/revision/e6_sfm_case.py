"""Fresh COLMAP 3.13 CLI SfM with the original candidate pairs and GPU matching."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tarfile
import time
import urllib.request
import pycolmap
import numpy as np

p=argparse.ArgumentParser()
p.add_argument('--root',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args()
runtime=json.loads((a.root/'runtime_manifest.json').read_text())
survey=a.root/runtime['survey']
metadata=json.loads((survey/'report.json').read_text())
names={row['index']:row['name'] for row in metadata['images']}
with np.load(a.root/runtime['case_paths']['C0']['preparation']/'global_cameras.npz') as data:
    required_names={names[int(index)] for index in data['image_indices']}
a.out.mkdir(exist_ok=True)
case=dict(status='running',scope='Fresh SfM stage only; C5 camera BA and full-flow totals remain pending.',stages=[])
started=time.monotonic()
prefix=Path('/content/colmap313')
exe=prefix/'bin/colmap'
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',LD_LIBRARY_PATH=str(prefix/'lib')+':'+os.environ.get('LD_LIBRARY_PATH',''))
checkpoints=[]
seen=set()


def write(path,value):
    temporary=path.with_suffix('.partial');temporary.write_text(json.dumps(value,indent=2));temporary.replace(path)


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(4*1024**2),b''):h.update(block)
    return h.hexdigest()


def snapshot():
    import zipfile
    for images in sorted((a.out/'snapshots').rglob('images.bin')):
        if str(images) in seen:continue
        folder=images.parent
        files=list(folder.glob('*.bin'))
        if len(files)<3:continue
        model=pycolmap.Reconstruction(str(folder))
        name=f'Supplement_{a.out.name}_sfm_{model.num_reg_images():04d}_{sha(images)[:8]}.zip'
        target=Path('/content/cpu_supplement_checkpoints')/name
        with zipfile.ZipFile(target.with_suffix('.partial'),'w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
            for file in files:z.write(file,'sparse/'+file.name)
        target.with_suffix('.partial').replace(target)
        checkpoints.append(dict(name=name,bytes=target.stat().st_size,sha256=sha(target),registered_images=model.num_reg_images()))
        seen.add(str(images))
    write(a.out/'progress.json',dict(completed_chunks=len(checkpoints),chunk_checkpoints=checkpoints))


def command(name,arguments,limit=1900):
    tick=time.monotonic()
    peak_rss_mib=peak_gpu_used_mib=0.
    with (a.out/(name+'.log')).open('w') as log:
        process=subprocess.Popen(arguments,stdout=log,stderr=subprocess.STDOUT,env=env)
        while process.poll() is None:
            process_status=Path(f'/proc/{process.pid}/status')
            if process_status.exists():
                for line in process_status.read_text().splitlines():
                    if line.startswith('VmHWM:'):peak_rss_mib=max(peak_rss_mib,float(line.split()[1])/1024)
            gpu=subprocess.run(['nvidia-smi','--query-gpu=memory.used','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
            if gpu.returncode==0:peak_gpu_used_mib=max(peak_gpu_used_mib,float(gpu.stdout.splitlines()[0]))
            if time.monotonic()-tick>limit:
                process.terminate();process.wait(20);raise TimeoutError(name)
            if name.startswith('mapping'):snapshot()
            time.sleep(5)
    case['stages'].append(dict(name=name,seconds=time.monotonic()-tick,exit_code=process.returncode,command=arguments,
                              sampled_child_peak_rss_mib=peak_rss_mib,sampled_device_peak_used_mib=peak_gpu_used_mib,sampling_interval_seconds=5))
    write(a.out/'case.json',case)
    assert process.returncode==0,name+' failed'


try:
    if not exe.exists():
        archive=Path('/content/micromamba.tar.bz2')
        with urllib.request.urlopen('https://micro.mamba.pm/api/micromamba/linux-64/latest',timeout=120) as r:
            with archive.open('wb') as f:
                shutil.copyfileobj(r,f,length=1024**2)
        with tarfile.open(archive) as z:
            member=z.getmember('bin/micromamba');z.extract(member,'/content/micromamba_cli')
        command('environment',[ '/content/micromamba_cli/bin/micromamba','create','-y','-p',str(prefix),'-c','conda-forge',
                'colmap=3.13.0=cuda_126h79fc88e_0'],1200)
    version=subprocess.run([str(exe),'-h'],capture_output=True,text=True,env=env).stdout
    assert '3.13.0' in version and 'CUDA' in version
    case['version_header']=version.splitlines()[:4]
    case['benchmark_started_after_environment_setup']=True
    database=a.out/'database.db'
    feature_help=subprocess.run([str(exe),'feature_extractor','-h'],capture_output=True,text=True,env=env)
    feature_help_text=feature_help.stdout+feature_help.stderr
    size_option='--SiftExtraction.max_image_size' if 'SiftExtraction.max_image_size' in feature_help_text else '--FeatureExtraction.max_image_size'
    command('features',[str(exe),'feature_extractor','--database_path',str(database),'--image_path',str(survey/'images'),
            '--ImageReader.single_camera_per_folder','1','--ImageReader.camera_model','SIMPLE_RADIAL',
            '--FeatureExtraction.use_gpu','1','--FeatureExtraction.num_threads','4',size_option,'1600',
            '--SiftExtraction.max_num_features','4096'],900)
    command('matching',[str(exe),'matches_importer','--database_path',str(database),'--match_list_path',str(survey/'pairs.txt'),
            '--match_type','pairs','--FeatureMatching.use_gpu','1','--FeatureMatching.num_threads','4',
            '--FeatureMatching.guided_matching','1'],900)
    (a.out/'snapshots').mkdir(exist_ok=True)
    best=None
    for attempt in range(2):
        output=a.out/f'mapping_{attempt}';output.mkdir()
        arguments=[str(exe),'mapper','--database_path',str(database),'--image_path',str(survey/'images'),
                   '--output_path',str(output),'--Mapper.num_threads','4','--Mapper.max_runtime_seconds','1800',
                   '--Mapper.snapshot_path',str(a.out/'snapshots'),'--Mapper.snapshot_frames_freq','20']
        if best is not None:arguments.extend(['--input_path',str(best)])
        command(f'mapping_{attempt}',arguments)
        candidates=[images.parent for images in output.rglob('images.bin')]
        if best is not None:candidates.append(best)
        assert candidates
        def coverage(path):
            candidate=pycolmap.Reconstruction(str(path))
            registered={candidate.images[index].name for index in candidate.reg_image_ids()}
            return len(required_names&registered),len(registered)
        best=max(candidates,key=coverage)
        if coverage(best)[0]==len(required_names):break
    snapshot()
    model=pycolmap.Reconstruction(str(best))
    destination=a.out/'sparse';destination.mkdir();model.write(str(destination))
    registered_names={model.images[index].name for index in model.reg_image_ids()}
    missing=sorted(required_names-registered_names)
    case.update(status='completed' if not missing else 'completed_unsupported',registered_images=model.num_reg_images(),missing_required_images=missing,
                model=str(destination),candidate_pairs_sha256=sha(survey/'pairs.txt'),
                timing=dict(SfM_seconds=sum(row['seconds'] for row in case['stages'] if row['name']!='environment')))
except Exception as error:
    case.update(status='failed',error_type=type(error).__name__,error=str(error)[:1500]);raise
finally:
    case['seconds']=time.monotonic()-started;write(a.out/'case.json',case)
print('FRESH_SFM_STAGE_COMPLETED',flush=True)
