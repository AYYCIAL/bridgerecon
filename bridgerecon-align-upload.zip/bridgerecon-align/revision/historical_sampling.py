"""Exact bilinear sampling compatible with the saved manuscript arrays.

The archived local_validation.py currently calls cv2.remap INTER_LINEAR, which
quantizes coordinates to a 1/32-pixel table. The saved C5 sample arrays instead
agree with exact bilinear interpolation at float32 query coordinates. This
compatibility layer is explicit; the archived source and results stay intact.
"""
import numpy as np
from scipy.ndimage import map_coordinates


def sample(array, uv):
    coordinates=np.asarray(uv,dtype=np.float32).reshape(-1,2)
    return map_coordinates(np.asarray(array,dtype=np.float32),coordinates[:,::-1].T,
                           order=1,mode='grid-constant',cval=0,prefilter=False)
