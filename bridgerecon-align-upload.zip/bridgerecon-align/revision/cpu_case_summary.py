"""E1-aligned RTK/LRF and fixed-pair summaries for one newly fitted case."""
from pathlib import Path, PureWindowsPath
import argparse
import importlib.util
import json
import sys
import numpy as np
from scipy.interpolate import LinearNDInterpolator, NearestNDInterpolator

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--preparation', type=Path, required=True)
p.add_argument('--hybrid', type=Path, required=True)
p.add_argument('--control', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
p.add_argument('--allow-subset', action='store_true')
p.add_argument('--reference-hybrid', type=Path)
args = p.parse_args()
sys.path.insert(0, str(args.root/'experiments'))
from historical_sampling import sample
from revision_v041_analysis import block_histograms, quantile_from_hist
spec = importlib.util.spec_from_file_location('portable_e1', args.root/'colab_runtime.py')
e1 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(e1)
runtime = json.loads((args.root/'runtime_manifest.json').read_text(encoding='utf-8'))
old_root = PureWindowsPath(runtime['old_absolute_root'])
def relocated(value):
    if isinstance(value,str):
        if value.startswith('/content/bridgerecon/'):
            return str(args.root / value.removeprefix('/content/bridgerecon/'))
        path=PureWindowsPath(value)
        if path.is_absolute():
            try:
                path.relative_to(PureWindowsPath(args.root))
                return value
            except ValueError:
                pass
            try:return str(args.root.joinpath(*path.relative_to(old_root).parts))
            except ValueError:return value
        if '\\' in value and path.suffix.lower() in {'.npz','.json','.bin','.jpg','.py'}:
            return path.as_posix()
    if isinstance(value,list):return [relocated(v) for v in value]
    if isinstance(value,dict):return {k:relocated(v) for k,v in value.items()}
    return value
def read(path):return relocated(json.loads(Path(path).read_text(encoding='utf-8')))
P = e1.enu(read(args.root/'experiments/data_audit/images.json'))
with np.load(args.preparation/'global_cameras.npz') as g:
    E, indices = g['extrinsics'], g['image_indices'].astype(int)
C = -np.einsum('nji,nj->ni', E[:, :, :3], E[:, :, 3])
hold = np.array([e1.held_out(i) for i in indices])
if not args.allow_subset:
    assert (~hold).sum() == 454 and hold.sum() == 124
assert (~hold).sum() >= 3 and hold.sum() >= 1
s, R, t = e1.fit_similarity(C[~hold], P[indices][~hold])
residual = s*C@R.T+t-P[indices]
control = read(args.control/'report.json')
prep = read(args.preparation/'report.json')
hybrid = read(args.hybrid/'report.json')
result = {'scope': 'RTK uses 454-fit/124-test ENU; all depths rescaled by the same 454-fit scale',
          'camera': prep['native_cameras']['1'], 'solver': control['solver'],
          'withheld_rtk': e1.residual_summary(residual[hold]), 'enu_454_scale': s,
          'training_reprojection': control['training_reprojection_pixels'],
          'v3': hybrid['metrics']['view_depth_scale']}
result.update(navigation_fit_cameras=int((~hold).sum()), navigation_test_cameras=int(hold.sum()), enu_fit_scale=s)
if args.allow_subset:
    result.pop('enu_454_scale')
    result['scope'] = 'Navigation hash split restricted to retained cameras; all evaluated depths use that same training-only ENU scale'

reference = args.reference_hybrid or args.root/runtime['case_paths']['C5']['run']
with np.load(reference/'checking_pairs.npz') as p0, np.load(args.hybrid/'checking_pairs.npz') as p1:
    assert np.array_equal(p0['source'], p1['source']) and np.array_equal(p0['target'], p1['target'])
    a, b = p1['errors'][:, 3], p0['errors'][:, 3]
    ok = p1['supported'][:, 3] & p0['supported'][:, 3]
    source = p0['source'].copy()
    with np.load(reference/'checking_samples.npz') as obs:
        groups = obs['view'][source]//8
    edges = np.geomspace(1e-3, 1e3, 6001)
    rng = np.random.default_rng(20261023)
    weights = np.stack([np.bincount(rng.integers(0, 72, 72), minlength=72) for _ in range(2000)]).astype(float)
    qa = quantile_from_hist(weights@block_histograms(a, ok, groups, edges), edges, .5)
    qb = quantile_from_hist(weights@block_histograms(b, ok, groups, edges), edges, .5)
    result['v3_common_with_C5'] = {'pairs':int(ok.sum()), 'median_px':float(np.median(a[ok])),
        'p95_px':float(np.percentile(a[ok],95)), 'C5_median_px':float(np.median(b[ok])),
        'median_delta_px':float(np.median(a[ok])-np.median(b[ok])),
        'delta_ci95_px':np.percentile(qa-qb,[2.5,97.5]).tolist()}

headers = read(args.root/'metadata/original_xmp_headers.json')
L = np.array([float(r['drone_dji']['LRFTargetDistance']) for r in headers[:576]])
with np.load(args.root/'metadata/c5_mvs_centre_windows.npz') as crops:
    depth = crops['depth'][:,54:75,54:75].copy()
depth[depth<=0] = np.nan
flat = np.nanmax(depth,axis=(1,2))-np.nanmin(depth,axis=(1,2))<1
assert flat.sum()==271
views = {v['index']:v for v in prep['views']}
owner = {}
for chunk in hybrid['chunks']:
    for slot, index in enumerate(chunk['image_indices']):
        owner.setdefault(index,(chunk,slot))
centre = np.array([258.5,195.5])
v3, a3 = np.full(576,np.nan), np.full(576,np.nan)
cached_path, cached_depth = None, None
for i in range(576):
    if i not in owner:
        continue
    chunk, slot = owner[i]
    path = chunk['input']
    if path != cached_path:
        with np.load(path) as prediction:
            cached_depth = prediction['depth'].copy()
        cached_path = path
    d = float(sample(cached_depth[slot,...,0],centre[None])[0])
    v3[i] = s*d*chunk['similarity']['scale']*chunk['depth_fit']['views'][slot]['applied_scale']
    with np.load(args.preparation/views[i]['file']) as anchors:
        use = anchors['train_eligible'] & np.isfinite(anchors['train_z']) & (anchors['train_z']>0)
        uv, z = anchors['train_uv'][use], anchors['train_z'][use]
        d3 = LinearNDInterpolator(uv,z)(centre[None])[0]
        if not np.isfinite(d3):
            d3 = NearestNDInterpolator(uv,z)(centre[None])[0]
        a3[i] = s*float(d3)
result['rangefinder'] = {}
for method, D in [('V3',v3),('A3',a3)]:
    for label, use in [('all',np.ones(576,bool)),('flat',flat)]:
        use = use & np.isfinite(D) & (D>0)
        ratio = np.median(D[use]/L[use])
        scatter = np.abs(D[use]/ratio-L[use])
        result['rangefinder'][method+'/'+label] = {'n':int(use.sum()),'bias_pct':float((ratio-1)*100),
            'scatter_median_m':float(np.median(scatter)),'scatter_p95_m':float(np.percentile(scatter,95))}
args.out.write_text(json.dumps(result,indent=2),encoding='utf-8')
print('SUMMARY_COMPLETED', args.out)
