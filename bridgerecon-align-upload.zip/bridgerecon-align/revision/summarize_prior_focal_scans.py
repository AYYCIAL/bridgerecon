"""Create E2/E3 tables and figures from the recovered, verified CPU summaries."""
from pathlib import Path
import csv
import hashlib
import json
import zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parent.parent
SOURCE=ROOT/'revision_20261116/results/highmem_cpu_runs/attempt_155903'
OUT=ROOT/'revision_20261116/results/prior_focal_tables';OUT.mkdir(exist_ok=True)
evidence={}
with zipfile.ZipFile(SOURCE/'cpu_results.zip') as archive:
    def load(label):
        names=[name for name in archive.namelist() if name.endswith('/'+label+'_summary.json')]
        assert names,(label,names)
        raw=archive.read(names[0])
        assert all(archive.read(name)==raw for name in names),('Conflicting summary copies',label)
        value=json.loads(raw)
        assert value['v3']['checking_pairs']==691694
        assert value['withheld_rtk']['three_dimensional_m']['n']==124
        for method in ['V3','A3']:
            assert value['rangefinder'][method+'/all']['n']==576
            assert value['rangefinder'][method+'/flat']['n']==271
        evidence[label]={'members':names,'sha256':hashlib.sha256(raw).hexdigest()}
        return value
    priors=[('C1','No prior'),('C2','Isotropic 10 m'),('sigma_v_2','10 / 2 m'),
            ('C5','10 / 1 m'),('sigma_v_0p5','10 / 0.5 m'),('C6','Isotropic 0.10 m'),
            ('C7','Isotropic 0.03 m'),('C15_RTK_001','Isotropic 0.01 m')]
    focal=[('C13_f1066_7','C13'),('C9_f1087_2','C9'),('C10_f1098_3','C10'),
           ('C8','C8'),('C11_f1120_5','C11'),('C12_f1131_6','C12')]
    prior_data=[load(label) for label,_ in priors]
    focal_data=[load(label) for label,_ in focal]


def flatten(label,description,value):
    row={'case':label,'description':description,'focal_px':value['camera']['params'][0],
         'k1':value['camera']['params'][3],'enu_454_scale':value['enu_454_scale'],
         'V3_support_fraction':value['v3']['supported_pair_fraction'],
         'V3_success_below2px_fraction':value['v3']['fixed_inventory_success_below2px'],
         'V3_own_median_px':value['v3']['reprojection_pixels']['median'],
         'V3_own_p95_px':value['v3']['reprojection_pixels']['p95']}
    common=value['v3_common_with_C5']
    row.update(common_pairs_with_C5=common['pairs'],V3_common_median_px=common['median_px'],
               V3_common_p95_px=common['p95_px'],V3_delta_median_vs_C5_px=common['median_delta_px'],
               V3_delta_ci95_low_px=common['delta_ci95_px'][0],V3_delta_ci95_high_px=common['delta_ci95_px'][1])
    for axis,statistics in value['withheld_rtk'].items():
        for quantile in ['median','p95']:row['RTK_'+axis+'_'+quantile]=statistics[quantile]
    for key,statistics in value['rangefinder'].items():
        for metric,number in statistics.items():row[key.replace('/','_')+'_'+metric]=number
    return row


def write_csv(name,labels,data):
    rows=[flatten(label,description,value) for (label,description),value in zip(labels,data)]
    with (OUT/name).open('w',newline='',encoding='utf-8-sig') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    return rows


prior_rows=write_csv('E2_prior_strength.csv',priors,prior_data)
focal_rows=write_csv('E3_focal_sensitivity.csv',focal,focal_data)
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.22,'pdf.fonttype':42})


def draw_bias(axis,x,data,subset):
    for method,color,marker in [('V3','#1765ad','o'),('A3','#d46a18','s')]:
        axis.plot(x,[d['rangefinder'][method+'/'+subset]['bias_pct'] for d in data],
                  color=color,marker=marker,label=method)
    axis.axhline(0,color='black',lw=.8,alpha=.6)
    axis.set_ylabel('Range bias (%)');axis.legend(frameon=False)


def draw_delta(axis,x,data):
    delta=np.array([d['v3_common_with_C5']['median_delta_px'] for d in data])
    intervals=np.array([d['v3_common_with_C5']['delta_ci95_px'] for d in data])
    axis.vlines(x,intervals[:,0],intervals[:,1],color='#1765ad')
    axis.plot(x,delta,'o',color='#1765ad')
    axis.axhline(0,color='black',lw=.8,alpha=.6)
    axis.set_ylabel('V3 median change vs C5 (px)')
    axis.set_title('Pairwise common support, 95% route-block CI')


x=np.arange(len(priors))
fig,axes=plt.subplots(2,2,figsize=(13.4,8.2),layout='constrained')
axes[0,0].plot(x,[d['camera']['params'][0] for d in prior_data],'o-',color='#1765ad')
axes[0,0].set(ylabel='Shared focal length (px)',title='Free focal length under position priors')
draw_bias(axes[0,1],x,prior_data,'all');axes[0,1].set_title('Principal-point range comparison, 576 images')
for quantile,style in [('median','o-'),('p95','s--')]:
    axes[1,0].plot(x,[d['withheld_rtk']['three_dimensional_m'][quantile] for d in prior_data],style,label=quantile)
axes[1,0].set(yscale='log',ylabel='Held-out 3D RTK residual (m)',title='454 fit positions, 124 held-out positions');axes[1,0].legend(frameon=False)
draw_delta(axes[1,1],x,prior_data)
short=['None','10 m','10 / 2','10 / 1','10 / 0.5','0.10 m','0.03 m','0.01 m']
for axis in axes.ravel():
    axis.set_xticks(x,short,rotation=35,ha='right');axis.set_xlabel('Position prior: isotropic or horizontal / vertical (m)')
fig.suptitle('E2  Position-prior sensitivity',fontsize=15)
fig.savefig(OUT/'E2_prior_strength.png',dpi=180);fig.savefig(OUT/'E2_prior_strength.pdf');plt.close(fig)

x=np.array([d['camera']['params'][0] for d in focal_data])
fig,axes=plt.subplots(2,2,figsize=(12.5,8),layout='constrained')
draw_bias(axes[0,0],x,focal_data,'all');axes[0,0].set_title('Range bias, all 576 images')
mvs=json.loads((ROOT/'revision_20261116/results/cli_gpu_mvs_20261116/attempt_145119/C8_MVS518/C8_MVS518_summary.json').read_text())
axes[0,0].scatter([1109.4],[mvs['primary_raster']['all']['bias_pct']],marker='*',s=140,color='#52565d',label='C8 MVS518',zorder=5)
axes[0,0].legend(frameon=False)
draw_bias(axes[0,1],x,focal_data,'flat');axes[0,1].set_title('Range bias, fixed flat subset of 271 images')
for method,color,marker in [('V3','#1765ad','o'),('A3','#d46a18','s')]:
    axes[1,0].plot(x,[d['rangefinder'][method+'/all']['scatter_p95_m'] for d in focal_data],color=color,marker=marker,label=method)
axes[1,0].set(ylabel='Debiased absolute range residual P95 (m)',title='Range dispersion, all 576 images');axes[1,0].legend(frameon=False)
draw_delta(axes[1,1],x,focal_data)
for axis in axes.ravel():axis.set_xlabel('Fixed shared focal length at 1600 x 1200 (px)')
fig.suptitle('E3  Fixed-focal sensitivity with isotropic 0.10 m priors',fontsize=15)
fig.savefig(OUT/'E3_focal_sensitivity.png',dpi=180);fig.savefig(OUT/'E3_focal_sensitivity.pdf');plt.close(fig)
record={'status':'generated_pending_visual_review','source_archive_sha256':json.loads((SOURCE/'cpu_results_manifest.json').read_text())['archive_sha256'],
        'source_summaries':evidence,'E2_cases':len(prior_rows),'E3_cases':len(focal_rows),
        'definitions':'454-fit ENU scale, 124 withheld RTK positions, 691694 fixed pairs. Plot changes use pairwise common support with C5 and 2000 route-block bootstrap resamples.',
        'interpretation':'C15 0.01 m prior shows a larger image-consistency change than the weaker priors; retain this observed result in interpretation.',
        'outputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.iterdir() if p.suffix in ['.csv','.png','.pdf']}}
(OUT/'figure_manifest.json').write_text(json.dumps(record,indent=2))
print('E2_E3_TABLES_FIGURES_READY',str(OUT),flush=True)
