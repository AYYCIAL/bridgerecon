"""E7/E8 scans using the frozen manuscript evaluator and explicit overlays."""
from pathlib import Path, PureWindowsPath
import argparse
import hashlib
import importlib
import json
import os
import shutil
import subprocess
import sys
import time
import numpy as np
from scipy.interpolate import LinearNDInterpolator, NearestNDInterpolator
from scipy.spatial import QhullError

p=argparse.ArgumentParser()
p.add_argument('--label',required=True)
p.add_argument('--confidence',type=float,default=1.2)
p.add_argument('--fraction',type=float,default=1.)
p.add_argument('--bounds',choices=['original','none','tight'],default='original')
p.add_argument('--out',type=Path,required=True)
args=p.parse_args()
assert args.confidence in [1.,1.2,1.5,2.,3.] and args.fraction in [1.,.5,.25,.1,.05]
root=Path(os.environ.get('BRIDGERECON_ROOT', '/content/bridgerecon'));exp=root/'experiments';sys.path.insert(0,str(exp))
sys.path.insert(0,str(Path(__file__).parent))
started=time.monotonic()
runtime=json.loads((root/'runtime_manifest.json').read_text())
old=PureWindowsPath(runtime['old_absolute_root'])


def relocate(value):
    if isinstance(value,str):
        path=PureWindowsPath(value)
        if path.is_absolute():
            try:return str(root.joinpath(*path.relative_to(old).parts))
            except ValueError:return value
        if '\\' in value and path.suffix:return path.as_posix()
    if isinstance(value,list):return [relocate(v) for v in value]
    if isinstance(value,dict):return {k:relocate(v) for k,v in value.items()}
    return value


def read(path):return relocate(json.loads(Path(path).read_text()))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2))


args.out.mkdir(parents=True,exist_ok=True)
import work_schedule
work_schedule.require_start_window=lambda seconds:None
import local_validation
from historical_sampling import sample
local_validation.sample=sample
import global_hybrid_geometry as geom
g_source=Path(geom.__file__).read_text(encoding='utf-8-sig')
updated=g_source.replace('c>=1.2',f'c>={args.confidence!r}')
if args.bounds=='none':
    updated=updated.replace('len(log_ratio)>=20','len(log_ratio)>0').replace('len(pooled)>=100','len(pooled)>0')
    updated=updated.replace('.8<=raw/chunk<=1.25','0.<raw/chunk<float("inf")')
elif args.bounds=='tight':
    updated=updated.replace('len(log_ratio)>=20','len(log_ratio)>=40').replace('len(pooled)>=100','len(pooled)>=50')
    updated=updated.replace('.8<=raw/chunk<=1.25','.95<=raw/chunk<=1.05')
exec(compile(updated,geom.__file__,'exec'),geom.__dict__)
geom.sample=sample
import run_global_hybrid as hybrid
h_source=Path(hybrid.__file__).read_text(encoding='utf-8-sig')
assert h_source.count('>=1.2')==2
h_overlay=h_source.replace('>=1.2',f'>={args.confidence!r}')
exec(compile(h_overlay,hybrid.__file__,'exec'),hybrid.__dict__)
hybrid.read=read;hybrid.require_start_window=lambda seconds:None
source_prep=root/runtime['case_paths']['C5']['preparation']
prep=source_prep
sparsity={'rule':'First 8 bytes of SHA256(anchor-sparsity-v1|globalID) < fraction * 2**64; same ID in all views',
          'requested_fraction':args.fraction}
if args.fraction<1:
    prep=args.out/'preparation';prep.mkdir(exist_ok=True);(prep/'anchors').mkdir(exist_ok=True)
    report=read(source_prep/'report.json');selected=set();all_ids=set()
    for row in report['views']:
        source=source_prep/row['file'];assert sha(source)==row['sha256']
        with np.load(source) as archive:data={k:archive[k] for k in archive.files}
        ids=data['train_ids'];all_ids.update(map(int,ids))
        keep=np.array([int.from_bytes(hashlib.sha256(f'anchor-sparsity-v1|{int(pid)}'.encode()).digest()[:8],'big')<args.fraction*2**64 for pid in ids])
        selected.update(map(int,ids[keep]));data['train_eligible']=data['train_eligible']&keep
        destination=prep/row['file'];np.savez_compressed(destination,**data)
        row.update(sha256=sha(destination),train_depth_eligible=int(data['train_eligible'].sum()))
    for name in ['native_cameras.json','global_cameras.npz','split.npz']:
        shutil.copy2(source_prep/name,prep/name)
    report['sparsity_overlay']=dict(sparsity,source_preparation=str(source_prep))
    write(prep/'report.json',report)
    sparsity.update(actual_unique_tracks=len(selected),source_unique_tracks=len(all_ids),actual_fraction=len(selected)/len(all_ids))
else:
    with np.load(source_prep/'split.npz') as split:sparsity.update(actual_unique_tracks=len(split['selected_training_ids']),actual_fraction=1.)
out=args.out/'hybrid';out.mkdir(exist_ok=True)
hybrid.worker(prep,[root/runtime['predictions']],None,out)
report=read(out/'report.json')
result={'label':args.label,'status':'running','confidence':args.confidence,'fraction':args.fraction,
        'bounds':args.bounds,'sparsity':sparsity,
        'source_sha256':{'geometry':hashlib.sha256(g_source.encode()).hexdigest(),'evaluator':hashlib.sha256(h_source.encode()).hexdigest()},
        'overlay_sha256':{'geometry':hashlib.sha256(updated.encode()).hexdigest(),'evaluator':hashlib.sha256(h_overlay.encode()).hexdigest()},
        'camera_configuration':'Frozen original C5; no inference or camera BA',
        'scope':'E7/E8 numerical scans; bridge-envelope stratification requires separate review',
        'chunk_support':[{'start':c['start'],'supported':c['depth_fit']['chunk_supported'],
                          'anchors':c['depth_fit']['pooled_training_observations']} for c in report['chunks']]}
result['view_fallback_fraction']=1-sum(v['view_specific_accepted'] for c in report['chunks'] for v in c['depth_fit']['views'])/sum(len(c['depth_fit']['views']) for c in report['chunks'])
if report['status']=='unsupported_training_anchors':
    result.update(status='completed_unsupported',reason='Original minimum-support rule rejects at least one context; not relaxed to force a result',seconds=time.monotonic()-started)
    write(args.out/'scan_result.json',result)
    print('SCAN_CASE_COMPLETED',args.label,'unsupported',flush=True)
    raise SystemExit(0)
assert report['status']=='completed'
baseline=root/runtime['case_paths']['C5']['run']
with np.load(baseline/'checking_pairs.npz') as a,np.load(out/'checking_pairs.npz') as b:
    assert np.array_equal(a['source'],b['source']) and np.array_equal(a['target'],b['target'])
    assert len(a['source'])==691694
    if args.label=='baseline':
        am,bm=read(baseline/'report.json')['metrics']['view_depth_scale'],report['metrics']['view_depth_scale']
        parity={'pairs':len(a['source']),'support_delta':bm['supported_pair_fraction']-am['supported_pair_fraction'],
                'median_delta_px':bm['reprojection_pixels']['median']-am['reprojection_pixels']['median']}
        assert abs(parity['support_delta'])<1e-8 and abs(parity['median_delta_px'])<1e-4
        result['parity']=parity

# Freeze above, then evaluate. Baseline A3 uses exactly TIN + nearest outside hull.
from local_validation import inside,statistics
from global_hybrid_geometry import unproject_native
from revision_v041_analysis import pair_errors
with np.load(out/'checking_samples.npz') as z:samples={k:z[k] for k in z.files}
metadata=read(prep/'report.json');views={v['index']:v for v in metadata['views']}
cameras=read(prep/'native_cameras.json');depth=np.full(len(samples['ids']),np.nan);models={}
tin_fallback_views=[]
for index in np.unique(samples['view']):
    with np.load(prep/views[int(index)]['file']) as a:
        good=a['train_eligible']&inside(a['train_uv'])&np.isfinite(a['train_z'])&(a['train_z']>0)
        uv,z=a['train_uv'][good],a['train_z'][good];positions=np.where(samples['view']==index)[0]
        quv=samples['uv'][positions]
        if not len(z):continue
        try:
            if len(z)<3:raise QhullError('Insufficient anchors')
            d=LinearNDInterpolator(uv,z)(quv)
        except QhullError:
            d=np.full(len(quv),np.nan);tin_fallback_views.append(int(index))
        missing=~np.isfinite(d)
        d[missing]=NearestNDInterpolator(uv,z)(quv[missing]);depth[positions]=d
        models[int(index)]={'E':a['extrinsics'].copy(),'A':a['native_to_input'].copy(),'camera':cameras[str(int(a['camera_id']))]}
xyz=np.full((len(depth),3),np.nan)
for index,model in models.items():
    rows=np.where(samples['view']==index)[0]
    xyz[rows]=unproject_native(samples['uv'][rows],depth[rows],model['E'],model['camera'],model['A'])
with np.load(out/'checking_pairs.npz') as pairs:
    source,target=pairs['source'],pairs['target']
    ae,av=pair_errors(xyz,np.isfinite(xyz).all(axis=1)&(depth>0),samples['uv'],samples['view'],source,target,models)
    np.savez_compressed(args.out/'A3_checking_pairs.npz',errors=ae,supported=av)
    result['cross_view']={}
    for name,errors,supported in [('V2',pairs['errors'][:,2],pairs['supported'][:,2]),('V3',pairs['errors'][:,3],pairs['supported'][:,3]),('A3',ae,av)]:
        result['cross_view'][name]={'fixed_pairs':len(source),'supported_fraction':float(supported.mean()),
            'reprojection_px':statistics(errors),'fixed_inventory_success_below2px':float(np.sum(errors<2)/len(source))}
result['A3_degenerate_TIN_nearest_fallback_views']=tin_fallback_views
control=Path(read(source_prep/'report.json')['camera_control_source'])
summary=subprocess.run([sys.executable,str(Path(__file__).with_name('cpu_case_summary.py')),
    '--root',str(root),'--preparation',str(prep),'--control',str(control),'--hybrid',str(out),
    '--out',str(args.out/'summary.json')],capture_output=True,text=True,timeout=900)
(args.out/'summary.log').write_text(summary.stdout+'\n'+summary.stderr)
assert summary.returncode==0,summary.stderr[-3000:]
result['summary']=read(args.out/'summary.json')

import audit_full_hybrid_seams as seam
s_source=Path(seam.__file__).read_text(encoding='utf-8-sig')
assert s_source.count('>=1.2')==1
s_overlay=s_source.replace('>=1.2',f'>={args.confidence!r}')
exec(compile(s_overlay,seam.__file__,'exec'),seam.__dict__)
seam.read=read;seam.require_start_window=lambda seconds:None
seam.INPUT=out;seam.BASE=args.out/'seams';(seam.BASE/'runs').mkdir(parents=True,exist_ok=True)
seam.main()
seam_reports=list((seam.BASE/'runs').glob('*/report.json'));assert len(seam_reports)==1
result['seams']=read(seam_reports[0]);assert result['seams']['seam_count']==71
result.update(status='completed',seconds=time.monotonic()-started)
write(args.out/'scan_result.json',result)
print('SCAN_CASE_COMPLETED',args.label,flush=True)
