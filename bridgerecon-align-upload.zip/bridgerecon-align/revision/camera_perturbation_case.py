"""Run one E4 control from C8 with the archived BA, anchor and evaluation code."""
from pathlib import Path, PureWindowsPath
from datetime import datetime
import argparse
import hashlib
import importlib
import json
import os
import runpy
import sys
import time
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--free-principal-point', action='store_true')
parser.add_argument('--radial-k2', action='store_true')
parser.add_argument('--time-offset-seconds', type=float, default=0.)
parser.add_argument('--vertical-offset-metres', type=float, default=0.)
parser.add_argument('--threads', type=int, default=8)
args = parser.parse_args()
assert sum([args.free_principal_point, args.radial_k2, bool(args.time_offset_seconds), bool(args.vertical_offset_metres)]) <= 1
assert 1 <= args.threads <= 8
root = args.root.resolve()
out = args.out.resolve()
runtime = json.loads((root / 'runtime_manifest.json').read_text(encoding='utf-8'))
survey = root / runtime['survey']
assert out.is_relative_to(survey.resolve())
out.mkdir(parents=True, exist_ok=True)
experiments = root / 'experiments'
sys.path.insert(0, str(experiments))
started = time.monotonic()
deadline = started + 900
old_root = PureWindowsPath(runtime['old_absolute_root'])


def relocated(value):
    if isinstance(value, str):
        if value.startswith('/content/bridgerecon/'):
            return str(root / value.removeprefix('/content/bridgerecon/'))
        path = PureWindowsPath(value)
        if path.is_absolute():
            try:
                path.relative_to(PureWindowsPath(root))
                return value
            except ValueError:
                pass
            try:
                return str(root.joinpath(*path.relative_to(old_root).parts))
            except ValueError:
                return value
        if '\\' in value and path.suffix.lower() in ['.npz', '.json', '.bin', '.jpg', '.png', '.ply', '.py', '.txt', '.csv']:
            return path.as_posix()
    elif isinstance(value, list):
        return [relocated(item) for item in value]
    elif isinstance(value, dict):
        return {key: relocated(item) for key, item in value.items()}
    return value


def read(path):
    return relocated(json.loads(Path(path).read_text(encoding='utf-8')))


def check_window(seconds):
    if time.monotonic() + seconds > deadline:
        raise TimeoutError('E4 case reached its fifteen-minute deadline')
    return dict(platform=sys.platform, case_deadline_seconds=900)


import work_schedule
work_schedule.require_start_window = check_window
import local_validation
from historical_sampling import sample
local_validation.sample = sample
import global_hybrid_geometry as geometry
if args.radial_k2:
    from radial_k2_geometry import install
    install(geometry)

base = importlib.import_module('run_navigation_prior_ba')
base.read = read
module = importlib.import_module('run_rtk_weighted_ba')
source_bytes = Path(module.__file__).read_bytes()
source = source_bytes.decode('utf-8-sig')
replacements = {
    'initial_model = resume / \'sparse\' if resume else PREP / \'fitted_sparse\'':
        'initial_model = resume / \'sparse\' if resume else E4_INITIAL_MODEL',
    "camera.params = np.array([fixed_focal, camera.width / 2., camera.height / 2., 0.])":
        'camera.params = np.array([fixed_focal, camera.params[1], camera.params[2], camera.params[3]])',
    'positions = nominal_positions(inventory)[indices]':
        "if E4_RADIAL_K2 and model.cameras[1].model.name == 'SIMPLE_RADIAL':\n"
        "        camera = model.cameras[1]\n"
        "        previous_params = camera.params.copy()\n"
        "        camera.model = pycolmap.CameraModelId.RADIAL\n"
        "        camera.params = np.r_[previous_params, 0.]\n"
        '    positions = nominal_positions(inventory)[indices]',
    'options.refine_principal_point = False':
        f'options.refine_principal_point = {args.free_principal_point!r}',
    'options.solver_options.num_threads = 4':
        f'options.solver_options.num_threads = {args.threads}',
}
overlay = source
for original, replacement in replacements.items():
    assert overlay.count(original) == 1, original
    overlay = overlay.replace(original, replacement)
exec(compile(overlay, module.__file__, 'exec'), module.__dict__)
module.read = read
module.require_start_window = check_window
module.E4_INITIAL_MODEL = root / runtime['case_paths']['C8']['preparation'] / 'fitted_sparse'
module.E4_RADIAL_K2 = args.radial_k2
original_positions = module.nominal_positions
inventory = read(root / 'experiments/data_audit/images.json')
positions = original_positions(inventory)
headers = read(root / 'metadata/original_xmp_headers.json')
exposures = [datetime.fromisoformat(row['drone_dji']['UTCAtExposure'].replace('Z', '+00:00')) for row in headers]
times = np.array([(stamp - exposures[0]).total_seconds() for stamp in exposures])
assert len(times) == len(positions) and np.all(np.diff(times) > 0)
velocity = np.gradient(positions, times, axis=0)
shift = args.time_offset_seconds * velocity
shift[:, 2] += args.vertical_offset_metres
module.nominal_positions = lambda rows: original_positions(rows) + shift
c8 = read(root / runtime['case_paths']['C8']['preparation'] / 'report.json')
sigma = float(c8['navigation_sigma_assumption'])
focal = float(c8['native_cameras']['1']['params'][0])
case = dict(status='running', initial_configuration='C8',
            free_principal_point=args.free_principal_point, radial_k2=args.radial_k2,
            time_offset_seconds=args.time_offset_seconds, vertical_offset_metres=args.vertical_offset_metres,
            velocity_method='Central finite differences of recorded RTK positions at UTCAtExposure timestamps',
            exposure_gap_seconds=[float(np.diff(times).min()), float(np.diff(times).max())],
            prior_shift_median_m=float(np.median(np.linalg.norm(shift, axis=1))),
            ba_source_sha256=hashlib.sha256(source_bytes).hexdigest(),
            ba_overlay_sha256=hashlib.sha256(overlay.encode()).hexdigest(),
            worker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            sampling_sha256=hashlib.sha256(Path(__file__).with_name('historical_sampling.py').read_bytes()).hexdigest(),
            summary_source_sha256=hashlib.sha256(Path(__file__).with_name('cpu_case_summary.py').read_bytes()).hexdigest(),
            range_sampling='Fixed 518x392 array centre [258.5, 195.5] in every control, matching the existing range summaries')
if args.radial_k2:
    case['radial_geometry_sha256'] = hashlib.sha256(Path(__file__).with_name('radial_k2_geometry.py').read_bytes()).hexdigest()
case_path = out / 'case.json'
case_path.write_text(json.dumps(case, indent=2))
try:
    control = out / 'control'
    control.mkdir(exist_ok=True)
    module.worker(control, sigma, sigma, 30., 400, 300., fixed_focal=focal)
    report = read(control / 'report.json')
    if 'NO_CONVERGENCE' in report['solver']['termination']:
        continuation = out / 'control_continued'
        continuation.mkdir(exist_ok=True)
        module.worker(continuation, sigma, sigma, 30., 400, 300., resume=control, fixed_focal=focal)
        control = continuation
        report = read(control / 'report.json')
    assert report['solver']['solution_usable'] and 'NO_CONVERGENCE' not in report['solver']['termination']
    report['perturbation'] = case.copy()
    report['calibration'] = f'Fixed focal {focal} px; ' + ('free principal point; ' if args.free_principal_point else 'fixed principal point; ')
    report['calibration'] += 'free k1/k2' if args.radial_k2 else 'free k1'
    (control / 'report.json').write_text(json.dumps(report, indent=2))
    export = importlib.import_module('export_hybrid_model_anchors')
    export.require_start_window = check_window
    preparation = out / 'preparation'
    preparation.mkdir(exist_ok=True)
    export.worker(control, preparation)
    hybrid = importlib.import_module('run_global_hybrid')
    hybrid.read = read
    hybrid.require_start_window = check_window
    hybrid_out = out / 'hybrid'
    hybrid_out.mkdir(exist_ok=True)
    hybrid.worker(preparation, [root / runtime['predictions']], None, hybrid_out)
    assert read(hybrid_out / 'report.json')['status'] == 'completed'
    sys.argv = ['cpu_case_summary.py', '--root', str(root), '--control', str(control),
                '--preparation', str(preparation), '--hybrid', str(hybrid_out), '--out', str(out / 'summary.json')]
    runpy.run_path(str(Path(__file__).with_name('cpu_case_summary.py')), run_name='__main__')
    case.update(status='completed', control=str(control), preparation=str(preparation), hybrid=str(hybrid_out),
                summary=read(out / 'summary.json'))
except BaseException as error:
    case.update(status='failed', error_type=type(error).__name__, error=str(error)[:2000])
    raise
finally:
    case['seconds'] = time.monotonic() - started
    case_path.write_text(json.dumps(case, indent=2))
print('CAMERA_PERTURBATION_COMPLETED', str(out), flush=True)
