"""Fuse the restored frozen-C5 maps in 72 archived covisibility contexts."""
from pathlib import Path
import argparse
import importlib.util
import json
import os
import resource
import shutil
import sys
import time
import zipfile
import numpy as np
import pycolmap
from voxel_cloud import digest, ply_layout, reduce_cloud

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--width', type=int, choices=[518, 1600], required=True)
args = parser.parse_args()
args.out.mkdir(exist_ok=True)
runtime = json.loads((args.root / 'runtime_manifest.json').read_text())
survey = args.root / runtime['survey']
preparation = args.root / runtime['case_paths']['C5']['preparation']
restored = args.root / f'e6_restored_mvs/C5_MVS{args.width}'
assert len(list((restored / 'dense/stereo/depth_maps').rglob('*.geometric.bin'))) == 576
sys.path.insert(0, str(args.root / 'experiments'))
from fuse_depth_tiles import make_manifest
spec = importlib.util.spec_from_file_location('fusion_e1', args.root / 'colab_runtime.py')
e1 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(e1)
started = time.monotonic()
case = dict(status='running', width=args.width, stages=[], tiles=[], chunk_checkpoints=[], checkpoint_seconds=0.,
    scope='Original frozen-C5 depth maps with declared tiled native fusion; shared-photo context overlaps retained before voxel reduction',
    input_camera_sha256={name: digest(preparation / 'fitted_sparse' / name) for name in ['cameras.bin', 'images.bin', 'points3D.bin']})


def save():
    case.update(seconds=time.monotonic() - started, peak_rss_MiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024)
    temporary = args.out / 'case.json.partial'
    temporary.write_text(json.dumps(case, indent=2))
    temporary.replace(args.out / 'case.json')
    temporary = args.out / 'progress.json.partial'
    temporary.write_text(json.dumps(dict(completed_chunks=len(case['tiles']), phase=case.get('phase'),
        chunk_checkpoints=case['chunk_checkpoints'])))
    temporary.replace(args.out / 'progress.json')


try:
    assert pycolmap.__version__ == '3.13.0'
    tick = time.monotonic()
    input_sparse = args.out / 'input_sparse'
    input_sparse.mkdir()
    model = pycolmap.Reconstruction(str(preparation / 'fitted_sparse'))
    metadata = json.loads((survey / 'report.json').read_text())
    names = {row['index']: row['name'] for row in metadata['images']}
    required = {names[index] for index in range(576)}
    for image_id in list(model.reg_image_ids()):
        image = model.images[image_id]
        if image.name not in required:
            model.deregister_frame(image.frame_id)
    assert model.num_reg_images() == 576
    model.write(str(input_sparse))
    undistorted = args.out / 'undistorted'
    case['phase'] = 'undistortion_for_fusion'
    save()
    pycolmap.undistort_images(str(undistorted), str(input_sparse), str(survey / 'images'),
        num_patch_match_src_images=10, undistort_options={'max_image_size': args.width})
    case['stages'].append(dict(name='undistortion', seconds=time.monotonic() - tick))
    expected = json.loads(Path('/content/mvs_restore_manifest.json').read_text())['expected_cameras'][str(args.width)]
    actual = pycolmap.Reconstruction(str(undistorted / 'sparse'))
    for row in expected:
        camera = actual.cameras[row['id']]
        assert camera.model.value == row['model']
        assert camera.width == row['width'] and camera.height == row['height']
        assert np.allclose(camera.params, row['params'], rtol=0, atol=1e-10)
    case['undistorted_camera_parity_verified'] = True
    dense = restored / 'dense'
    shutil.copytree(undistorted / 'sparse', dense / 'sparse', dirs_exist_ok=True)
    shutil.copy2(undistorted / 'stereo/fusion.cfg', dense / 'stereo/fusion.cfg')
    manifest = make_manifest(survey, restored, expected_images=576)
    assert len(manifest['tiles']) == 72
    (args.out / 'tile_manifest.json').write_text(json.dumps(manifest, indent=2))
    cloud_paths = []
    fusion_seconds = 0.
    case['phase'] = 'native_tiled_fusion'
    for tile in manifest['tiles']:
        folder = args.out / 'tiles' / f'{tile["tile"]:03d}'
        workspace = folder / 'dense'
        workspace.mkdir(parents=True)
        shutil.copytree(dense / 'sparse', workspace / 'sparse')
        for name in tile['context']:
            paths = [(undistorted / 'images' / name, workspace / 'images' / name)]
            for kind in ['depth_maps', 'normal_maps']:
                paths.append((dense / 'stereo' / kind / (name + '.geometric.bin'),
                              workspace / 'stereo' / kind / (name + '.geometric.bin')))
            for source, destination in paths:
                destination.parent.mkdir(parents=True, exist_ok=True)
                os.link(source, destination)
        (workspace / 'stereo/fusion.cfg').write_text('\n'.join(tile['context']) + '\n')
        options = pycolmap.StereoFusionOptions()
        options.num_threads = 8
        options.use_cache = False
        options.max_image_size = args.width
        options.min_num_pixels = 5
        path = folder / 'fused.ply'
        tick = time.monotonic()
        pycolmap.stereo_fusion(str(path), str(workspace), input_type='geometric', options=options)
        elapsed = time.monotonic() - tick
        fusion_seconds += elapsed
        count, dtype, offset = ply_layout(path)
        assert path.stat().st_size == offset + count * dtype.itemsize
        if count:
            cloud = np.memmap(path, dtype=dtype, offset=offset, shape=(count,), mode='r')
            for begin in range(0, count, 200000):
                assert all(np.isfinite(cloud[begin:begin + 200000][key]).all() for key in ['x', 'y', 'z'])
            del cloud
        cloud_paths.append(path)
        case['tiles'].append(dict(tile=tile['tile'], points=count, seconds=elapsed, sha256=digest(path)))
        tick = time.monotonic()
        target = Path('/content/cpu_supplement_checkpoints') / f'Supplement_{args.out.name}_fusion_{tile["tile"]:03d}.zip'
        with zipfile.ZipFile(target.with_suffix('.partial'), 'w', zipfile.ZIP_DEFLATED, compresslevel=1) as archive:
            archive.write(path, 'fused.ply')
        target.with_suffix('.partial').replace(target)
        case['chunk_checkpoints'].append(dict(name=target.name, bytes=target.stat().st_size, sha256=digest(target), tile=tile['tile']))
        case['checkpoint_seconds'] += time.monotonic() - tick
        save()
        print('MVS_FUSION_TILE_VERIFIED', args.width, tile['tile'], count, flush=True)
        assert workspace.resolve().is_relative_to(args.out.resolve() / 'tiles')
        shutil.rmtree(workspace)
    case['native_fusion_seconds'] = fusion_seconds
    with np.load(preparation / 'global_cameras.npz') as archive:
        E, indices = archive['extrinsics'], archive['image_indices'].astype(int)
    centers = -np.einsum('nji,nj->ni', E[:, :, :3], E[:, :, 3])
    rows = json.loads((args.root / 'experiments/data_audit/images.json').read_text())
    training = np.array([not e1.held_out(index) for index in indices])
    transform = e1.fit_similarity(centers[training], e1.enu(rows)[indices][training])
    case['phase'] = 'common_voxel_reduction'
    save()
    assert sum(row['points'] for row in case['tiles']) > 0
    case['voxel'] = reduce_cloud(cloud_paths, args.out / 'voxel', transform=transform)
    case.update(status='completed', core_cameras=576, fusion_tiles=72,
        output_records_before_voxel=sum(row['points'] for row in case['tiles']),
        source_cameras_unchanged=all(digest(preparation / 'fitted_sparse' / name) == value for name, value in case['input_camera_sha256'].items()))
    assert case['source_cameras_unchanged']
    recovery_deadline = time.monotonic() + 240
    while time.monotonic() < recovery_deadline:
        if all((Path('/content/cpu_supplement_checkpoints') / (row['name'] + '.host_verified.json')).exists() for row in case['chunk_checkpoints']):
            break
        time.sleep(2)
    else:
        raise TimeoutError('Fusion tile archives were not acknowledged by the host')
    case['fusion_tile_checkpoints_host_verified'] = True
    for path in cloud_paths:
        assert path.resolve().is_relative_to(args.out.resolve() / 'tiles')
        path.unlink()
        visibility = path.with_suffix('.ply.vis')
        visibility.unlink(missing_ok=True)
    assert (undistorted / 'images').resolve().is_relative_to(args.out.resolve())
    shutil.rmtree(undistorted / 'images')
except BaseException as error:
    case.update(status='failed', error_type=type(error).__name__, error=str(error)[:1500])
    raise
finally:
    save()
print('MVS_TILED_FUSION_AND_VOXEL_COMPLETED', args.width, flush=True)
