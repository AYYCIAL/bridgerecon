"""Held-out range difference after a range-based scale correction (Section 3.8, Table S18 of the article).

Reads data/aggregate/range_correction/range_scale_correction.json (written by demos/range_scale_correction.py) and
plots, for C5 and C8, the median absolute range difference on the held-out photographs against the number of
photographs used to estimate the scale factor (median and 5th-95th percentile over 1000 random draws), the split by
pass (outbound pass -> return pass) and the uncorrected difference.
Output: docs/figures/range_correction.png. Usage: python demos/plot_range_correction.py (matplotlib)
"""
from pathlib import Path
import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RESULT = ROOT / "data" / "aggregate" / "range_correction" / "range_scale_correction.json"
OUT = ROOT / "docs" / "figures"
OUT.mkdir(parents=True, exist_ok=True)
COLOUR = {"C5": "#1f5f8b", "C8": "#d35f0b"}

res = json.loads(RESULT.read_text(encoding="utf-8"))["results"]
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False})
fig, ax = plt.subplots(figsize=(6.4, 3.8), layout="constrained")
for case, r in res.items():
    ks = sorted(int(k) for k in r["random"])
    med = [r["random"][str(k)]["median_of_medians_m"] for k in ks]
    lo = [m - r["random"][str(k)]["median_5th_95th_m"][0] for k, m in zip(ks, med)]
    hi = [r["random"][str(k)]["median_5th_95th_m"][1] - m for k, m in zip(ks, med)]
    ax.errorbar(ks, med, yerr=[lo, hi], marker="o", ms=4, capsize=3, color=COLOUR[case], label=f"{case}, random photographs")
    split = r["outbound_to_return"]
    offset = 0.96 if case == "C5" else 1.04            # keep the two pass-split markers apart
    ax.scatter([split["train_images"] * offset], [split["median_m"]], marker="s", s=36, color=COLOUR[case], zorder=3,
               label=f"{case}, outbound pass → return pass")
    ax.axhline(r["uncorrected"]["median_m"], ls="--", lw=1, color=COLOUR[case])
    ax.annotate(f"{case} uncorrected {r['uncorrected']['median_m']:.2f} m", (4.2, r["uncorrected"]["median_m"]),
                xytext=(0, 3), textcoords="offset points", fontsize=8, color=COLOUR[case])
ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xticks([5, 10, 29, 58, 282], ["5", "10", "29", "58", "282"])
ax.set(xlim=(4, 400), xlabel="Photographs used to estimate the range/depth ratio",
       ylabel="Median |range − scaled depth|, held-out (m)")
ax.grid(alpha=0.2, which="both")
ax.legend(loc="center right", fontsize=7.5)
fig.savefig(OUT / "range_correction.png", dpi=160)
for case, r in res.items():
    print(case, "uncorrected %.3f m; ten photographs %.3f m; outbound->return %.3f m"
          % (r["uncorrected"]["median_m"], r["random"]["10"]["median_of_medians_m"], r["outbound_to_return"]["median_m"]))
