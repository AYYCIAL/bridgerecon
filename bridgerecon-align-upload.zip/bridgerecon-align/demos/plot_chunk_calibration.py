"""Depth-scale calibration along the route (cf. Figure 4e of the article), from data/calibration/.

Panel (a): pooled chunk scale q_k and the combined depth multiplier s_k*q_k (divided by its median) for the 72
twelve-photograph chunks; shading marks the two chunks that span the turn between the passes.
Panel (b): ratio of the accepted per-image scale q_ki to its chunk scale q_k.
Output: docs/figures/chunk_calibration.png. Usage: python demos/plot_chunk_calibration.py (numpy, matplotlib)
"""
from pathlib import Path
import csv

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "calibration"
OUT = ROOT / "docs" / "figures"
OUT.mkdir(parents=True, exist_ok=True)


def rows(name):
    with (DATA / name).open(encoding="utf-8") as f:
        return list(csv.DictReader(f))


chunks = rows("chunk_calibration.csv")
views = rows("view_scales.csv")
start = np.array([int(r["chunk_start"]) for r in chunks])
q = np.array([float(r["chunk_scale_q"]) for r in chunks])
sq = np.array([float(r["combined_sq_over_median"]) for r in chunks])
ratio = np.array([float(r["ratio_to_chunk_scale"]) for r in views if r["per_image_scale_accepted"] == "True"])

plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "axes.titlesize": 9.5,
                     "axes.titleweight": "bold", "axes.titlelocation": "left", "legend.frameon": False})
fig, axes = plt.subplots(1, 2, figsize=(10.4, 3.6), layout="constrained", gridspec_kw={"width_ratios": [2.2, 1]})
for s in (272, 280):
    axes[0].axvspan(s - 4, s + 4, color="grey", alpha=0.15, lw=0)
axes[0].plot(start, q, "o-", ms=3, lw=1, color="#1f5f8b", label="pooled chunk scale $q_k$")
axes[0].plot(start, sq, "s-", ms=3, lw=1, color="#d35f0b", label="$s_k q_k$ / median")
axes[0].set(xlabel="First photograph of the chunk", ylabel="Scale factor", title="(a) Depth scale along the route")
axes[0].legend(loc="upper left")
axes[0].grid(alpha=0.2)
axes[1].hist(ratio, bins=30, color="#5b6b78")
axes[1].set(xlabel="$q_{ki}$ / $q_k$", ylabel="Photographs", title="(b) Per-image scales")
axes[1].grid(alpha=0.2)
fig.savefig(OUT / "chunk_calibration.png", dpi=160)
print("chunks %d: q_k %.2f-%.2f (CV %.1f%%); s_k*q_k CV %.1f%%; per-image ratios %d, %.3f-%.3f"
      % (len(q), q.min(), q.max(), 100 * q.std() / q.mean(), 100 * sq.std() / sq.mean(), ratio.size, ratio.min(), ratio.max()))
