"""Redraw Figures 7 and 11 of the manuscript from the files in this package.

Figure 7 (seam consistency): empirical distribution of the normalized discrepancy of photographs repeated in
adjacent chunks (panel a) and the P95 per adjacent overlap (panel b) for the depth variants V0-V3.
Figure 11 (focal-length and prior sensitivity): depth-to-range ratio bias (panel a) and V3 image discrepancy
(panel b) against the focal length; a least-squares line through the six fixed-focal controls shows the focal
sensitivity of the bias, and the distance of every prior control from that line is written to
data/aggregate/figures/figure11_line_check.json.

Inputs:  data/aggregate/figures/figure7_seam_quantiles.csv, data/aggregate/figures/figure7_seam_p95.csv,
         data/aggregate/prior_focal_tables/E2_prior_strength.csv, data/aggregate/prior_focal_tables/E3_focal_sensitivity.csv
Outputs: docs/figures/figure7_seam_consistency.png, docs/figures/figure11_camera_constraints.png,
         data/aggregate/figures/figure11_line_check.json
Usage:   python demos/make_figures_7_11.py   (requires numpy and matplotlib)
"""
from pathlib import Path
import csv
import json

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
AGG = ROOT / "data" / "aggregate"
OUT = ROOT / "docs" / "figures"
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({"font.family": "Arial", "font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titlesize": 9.5, "axes.titleweight": "bold", "axes.titlelocation": "left",
                     "legend.fontsize": 8, "legend.frameon": False, "pdf.fonttype": 42})
VCOL = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"]     # V0-V3, as in Figure 6
PRIOR, FIXED, LINE = "#1f5f8b", "#d35f0b", "#5b6b78"


def rows(path):
    with path.open(encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


# ----------------------------------------------------------------------------- Figure 7
quant = rows(AGG / "figures" / "figure7_seam_quantiles.csv")
seams = rows(AGG / "figures" / "figure7_seam_p95.csv")
q = [float(r["quantile"]) for r in quant]
fig, axes = plt.subplots(1, 2, figsize=(10.4, 3.8), layout="constrained")
for k in range(4):
    axes[0].plot([float(r[f"V{k}_pct"]) for r in quant], q, color=VCOL[k], label=f"V{k}")
    axes[1].plot(range(1, len(seams) + 1), [float(s[f"V{k}_p95_pct"]) for s in seams], color=VCOL[k], lw=1.1, label=f"V{k}")
bad = [i for i, s in enumerate(seams) if float(s["V3_p95_pct"]) > float(s["V0_p95_pct"])]
axes[1].scatter([i + 1 for i in bad], [float(seams[i]["V3_p95_pct"]) for i in bad],
                facecolors="none", edgecolors="black", s=55, zorder=4, label="V3 above V0")
for i, s in enumerate(seams):
    if s["turn"] == "True":
        axes[1].axvspan(i + 0.6, i + 1.4, color="grey", alpha=0.17, label="turn")
axes[0].set(xlim=(0, 15), ylim=(0, 1), xlabel="Seam discrepancy / training depth (%)", ylabel="Cumulative fraction",
            title="(a) Normalized overlap discrepancy")
axes[1].set(yscale="log", xlabel="Adjacent overlap along the route", ylabel="P95 / training depth (%)",
            title="(b) P95 per overlap")
for ax in axes:
    ax.grid(alpha=0.2)
axes[0].legend(loc="lower right")
axes[1].legend(loc="lower right", bbox_to_anchor=(1.0, 1.0), ncol=6, fontsize=7.5, handlelength=1.4, columnspacing=1.0)
fig.savefig(OUT / "figure7_seam_consistency.png", dpi=160)
plt.close(fig)

# ----------------------------------------------------------------------------- Figure 11
PRIOR_LABEL = {"C1": "C1", "C2": "C2", "sigma_v_2": "σv = 2 m", "C5": "C5", "sigma_v_0p5": "σv = 0.5 m",
               "C6": "C6", "C7": "C7", "C15_RTK_001": "0.01-m prior"}
FIXED_LABEL = {"C13_f1066_7": "width", "C9_f1087_2": "−2%", "C10_f1098_3": "−1%", "C8": "C8",
               "C11_f1120_5": "+1%", "C12_f1131_6": "+2%"}
prior = [r for r in rows(AGG / "prior_focal_tables" / "E2_prior_strength.csv") if r["case"] in PRIOR_LABEL]
fixed = [r for r in rows(AGG / "prior_focal_tables" / "E3_focal_sensitivity.csv") if r["case"] in FIXED_LABEL]
fx = np.array([float(r["focal_px"]) for r in fixed])
fb = np.array([float(r["V3_all_bias_pct"]) for r in fixed])
slope, intercept = np.polyfit(fx, fb, 1)
per_percent = slope * 1109.4 / 100            # percentage points of bias per 1% of the nominal focal length
check = {r["case"]: dict(focal_px=float(r["focal_px"]), bias_pct=float(r["V3_all_bias_pct"]),
                         line_pct=float(slope * float(r["focal_px"]) + intercept),
                         rtk_test_3d_median_m=float(r["RTK_test_3d_median_m"]) if r.get("RTK_test_3d_median_m") else None)
         for r in prior}
for v in check.values():
    v["residual_pp"] = v["bias_pct"] - v["line_pct"]

fig, axes = plt.subplots(1, 2, figsize=(10.4, 3.9), layout="constrained")
xs = np.linspace(1040, 1375, 2)
axes[0].plot(xs, slope * xs + intercept, ls=(0, (4, 3)), color=LINE, lw=1.0,
             label=f"fit to fixed-focal controls ({per_percent:.2f} pp per 1% of f)")
for data, labels, colour, marker, name in [(prior, PRIOR_LABEL, PRIOR, "o", "prior controls"),
                                           (fixed, FIXED_LABEL, FIXED, "s", "fixed-focal controls")]:
    f = [float(r["focal_px"]) for r in data]
    for panel, (ax, key) in enumerate([(axes[0], "V3_all_bias_pct"), (axes[1], "V3_own_median_px")]):
        y = [float(r[key]) for r in data]
        ax.scatter(f, y, marker=marker, color=colour, s=34 if marker == "o" else 30, zorder=3, label=name)
        for r, xi, yi in zip(data, f, y):
            lab = labels[r["case"]]
            if colour == FIXED and lab not in ("width", "C8"):
                continue                      # the ±1/±2% points are identified by their spacing
            dx, dy, ha = (6, 4, "left")
            if lab in ("C5",):
                dx, dy, ha = (-6, 5, "right")
            if lab == "σv = 0.5 m":
                dx, dy, ha = (6, -11, "left")
            if lab == "C8":
                dx, dy, ha = (7, -13, "left")
            if panel == 0 and lab in ("C6", "C7", "0.01-m prior"):
                dx, dy, ha = (7, -10, "left")   # below the fitted line, which rises to the right
            if panel == 0 and lab == "width":
                dx, dy, ha = (-6, 4, "right")
            ax.annotate(lab, (xi, yi), xytext=(dx, dy), textcoords="offset points", fontsize=7.5, ha=ha,
                        color=colour)
axes[0].axhline(0, color="grey", lw=0.7)
axes[0].set(ylabel="V3 depth / LRF ratio bias (%)", title="(a) Depth-to-range bias", ylim=(-9.5, 24))
for ax in axes:
    ax.set_xlim(1035, 1390)
axes[1].set(ylabel="V3 median discrepancy, own support (px)", title="(b) Image consistency")
for ax in axes:
    ax.set_xlabel("Focal length in the 1600-pixel plane (px)")
    ax.grid(alpha=0.2)
axes[0].legend(loc="upper left")
axes[1].legend(loc="upper center")
fig.savefig(OUT / "figure11_camera_constraints.png", dpi=160)
plt.close(fig)

summary = dict(slope_pct_per_px=float(slope), intercept_pct=float(intercept), pp_per_percent_of_1109_4=float(per_percent),
               fixed_focal_fit_residual_max_pp=float(np.max(np.abs(fb - (slope * fx + intercept)))), prior_controls=check)
(AGG / "figures").mkdir(parents=True, exist_ok=True)
(AGG / "figures" / "figure11_line_check.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
for k, v in check.items():
    print(k, "f=%.1f bias=%+.2f line=%+.2f residual=%+.2f" % (v["focal_px"], v["bias_pct"], v["line_pct"], v["residual_pp"]))
