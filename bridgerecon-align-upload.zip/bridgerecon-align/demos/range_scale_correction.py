"""Held-out laser-range scale correction for C5 and C8 (Section 3.8 and Supplementary Table S18).

A depth/range scale factor is estimated as the median LRF/depth ratio over k photographs and applied to the
remaining photographs; the uncorrected absolute difference |s*z - r| is then summarized on those held-out
photographs only. Random subsets use k = 5, 10, 29 (5%) and 58 (10%) with 1000 draws each (seed 20261118);
a split by pass estimates the factor on the outbound pass (0-281) and tests on the return pass (282-575).

Input:  data/aggregate/reviewer3/C5_C8_uncorrected_ranges.csv (z-depth at the principal point under the 454-position
        gauge and the LRF range for all 576 main-route photographs of C5 and C8).
Output: data/aggregate/range_correction/range_scale_correction.json and .csv.
Usage:  python demos/range_scale_correction.py   (requires numpy)
"""
from pathlib import Path
import csv
import json

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "data" / "aggregate" / "reviewer3" / "C5_C8_uncorrected_ranges.csv"
OUT = ROOT / "data" / "aggregate" / "range_correction"
SEED, DRAWS, KS = 20261118, 1000, (5, 10, 29, 58)


def summary(err):
    return dict(median_m=float(np.median(err)), p95_m=float(np.percentile(err, 95)))


rows = list(csv.DictReader(SRC.open(encoding="utf-8-sig")))
result, table = {}, []
for case in ("C5", "C8"):
    r = [x for x in rows if x["case"] == case]
    z = np.array([float(x["depth_454_gauge_m"]) for x in r])
    lrf = np.array([float(x["lrf_m"]) for x in r])
    idx = np.array([int(x["image_index"]) for x in r])
    assert len(z) == 576
    raw = summary(np.abs(z - lrf))
    out = dict(images=len(z), median_ratio_bias_pct=float(100 * (np.median(z / lrf) - 1)), uncorrected=raw, random={})
    table.append([case, "none (uncorrected)", "all 576", f"{raw['median_m']:.3f}", f"{raw['p95_m']:.3f}", ""])
    rng = np.random.default_rng(SEED)
    for k in KS:
        med, p95 = [], []
        for _ in range(DRAWS):
            train = rng.choice(len(z), k, replace=False)
            test = np.setdiff1d(np.arange(len(z)), train)
            s = np.median(lrf[train] / z[train])
            e = np.abs(s * z[test] - lrf[test])
            med.append(np.median(e))
            p95.append(np.percentile(e, 95))
        med, p95 = np.array(med), np.array(p95)
        out["random"][str(k)] = dict(draws=DRAWS, median_of_medians_m=float(np.median(med)),
                                     median_5th_95th_m=[float(np.percentile(med, 5)), float(np.percentile(med, 95))],
                                     median_of_p95_m=float(np.median(p95)))
        table.append([case, f"{k} random images", f"remaining {576 - k}", f"{np.median(med):.3f}",
                      f"{np.median(p95):.3f}", f"{np.percentile(med, 5):.3f}-{np.percentile(med, 95):.3f}"])
    p1, p2 = idx <= 281, (idx >= 282) & (idx <= 575)
    s = np.median(lrf[p1] / z[p1])
    e = summary(np.abs(s * z[p2] - lrf[p2]))
    out["outbound_to_return"] = dict(train_images=int(p1.sum()), test_images=int(p2.sum()), scale=float(s), **e)
    table.append([case, "outbound pass", "return pass", f"{e['median_m']:.3f}", f"{e['p95_m']:.3f}", ""])
    result[case] = out

OUT.mkdir(parents=True, exist_ok=True)
(OUT / "range_scale_correction.json").write_text(json.dumps(dict(
    source=SRC.relative_to(ROOT).as_posix(), seed=SEED, draws=DRAWS, results=result), indent=2), encoding="utf-8")
with (OUT / "range_scale_correction.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["case", "scale estimated from", "evaluated on", "median_abs_diff_m", "p95_abs_diff_m", "median_5th-95th_over_draws_m"])
    w.writerows(table)
for row in table:
    print(row)
